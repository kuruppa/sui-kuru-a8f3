const CACHE = "kuruppa-river-v7";
const ASSETS = [
  "./index.html",
  "./css/game.css",
  "./js/game.js",
  "./manifest.json",
  "./assets/icon.svg",
  "./assets/icon.png",
  "./assets/kuruppa-sit.png",
  "./assets/kuruppa-happy.png",
  "./assets/kuruppa-smile.png",
  "./assets/kuruppa-dizzy.png",
  "./assets/kuruppa-yay.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ゲーム本体はネットワーク優先（更新が端末に残りにくくする）
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  const path = url.pathname;
  const networkFirst =
    path.endsWith(".js") ||
    path.endsWith(".css") ||
    path.endsWith(".html") ||
    path.endsWith("/") ||
    path.endsWith("/index.html");

  if (networkFirst) {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((cache) => cache.put(event.request, copy));
          return res;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((hit) => hit || fetch(event.request))
  );
});

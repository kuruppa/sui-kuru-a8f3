#!/usr/bin/env bash
# 公開リポジトリ sui-kuru-a8f3 へ初回 push 用（PC）
set -euo pipefail
cd "$(dirname "$0")"

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  git init -b main
  git add -A
  git commit -m "Initial commit: スイスイくるっぱ！筑後川の大冒険"
fi

REMOTE="https://github.com/kuruppa/sui-kuru-a8f3.git"
if ! git remote get-url origin >/dev/null 2>&1; then
  git remote add origin "$REMOTE"
fi

echo "→ push します。Organization kuruppa 配下に空の公開リポジトリ sui-kuru-a8f3 を先に作成してください。"
git push -u origin main

echo ""
echo "完了後: リポジトリ → Settings → Pages → Source = GitHub Actions"
echo "遊べるURL: https://kuruppa.github.io/sui-kuru-a8f3/"

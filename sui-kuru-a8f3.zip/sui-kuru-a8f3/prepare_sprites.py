"""Export official Kuruppa sprites with transparent background."""
import os
import sys

try:
    from PIL import Image
except ImportError:
    import subprocess

    subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow", "-q"])
    from PIL import Image

SRC = "/tmp/kuruppa-design"
OUT = os.path.join(os.path.dirname(__file__), "assets")
os.makedirs(OUT, exist_ok=True)

MAPPING = {
    "extracted_129.png": "kuruppa-sit.png",
    "extracted_131.png": "kuruppa-happy.png",
    "extracted_135.png": "kuruppa-smile.png",
    "extracted_144.png": "kuruppa-dizzy.png",
    "extracted_184.png": "kuruppa-yay.png",
}


def black_bg_to_alpha(img: Image.Image, threshold: int = 28) -> Image.Image:
    img = img.convert("RGBA")
    w, h = img.size
    px = img.load()
    seen = [[False] * h for _ in range(w)]
    q = []

    def is_bg(x, y):
        r, g, b, a = px[x, y]
        return a > 0 and r <= threshold and g <= threshold and b <= threshold

    for x in range(w):
        q.append((x, 0))
        q.append((x, h - 1))
    for y in range(h):
        q.append((0, y))
        q.append((w - 1, y))

    while q:
        x, y = q.pop()
        if x < 0 or y < 0 or x >= w or y >= h or seen[x][y]:
            continue
        seen[x][y] = True
        if not is_bg(x, y):
            continue
        px[x, y] = (0, 0, 0, 0)
        q.extend(((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))

    # soften leftover dark fringe next to transparency
    fringe = []
    for x in range(w):
        for y in range(h):
            r, g, b, a = px[x, y]
            if a == 0 or r + g + b > 90:
                continue
            for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if 0 <= nx < w and 0 <= ny < h and px[nx, ny][3] == 0:
                    fringe.append((x, y))
                    break
    for x, y in fringe:
        px[x, y] = (0, 0, 0, 0)

    bbox = img.getbbox()
    if bbox:
        img = img.crop(bbox)
    return img


def white_to_alpha(img: Image.Image, threshold: int = 246) -> Image.Image:
    img = img.convert("RGBA")
    px = img.load()
    w, h = img.size
    for x in range(w):
        for y in range(h):
            r, g, b, a = px[x, y]
            if r >= threshold and g >= threshold and b >= threshold:
                px[x, y] = (r, g, b, 0)
    bbox = img.getbbox()
    if bbox:
        img = img.crop(bbox)
    return img


for src_name, dst_name in MAPPING.items():
    src = os.path.join(SRC, src_name)
    raw = Image.open(src)
    corner = raw.convert("RGBA").getpixel((0, 0))
    img = black_bg_to_alpha(raw) if corner[0] < 40 else white_to_alpha(raw)
    dst = os.path.join(OUT, dst_name)
    img.save(dst, "PNG")
    print("ok", dst_name, img.size, "via", "black" if corner[0] < 40 else "white")

# App icon: official sit sprite on river circle
sit = Image.open(os.path.join(OUT, "kuruppa-sit.png")).convert("RGBA")
icon = Image.new("RGBA", (512, 512), (79, 195, 247, 255))
# rounded-ish by just filling; browsers mask apple icons
pad = 70
box = 512 - pad * 2
sit_c = sit.copy()
sit_c.thumbnail((box, box))
icon.paste(sit_c, ((512 - sit_c.size[0]) // 2, (512 - sit_c.size[1]) // 2 + 12), sit_c)
icon.save(os.path.join(OUT, "icon.png"), "PNG")
print("ok icon.png", icon.size)

(() => {
  "use strict";

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const startUi = document.getElementById("start-ui");
  const goalUi = document.getElementById("goal-ui");
  const startBtn = document.getElementById("start-btn");
  const againBtn = document.getElementById("again-btn");
  const goalScoreEl = document.getElementById("goal-score");

  const params = new URLSearchParams(location.search);
  const FAST = params.has("fast");
  const AUTO_GOAL = params.has("goal");

  const CONFIG = {
    durationMs: FAST ? 12000 : 60000,
    dizzyMs: 2000,
    freezeMs: 3000, // やきとり：川の流れを止める
    invincibleMs: 5500,
    waterGunMs: 900,
    rockHp: 1,
    lanes: 3,
    baseSpeed: FAST ? 280 : 165,
    bossProgress: 0.72, // ゴール前の岩2列山場
  };

  function charW() {
    return Math.min(58, Math.max(44, viewW * 0.125));
  }
  function rockRadius() {
    return Math.min(18, Math.max(13, viewW * 0.042));
  }
  function itemRadius() {
    return Math.min(16, Math.max(12, viewW * 0.036));
  }
  // プレイ開始は画面上部、進行に応じて下へ移動 → 「上から下へ進む」見え方
  function boatYStart() {
    return viewH * 0.28;
  }
  function boatYEnd() {
    return viewH * 0.72;
  }
  function boatYAt(progress) {
    const p = Math.max(0, Math.min(1, progress));
    return boatYStart() + (boatYEnd() - boatYStart()) * p;
  }
  function boatYBase() {
    if (state.mode === "play" || state.mode === "goal") return boatYAt(state.progress);
    return boatYStart();
  }

  const kuruppaImg = {
    sit: loadSprite("assets/kuruppa-sit.png"),
    happy: loadSprite("assets/kuruppa-happy.png"),
    smile: loadSprite("assets/kuruppa-smile.png"),
    dizzy: loadSprite("assets/kuruppa-dizzy.png"),
    yay: loadSprite("assets/kuruppa-yay.png"),
  };

  function loadSprite(src) {
    const img = new Image();
    img.src = src;
    return img;
  }

  const ITEM_LABELS = {
    yakitori: "やきとり",
    ramen: "とんこつラーメン",
    flag: "くるめかすり",
  };

  let viewW = 390;
  let viewH = 844;
  let lastTs = 0;
  let running = false;
  let audio;

  const input = {
    down: false,
    startX: 0,
    startY: 0,
    lastX: 0,
    swiped: false,
    id: null,
  };

  const state = {
    mode: "title", // title | play | goal
    time: 0,
    progress: 0,
    lane: 1,
    boatX: 0,
    targetX: 0,
    boatY: 0,
    boatWobble: 0,
    dizzyUntil: 0,
    freezeUntil: 0,
    invUntil: 0,
    waterUntil: 0,
    collected: { yakitori: 0, ramen: 0, flag: 0 },
    totalItems: 0,
    smashed: 0,
    hits: 0,
    comboTap: 0,
    riverOffset: 0,
    hintUntil: 0,
    _bossSpawned: false,
    objects: [],
    particles: [],
    confetti: [],
    splashes: [],
    waterShots: [],
    medalSpin: 0,
  };

  function now() {
    return state.time;
  }

  function isDizzy() {
    return now() < state.dizzyUntil;
  }
  function isFrozen() {
    return now() < state.freezeUntil;
  }
  function isInvincible() {
    return now() < state.invUntil;
  }
  function hasWater() {
    return now() < state.waterUntil;
  }

  function riverLeft() {
    return viewW * 0.18;
  }
  function riverRight() {
    return viewW * 0.82;
  }

  function laneX(lane) {
    const left = riverLeft();
    const right = riverRight();
    return left + ((right - left) * lane) / (CONFIG.lanes - 1);
  }

  function clampBoatX(x) {
    return Math.max(riverLeft(), Math.min(riverRight(), x));
  }

  function smashZone() {
    // 船より下（手前）の帯 — 進行は上→下
    return { top: state.boatY + 18, bottom: state.boatY + viewH * 0.28 };
  }

  function resetPlay() {
    state.mode = "play";
    state.time = 0;
    state.progress = 0;
    state.lane = 1;
    state.boatX = laneX(1);
    state.targetX = state.boatX;
    state.boatY = boatYBase();
    state.boatWobble = 0;
    state.dizzyUntil = 0;
    state.freezeUntil = 0;
    state.invUntil = 0;
    state.waterUntil = 0;
    state.collected = { yakitori: 0, ramen: 0, flag: 0 };
    state.totalItems = 0;
    state.smashed = 0;
    state.hits = 0;
    state.comboTap = 0;
    state.riverOffset = 0;
    state.hintUntil = 0;
    state._bossSpawned = false;
    state.objects = [];
    state.particles = [];
    state.confetti = [];
    state.splashes = [];
    state.waterShots = [];
    state.medalSpin = 0;
    state._spawnAcc = 0;
    state._toast = null;
    spawnOpening();
  }

  function spawnOpening() {
    state.objects.push(makeItem("yakitori", 1, state.boatY + viewH * 0.22));
    state.objects.push(makeRock(0, state.boatY + viewH * 0.55));
    state.objects.push(makeItem("ramen", 2, state.boatY + viewH * 0.78));
  }

  /** ゴール前：左右2レーンを岩で埋め尽くす山場 */
  function spawnBossWave() {
    if (state._bossSpawned) return;
    state._bossSpawned = true;
    const cols = [0, 2]; // 左右2列。中央は逃げ道／タップしがい
    const rows = 9;
    const start = state.boatY + viewH * 0.22;
    const gap = viewH * 0.1;
    for (let r = 0; r < rows; r++) {
      for (const lane of cols) {
        const jitter = ((r + lane) % 2) * viewH * 0.02;
        state.objects.push(makeRock(lane, start + r * gap + jitter));
      }
      // ときどき中央にも岩を置いて緊張感を出す
      if (r % 3 === 1) {
        state.objects.push(makeRock(1, start + r * gap + viewH * 0.03));
      }
    }
  }

  function makeRock(lane, y) {
    return {
      kind: "rock",
      lane,
      y,
      hp: CONFIG.rockHp,
      maxHp: CONFIG.rockHp,
      cracked: 0,
      gone: false,
      radius: rockRadius(),
    };
  }

  function makeItem(type, lane, y) {
    return {
      kind: "item",
      type,
      lane,
      y,
      gone: false,
      radius: itemRadius(),
      bob: Math.random() * Math.PI * 2,
    };
  }

  function occupiedLanes(bandY) {
    const set = new Set();
    for (const o of state.objects) {
      if (o.gone) continue;
      if (Math.abs(o.y - bandY) < viewH * 0.18) set.add(o.lane);
    }
    return set;
  }

  function randomFreeLane(bandY) {
    const used = occupiedLanes(bandY);
    const free = [];
    for (let i = 0; i < CONFIG.lanes; i++) if (!used.has(i)) free.push(i);
    if (!free.length) return -1;
    if (used.size >= 2 && Math.random() < 0.7) {
      const empty = free;
      return empty[(Math.random() * empty.length) | 0];
    }
    return free[(Math.random() * free.length) | 0];
  }

  function maybeSpawn(dt) {
    if (isFrozen()) return; // 流れ停止中は新規出現なし（画面上の岩・アイテムを処理する時間）
    if (state.progress > 0.9) return;
    // 山場中は通常スポーンを抑える（ボス波が主役）
    if (state._bossSpawned && state.progress < 0.88) {
      state._spawnAcc = (state._spawnAcc || 0) + dt;
      if (state._spawnAcc < 0.55) return;
      state._spawnAcc = 0;
      const y = state.boatY + viewH * 0.55 + Math.random() * viewH * 0.15;
      const lane = Math.random() < 0.7 ? (Math.random() < 0.5 ? 0 : 2) : 1;
      state.objects.push(makeRock(lane, y));
      return;
    }
    state._spawnAcc = (state._spawnAcc || 0) + dt;
    const interval = 1.05;
    if (state._spawnAcc < interval) return;
    state._spawnAcc = 0;
    // 船の前方（下側）に生成。くるっぱが下へ進んで追いつく
    const y = state.boatY + viewH * 0.42 + Math.random() * viewH * 0.2;
    const lane = randomFreeLane(y);
    if (lane < 0) return;
    const roll = Math.random();
    if (state.time < 3500) {
      if (roll < 0.55) state.objects.push(makeItem(pickItem(), lane, y));
      else state.objects.push(makeRock(lane, y));
      return;
    }
    if (roll < 0.22) state.objects.push(makeItem(pickItem(), lane, y));
    else state.objects.push(makeRock(lane, y));
  }

  function pickItem() {
    const bag = ["yakitori", "ramen", "flag"];
    return bag[(Math.random() * bag.length) | 0];
  }

  function collect(obj) {
    if (obj.gone) return;
    obj.gone = true;
    state.collected[obj.type] += 1;
    state.totalItems += 1;
    burst(laneX(obj.lane), obj.y, itemColor(obj.type), 18);
    speakGet(obj.type);
    playCollect(obj.type);
    if (obj.type === "yakitori") state.freezeUntil = now() + CONFIG.freezeMs;
    if (obj.type === "ramen") state.invUntil = now() + CONFIG.invincibleMs;
    if (obj.type === "flag") {
      state.waterUntil = now() + CONFIG.waterGunMs;
      fireWater();
    }
    try {
      navigator.vibrate && navigator.vibrate(18);
    } catch (_) {}
  }

  function fireWater() {
    state.waterShots.push({
      x: state.boatX,
      y: state.boatY + 40,
      life: CONFIG.waterGunMs,
    });
    playWater();
  }

  function damageRock(rock, amount, auto) {
    if (rock.gone) return;
    rock.hp -= amount;
    rock.cracked += 1;
    burst(laneX(rock.lane), rock.y, "#cfd8dc", auto ? 8 : 14);
    playSmash();
    if (rock.hp <= 0) {
      rock.gone = true;
      state.smashed += 1;
      burst(laneX(rock.lane), rock.y, "#fff59d", 22);
      try {
        navigator.vibrate && navigator.vibrate([12, 20, 12]);
      } catch (_) {}
    }
  }

  function hitRock(rock) {
    if (rock.gone || isInvincible() || isDizzy()) return;
    rock.gone = true;
    state.hits += 1;
    state.dizzyUntil = now() + CONFIG.dizzyMs;
    state.boatWobble = 1;
    burst(laneX(rock.lane), rock.y, "#ffcc80", 16);
    playDizzy();
    try {
      navigator.vibrate && navigator.vibrate([30, 40, 30]);
    } catch (_) {}
  }

  function frontRock() {
    const zone = smashZone();
    const reachX = charW() * 0.85;
    let best = null;
    let bestY = Infinity;
    for (const o of state.objects) {
      if (o.gone || o.kind !== "rock") continue;
      if (o.y < zone.top || o.y > zone.bottom) continue;
      if (Math.abs(laneX(o.lane) - state.boatX) > reachX) continue;
      // 船に最も近い岩 = y が最小
      if (o.y < bestY) {
        best = o;
        bestY = o.y;
      }
    }
    return best;
  }

  function rockAt(x, y) {
    let best = null;
    let bestD = Infinity;
    for (const o of state.objects) {
      if (o.gone || o.kind !== "rock") continue;
      const dx = x - laneX(o.lane);
      const dy = y - o.y;
      const d = dx * dx + dy * dy;
      const reach = o.radius + Math.max(28, charW() * 0.55);
      if (d < reach * reach && d < bestD) {
        best = o;
        bestD = d;
      }
    }
    return best;
  }

  function itemAt(x, y) {
    for (const o of state.objects) {
      if (o.gone || o.kind !== "item") continue;
      const dx = x - laneX(o.lane);
      const dy = y - o.y;
      if (dx * dx + dy * dy < (o.radius + 22) ** 2) return o;
    }
    return null;
  }

  function onTap(x, y) {
    if (state.mode !== "play") return;
    const item = itemAt(x, y);
    if (item) {
      collect(item);
      return;
    }
    // 1タップで必ず壊す（岩の上を直接タップ、または正面の岩）
    const rock = rockAt(x, y) || frontRock();
    if (rock) {
      state.comboTap += 1;
      damageRock(rock, Math.max(rock.hp, CONFIG.rockHp), false);
      splash(x, y);
      return;
    }
    splash(x, y);
  }

  function splash(x, y) {
    state.splashes.push({ x, y, life: 280 });
  }

  function burst(x, y, color, n) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 40 + Math.random() * 180;
      state.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - 40,
        life: 420 + Math.random() * 280,
        color,
        r: 3 + Math.random() * 5,
      });
    }
  }

  function spawnConfetti() {
    state.confetti = [];
    for (let i = 0; i < 90; i++) {
      state.confetti.push({
        x: Math.random() * viewW,
        y: -20 - Math.random() * viewH * 0.4,
        vx: -40 + Math.random() * 80,
        vy: 80 + Math.random() * 160,
        rot: Math.random() * 6,
        vr: -4 + Math.random() * 8,
        color: ["#ffd54f", "#ef5350", "#42a5f5", "#66bb6a", "#ab47bc", "#fff"][
          (Math.random() * 6) | 0
        ],
        w: 8 + Math.random() * 10,
        h: 12 + Math.random() * 10,
      });
    }
  }

  function reachGoal() {
    if (state.mode === "goal") return;
    state.mode = "goal";
    state.progress = 1;
    state.dizzyUntil = 0;
    spawnConfetti();
    playFanfare();
    const n = state.totalItems;
    goalScoreEl.textContent = `めいぶつ ${n}こ ゲット！`;
    goalUi.classList.remove("hidden");
  }

  function update(dtMs) {
    const dt = Math.min(0.05, dtMs / 1000);
    state.time += dtMs;
    state.targetX = clampBoatX(state.targetX);
    state.boatX += (state.targetX - state.boatX) * Math.min(1, dt * 14);
    state.boatWobble *= Math.pow(0.15, dt);

    if (state.mode === "title") {
      state.boatY = boatYStart();
      state.riverOffset -= 28 * dt;
      return;
    }

    if (state.mode === "goal") {
      state.boatY = boatYEnd();
      state.riverOffset -= 18 * dt;
      state.medalSpin += dt * 2.2;
      updateFx(dt, dtMs);
      for (const c of state.confetti) {
        c.x += c.vx * dt;
        c.y += c.vy * dt;
        c.rot += c.vr * dt;
        if (c.y > viewH + 20) c.y = -20;
      }
      return;
    }

    // めまい中は流れも止まる。やきとり中も流れだけ止まる（操作・タップは可能）
    const frozen = isFrozen();
    const speedMul = isDizzy() || frozen ? 0 : 1;
    const scroll = CONFIG.baseSpeed * speedMul;
    // 景色は上方向へ流れる（船が下へ進む見え方）— 停止中は動かない
    state.riverOffset -= scroll * dt;
    const goalDist = CONFIG.baseSpeed * (CONFIG.durationMs / 1000);
    const prevBoatY = state.boatY;
    if (!frozen && !isDizzy()) {
      state.progress = Math.min(1, state.progress + (scroll * dt) / goalDist);
    }
    // くるっぱ自身が上→下へ移動（進行の見え方の本体）
    state.boatY = boatYAt(state.progress);
    const dBoat = state.boatY - prevBoatY;

    if (state.progress >= CONFIG.bossProgress) spawnBossWave();

    maybeSpawn(dt);

    for (const o of state.objects) {
      if (o.gone) continue;
      // 船の下方向移動に合わせてワールドをずらし、相対的に前方（下）から近づける
      o.y += dBoat;
      o.y -= scroll * dt;
      if (o.kind === "item") {
        const dx = state.boatX - laneX(o.lane);
        const dy = o.y - (state.boatY + 10);
        if (dx * dx + dy * dy < (o.radius + charW() * 0.38) ** 2) collect(o);
      } else if (o.kind === "rock") {
        const dx = state.boatX - laneX(o.lane);
        if (
          isInvincible() &&
          Math.abs(dx) < charW() * 0.55 &&
          o.y > state.boatY &&
          o.y < smashZone().bottom
        ) {
          damageRock(o, 8, true);
        }
        const dy = o.y - state.boatY;
        if (!isInvincible() && !isDizzy() && dx * dx + dy * dy < (o.radius + charW() * 0.32) ** 2) {
          hitRock(o);
        }
      }
      if (o.y < -80 || o.y > viewH + 160) o.gone = true;
    }

    for (const shot of state.waterShots) {
      shot.y += 520 * dt;
      shot.life -= dtMs;
      for (const o of state.objects) {
        if (o.gone || o.kind !== "rock") continue;
        if (Math.abs(laneX(o.lane) - shot.x) > charW() * 0.7) continue;
        if (Math.abs(o.y - shot.y) < 70) damageRock(o, 8, true);
      }
    }
    state.waterShots = state.waterShots.filter((s) => s.life > 0 && s.y < viewH + 40);
    state.objects = state.objects.filter((o) => !o.gone);

    updateFx(dt, dtMs);

    if (AUTO_GOAL && state.time > 400) reachGoal();
    else if (state.progress >= 1) reachGoal();
  }

  function updateFx(dt, dtMs) {
    for (const p of state.particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 220 * dt;
      p.life -= dtMs;
    }
    state.particles = state.particles.filter((p) => p.life > 0);
    for (const s of state.splashes) s.life -= dtMs;
    state.splashes = state.splashes.filter((s) => s.life > 0);
  }

  function itemColor(type) {
    if (type === "yakitori") return "#bf360c";
    if (type === "ramen") return "#fb8c00";
    return "#3949ab";
  }

  function speakGet(type) {
    state._toast = { text: `${ITEM_LABELS[type]} ゲット！`, until: now() + 1400 };
  }

  /* ---------- audio ---------- */
  function ensureAudio() {
    if (audio) return audio;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    audio = { ctx: new AC(), bgm: true };
    return audio;
  }

  function beep(freq, dur, type, gain) {
    const a = ensureAudio();
    if (!a) return;
    const o = a.ctx.createOscillator();
    const g = a.ctx.createGain();
    o.type = type || "sine";
    o.frequency.value = freq;
    g.gain.value = gain || 0.06;
    g.gain.exponentialRampToValueAtTime(0.001, a.ctx.currentTime + dur);
    o.connect(g).connect(a.ctx.destination);
    o.start();
    o.stop(a.ctx.currentTime + dur);
  }

  function playCollect(type) {
    beep(type === "flag" ? 392 : 523, 0.09, "triangle", 0.07);
    setTimeout(() => beep(784, 0.12, "triangle", 0.06), 80);
  }
  function playSmash() {
    beep(180, 0.07, "square", 0.04);
  }
  function playDizzy() {
    beep(220, 0.18, "sawtooth", 0.03);
    setTimeout(() => beep(180, 0.2, "sawtooth", 0.03), 120);
  }
  function playWater() {
    beep(660, 0.16, "sine", 0.05);
    beep(880, 0.2, "sine", 0.04);
  }
  function playFanfare() {
    [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => beep(f, 0.22, "triangle", 0.07), i * 140));
  }
  function tickBgm() {
    const a = audio;
    if (!a || state.mode !== "play" || isDizzy()) return;
    if (!a.nextNote) a.nextNote = 0;
    if (state.time < a.nextNote) return;
    const notes = [392, 440, 494, 523, 587, 523, 494, 440];
    a.i = (a.i || 0) + 1;
    beep(notes[a.i % notes.length], 0.18, "sine", 0.025);
    a.nextNote = state.time + (isFrozen() ? 420 : 340);
  }

  /* ---------- draw ---------- */
  function roundRect(x, y, w, h, r) {
    const rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }

  function drawSky() {
    const g = ctx.createLinearGradient(0, 0, 0, viewH);
    g.addColorStop(0, "#87e0ff");
    g.addColorStop(0.38, "#4fc3f7");
    g.addColorStop(1, "#0288d1");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, viewW, viewH);
  }

  function drawBanks() {
    ctx.fillStyle = "#8bc34a";
    ctx.beginPath();
    ctx.moveTo(0, 0);
    for (let y = 0; y <= viewH; y += 16) {
      const wiggle = Math.sin((y + state.riverOffset) * 0.02) * 10;
      ctx.lineTo(viewW * 0.13 + wiggle, y);
    }
    ctx.lineTo(0, viewH);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(viewW, 0);
    for (let y = 0; y <= viewH; y += 16) {
      const wiggle = Math.sin((y + state.riverOffset) * 0.02 + 1.2) * 10;
      ctx.lineTo(viewW * 0.87 + wiggle, y);
    }
    ctx.lineTo(viewW, viewH);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#689f38";
    const treeSpan = viewH + 80;
    for (let i = 0; i < 12; i++) {
      const raw = i * 90 + state.riverOffset * 0.4;
      const y = ((raw % treeSpan) + treeSpan) % treeSpan - 40;
      ctx.beginPath();
      ctx.ellipse(22, y, 16, 28, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(viewW - 22, y + 20, 16, 28, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawRiver() {
    const g = ctx.createLinearGradient(viewW * 0.15, 0, viewW * 0.85, 0);
    g.addColorStop(0, "#26c6da");
    g.addColorStop(0.5, "#29b6f6");
    g.addColorStop(1, "#26c6da");
    ctx.fillStyle = g;
    ctx.fillRect(viewW * 0.1, 0, viewW * 0.8, viewH);

    ctx.strokeStyle = "rgba(255,255,255,0.28)";
    ctx.lineWidth = 3;
    for (let i = 0; i < 7; i++) {
      ctx.beginPath();
      const x = viewW * (0.22 + i * 0.09);
      for (let y = 0; y <= viewH; y += 10) {
        const xx = x + Math.sin((y + state.riverOffset) * 0.03 + i) * 8;
        if (y === 0) ctx.moveTo(xx, y);
        else ctx.lineTo(xx, y);
      }
      ctx.stroke();
    }

    if (state.progress > 0.82 || state.mode === "goal") drawSuitengu();
  }

  function drawSuitengu() {
    const appear = state.mode === "goal" ? 1 : Math.min(1, (state.progress - 0.82) / 0.18);
    const baseY = viewH - 130;
    const y = baseY + (1 - appear) * 80; // 下からせり上がる
    ctx.save();
    ctx.globalAlpha = 0.4 + appear * 0.6;
    ctx.fillStyle = "#c62828";
    roundRect(viewW / 2 - 70, y + 40, 140, 70, 8);
    ctx.fill();
    ctx.fillStyle = "#b71c1c";
    ctx.beginPath();
    ctx.moveTo(viewW / 2 - 88, y + 48);
    ctx.lineTo(viewW / 2, y);
    ctx.lineTo(viewW / 2 + 88, y + 48);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#fff8e1";
    ctx.font = `bold ${Math.round(viewW * 0.045)}px sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText("すいてんぐう", viewW / 2, y + 82);
    ctx.restore();
  }


  function drawRock(o) {
    const x = laneX(o.lane);
    const k = 1 - o.hp / o.maxHp;
    ctx.save();
    ctx.translate(x, o.y);
    ctx.rotate(Math.sin(o.y * 0.02) * 0.05);
    ctx.fillStyle = k > 0.5 ? "#90a4ae" : "#78909c";
    ctx.beginPath();
    ctx.ellipse(0, 8, o.radius * 1.05, o.radius * 0.72, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#607d8b";
    ctx.beginPath();
    ctx.ellipse(-6, -4, o.radius * 0.82, o.radius * 0.7, -0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.28)";
    ctx.beginPath();
    ctx.ellipse(-14, -12, 8, 5, -0.4, 0, Math.PI * 2);
    ctx.fill();
    if (k > 0.15) {
      ctx.strokeStyle = "#455a64";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-o.radius * 0.4, -6);
      ctx.lineTo(4, 10);
      ctx.lineTo(o.radius * 0.35, -2);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawItem(o) {
    const x = laneX(o.lane);
    const bob = Math.sin(state.time * 0.006 + o.bob) * 5;
    ctx.save();
    ctx.translate(x, o.y + bob);
    // ラーメン・やきとりはひと回り大きく
    const base = o.type === "ramen" || o.type === "yakitori" ? 8.5 : 16;
    const s = o.radius / base;
    ctx.scale(s, s);
    ctx.shadowColor = "rgba(255,255,255,0.8)";
    ctx.shadowBlur = 10;
    if (o.type === "yakitori") drawYakitori();
    else if (o.type === "ramen") drawRamen();
    else drawFlag();
    ctx.restore();
  }

  function drawYakitori() {
    // 串
    ctx.strokeStyle = "#5d4037";
    ctx.lineWidth = 3.5;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(0, 26);
    ctx.lineTo(0, -24);
    ctx.stroke();

    // 肉・ねぎを交互に
    const pieces = [
      { y: -14, meat: true },
      { y: -2, meat: false },
      { y: 10, meat: true },
      { y: 20, meat: false },
    ];
    for (const p of pieces) {
      if (p.meat) {
        const g = ctx.createLinearGradient(-10, p.y, 10, p.y);
        g.addColorStop(0, "#5d2910");
        g.addColorStop(0.45, "#c45c26");
        g.addColorStop(1, "#8d3b16");
        ctx.fillStyle = g;
        roundRect(-11, p.y - 6, 22, 12, 4);
        ctx.fill();
        ctx.fillStyle = "rgba(255,224,178,0.35)";
        roundRect(-8, p.y - 4, 8, 5, 2);
        ctx.fill();
      } else {
        ctx.fillStyle = "#fff8e1";
        roundRect(-9, p.y - 5, 18, 10, 3);
        ctx.fill();
        ctx.fillStyle = "#ffcc80";
        roundRect(-9, p.y - 1, 18, 3, 1);
        ctx.fill();
      }
    }

    // ラベル
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    roundRect(-24, -40, 48, 16, 8);
    ctx.fill();
    ctx.fillStyle = "#bf360c";
    ctx.font = "bold 11px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("やきとり", 0, -32);
    ctx.textBaseline = "alphabetic";
  }

  function drawRamen() {
    // どんぶり
    ctx.fillStyle = "#f5f5f5";
    ctx.beginPath();
    ctx.ellipse(0, 16, 28, 10, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#eeeeee";
    ctx.beginPath();
    ctx.moveTo(-26, 14);
    ctx.quadraticCurveTo(-30, 28, 0, 32);
    ctx.quadraticCurveTo(30, 28, 26, 14);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#bdbdbd";
    ctx.lineWidth = 2;
    ctx.stroke();

    // スープ（とんこつ）
    ctx.fillStyle = "#f0c27a";
    ctx.beginPath();
    ctx.ellipse(0, 10, 24, 9, 0, 0, Math.PI * 2);
    ctx.fill();

    // めん
    ctx.strokeStyle = "#ffe082";
    ctx.lineWidth = 2.5;
    for (let i = -3; i <= 3; i++) {
      ctx.beginPath();
      ctx.moveTo(-14, 4 + i * 2.2);
      ctx.quadraticCurveTo(0, 10 + i * 2.2, 14, 4 + i * 2.2);
      ctx.stroke();
    }

    // チャーシュー
    ctx.fillStyle = "#8d4a2b";
    ctx.beginPath();
    ctx.ellipse(-8, 6, 9, 5, -0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#c9784a";
    ctx.beginPath();
    ctx.ellipse(-8, 5, 5, 2.5, -0.3, 0, Math.PI * 2);
    ctx.fill();

    // なると
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(10, 5, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ef5350";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(10, 5, 3.2, 0, Math.PI * 2);
    ctx.stroke();

    // ねぎ
    ctx.fillStyle = "#81c784";
    ctx.fillRect(-2, 0, 5, 3);
    ctx.fillRect(2, 8, 4, 2);

    // 湯気
    ctx.strokeStyle = "rgba(255,255,255,0.85)";
    ctx.lineWidth = 2;
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 10, -2);
      ctx.quadraticCurveTo(i * 10 + 4, -10, i * 10, -18);
      ctx.stroke();
    }

    // ラベル（子ども向け）
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    roundRect(-22, -34, 44, 16, 8);
    ctx.fill();
    ctx.fillStyle = "#e65100";
    ctx.font = "bold 11px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("らーめん", 0, -26);
    ctx.textBaseline = "alphabetic";
  }

  function drawFlag() {
    ctx.strokeStyle = "#5d4037";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(-6, 22);
    ctx.lineTo(-6, -20);
    ctx.stroke();
    ctx.fillStyle = "#1a237e";
    ctx.beginPath();
    ctx.moveTo(-4, -20);
    ctx.lineTo(22, -10);
    ctx.lineTo(-4, 2);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    for (let i = 0; i < 4; i++) {
      ctx.fillRect(0 + (i % 2) * 6, -16 + i * 4, 5, 2);
    }
  }

  function pickKuruppaSprite() {
    if (isDizzy()) return kuruppaImg.dizzy;
    if (state.mode === "goal" || state.mode === "title") return kuruppaImg.yay;
    if (isInvincible() || isFrozen()) return kuruppaImg.smile;
    if (state._toast && now() < state._toast.until) return kuruppaImg.happy;
    return kuruppaImg.sit;
  }

  function drawRaft(dw, dh) {
    // いかだ（丸太4本を縦に並べる）— キャラより大きくはみ出して「乗っている」と分かるように
    const top = dh * 0.02;
    const bottom = dh * 0.58;
    const logH = (bottom - top) / 4.1;
    const halfW = dw * 0.78;

    // 水面の影
    ctx.fillStyle = "rgba(0,40,80,0.22)";
    ctx.beginPath();
    ctx.ellipse(0, bottom + 8, halfW * 1.05, dh * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();

    // 丸太（横長の筒を縦に4本）
    for (let i = 0; i < 4; i++) {
      const cy = top + logH * (i + 0.5);
      const g = ctx.createLinearGradient(-halfW, cy, halfW, cy);
      g.addColorStop(0, "#5d4037");
      g.addColorStop(0.2, "#a1887f");
      g.addColorStop(0.5, "#8d6e63");
      g.addColorStop(0.8, "#6d4c41");
      g.addColorStop(1, "#3e2723");
      ctx.fillStyle = g;
      roundRect(-halfW, cy - logH * 0.42, halfW * 2, logH * 0.84, logH * 0.4);
      ctx.fill();
      // 木目
      ctx.strokeStyle = "rgba(62,39,35,0.45)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(-halfW * 0.7, cy - 2);
      ctx.lineTo(halfW * 0.7, cy + 2);
      ctx.stroke();
      // 丸太の端（切り口）
      ctx.fillStyle = "#bcaaa4";
      ctx.beginPath();
      ctx.ellipse(-halfW, cy, logH * 0.28, logH * 0.38, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(halfW, cy, logH * 0.28, logH * 0.38, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#6d4c41";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(-halfW, cy, logH * 0.12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(halfW, cy, logH * 0.12, 0, Math.PI * 2);
      ctx.stroke();
    }

    // しばったロープ（前後）
    ctx.strokeStyle = "#efebe9";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-halfW * 0.92, top + logH * 0.15);
    ctx.lineTo(-halfW * 0.92, bottom - logH * 0.15);
    ctx.moveTo(halfW * 0.92, top + logH * 0.15);
    ctx.lineTo(halfW * 0.92, bottom - logH * 0.15);
    ctx.stroke();
    ctx.strokeStyle = "#d7ccc8";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(-halfW * 0.85, top + logH);
    ctx.lineTo(halfW * 0.85, top + logH);
    ctx.moveTo(-halfW * 0.85, bottom - logH);
    ctx.lineTo(halfW * 0.85, bottom - logH);
    ctx.stroke();

    // 小さなオール（いかだ感の補強）
    ctx.strokeStyle = "#5d4037";
    ctx.lineWidth = 4;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(halfW * 0.55, top + 4);
    ctx.lineTo(halfW * 1.15, top - dh * 0.18);
    ctx.stroke();
    ctx.fillStyle = "#795548";
    ctx.beginPath();
    ctx.ellipse(halfW * 1.18, top - dh * 0.2, dw * 0.12, dh * 0.06, 0.6, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawKuruppa() {
    const dizzy = isDizzy();
    const img = pickKuruppaSprite();
    const x = state.boatX + Math.sin(state.time * 0.02) * (dizzy ? 6 : 1.5);
    const y = state.boatY + Math.sin(state.time * 0.005) * 3;
    const dw = charW();
    const ratio = img.naturalHeight && img.naturalWidth ? img.naturalHeight / img.naturalWidth : 1.16;
    const dh = dw * ratio;
    ctx.save();
    ctx.translate(x, y);
    if (dizzy) ctx.rotate(Math.sin(state.time * 0.03) * 0.16);

    drawRaft(dw, dh);

    if (isInvincible()) {
      ctx.strokeStyle = "rgba(255,236,140,0.85)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.ellipse(0, -dh * 0.06, dw * 0.62, dh * 0.58, 0, 0, Math.PI * 2);
      ctx.stroke();
    }

    // キャラを少し上にずらして、いかだが足元からはみ出して見えるように
    if (img.complete && img.naturalWidth) {
      ctx.drawImage(img, -dw / 2, -dh * 0.72, dw, dh);
    }

    if (dizzy) {
      ctx.fillStyle = "#ffd54f";
      ctx.font = `${Math.round(dw * 0.22)}px sans-serif`;
      ctx.textAlign = "center";
      for (let i = 0; i < 3; i++) {
        const a = state.time * 0.008 + i * 2.1;
        ctx.fillText("★", Math.cos(a) * dw * 0.55, -dh * 0.7 + Math.sin(a) * 6);
      }
    }
    ctx.restore();

    if (hasWater()) drawWaterBeam();
    if (isFrozen()) {
      // 流れ停止中：静かさの演出（速度線の代わりに波紋）
      ctx.strokeStyle = "rgba(227,242,253,0.85)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) {
        const r = 18 + i * 10 + (state.time * 0.02) % 10;
        ctx.beginPath();
        ctx.arc(state.boatX, state.boatY + 20, r, 0.15 * Math.PI, 0.85 * Math.PI);
        ctx.stroke();
      }
    }
  }

  function drawWaterBeam() {
    const x = state.boatX;
    const g = ctx.createLinearGradient(x, state.boatY, x, viewH);
    g.addColorStop(0, "rgba(178,245,255,0.9)");
    g.addColorStop(1, "rgba(178,245,255,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x - 6, state.boatY + 22);
    ctx.lineTo(x + 6, state.boatY + 22);
    ctx.lineTo(x + 14, viewH);
    ctx.lineTo(x - 14, viewH);
    ctx.closePath();
    ctx.fill();
  }


  function drawHud() {
    const pad = Math.max(12, viewW * 0.03);
    const top = Math.max(10, 18);
    ctx.save();
    roundRect(pad, top, viewW - pad * 2, 58, 18);
    ctx.fillStyle = "rgba(255,255,255,0.86)";
    ctx.fill();
    ctx.fillStyle = "#1565c0";
    ctx.font = `bold ${Math.round(viewW * 0.045)}px sans-serif`;
    ctx.textAlign = "left";
    ctx.fillText(`🍢${state.collected.yakitori}  🍜${state.collected.ramen}  🎏${state.collected.flag}`, pad + 14, top + 36);

    const barX = pad + 14;
    const barY = top + 46;
    const barW = viewW - pad * 2 - 28;
    roundRect(barX, barY, barW, 8, 4);
    ctx.fillStyle = "#bbdefb";
    ctx.fill();
    roundRect(barX, barY, Math.max(8, barW * state.progress), 8, 4);
    ctx.fillStyle = "#ffb300";
    ctx.fill();
    ctx.restore();

    // プレイ中は案内テキストを出さない（スタート画面でルール説明済み）
    // バフ中は見た目だけで伝える（くるっぱの表情・光・静止波紋）
    if (state.mode === "play" && isDizzy()) {
      ctx.fillStyle = "rgba(255, 236, 179, 0.12)";
      ctx.fillRect(0, 0, viewW, viewH);
    }
    if (state.mode === "play" && isFrozen()) {
      ctx.fillStyle = "rgba(179, 229, 252, 0.16)";
      ctx.fillRect(0, 0, viewW, viewH);
    }
  }

  function drawFx() {
    for (const p of state.particles) {
      ctx.globalAlpha = Math.max(0, p.life / 500);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    for (const s of state.splashes) {
      ctx.globalAlpha = Math.max(0, s.life / 280);
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(s.x, s.y, 18 + (280 - s.life) * 0.08, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    if (state.mode === "goal") {
      for (const c of state.confetti) {
        ctx.save();
        ctx.translate(c.x, c.y);
        ctx.rotate(c.rot);
        ctx.fillStyle = c.color;
        ctx.fillRect(-c.w / 2, -c.h / 2, c.w, c.h);
        ctx.restore();
      }
    }
  }

  function drawTitleKuruppa() {
    state.boatX = viewW / 2;
    state.targetX = state.boatX;
    state.boatY = boatYStart();
    drawKuruppa();
  }

  function frame(ts) {
    if (!running) return;
    if (!lastTs) lastTs = ts;
    const dt = Math.min(50, ts - lastTs);
    lastTs = ts;
    update(dt);
    tickBgm();
    drawSky();
    drawBanks();
    drawRiver();
    for (const o of state.objects) {
      if (o.kind === "rock") drawRock(o);
      else drawItem(o);
    }
    if (state.mode === "title") drawTitleKuruppa();
    else drawKuruppa();
    drawFx();
    if (state.mode !== "title") drawHud();
    requestAnimationFrame(frame);
  }

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    viewW = window.innerWidth;
    viewH = window.innerHeight;
    canvas.width = Math.round(viewW * dpr);
    canvas.height = Math.round(viewH * dpr);
    canvas.style.width = `${viewW}px`;
    canvas.style.height = `${viewH}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    state.boatY = boatYBase();
    if (state.mode === "title") {
      state.boatX = viewW / 2;
      state.targetX = state.boatX;
    } else {
      state.targetX = clampBoatX(state.targetX);
      state.boatX = clampBoatX(state.boatX);
    }
  }

  function startGame() {
    ensureAudio();
    if (audio && audio.ctx.state === "suspended") audio.ctx.resume();
    startUi.classList.add("hidden");
    goalUi.classList.add("hidden");
    resetPlay();
  }

  function bindInput() {
    const el = canvas;
    const pos = (ev) => {
      const r = canvas.getBoundingClientRect();
      return { x: ev.clientX - r.left, y: ev.clientY - r.top };
    };
    const nudgeStep = () => Math.max(28, viewW * 0.08);
    el.addEventListener(
      "pointerdown",
      (ev) => {
        el.setPointerCapture(ev.pointerId);
        const p = pos(ev);
        input.down = true;
        input.id = ev.pointerId;
        input.startX = p.x;
        input.startY = p.y;
        input.lastX = p.x;
        input.swiped = false;
        if (state.mode === "play" && !isDizzy()) {
          state.targetX = clampBoatX(p.x);
        }
        ev.preventDefault();
      },
      { passive: false }
    );
    el.addEventListener(
      "pointermove",
      (ev) => {
        if (!input.down || ev.pointerId !== input.id) return;
        const p = pos(ev);
        const dx = p.x - input.startX;
        const dy = p.y - input.startY;
        if (Math.abs(dx) > 28) input.swiped = true; // 横にしっかり動かしたときだけ「移動」
        if (state.mode === "play" && !isDizzy()) {
          state.targetX = clampBoatX(p.x);
        }
        input.lastX = p.x;
        ev.preventDefault();
      },
      { passive: false }
    );
    const up = (ev) => {
      if (!input.down || (ev.pointerId && ev.pointerId !== input.id)) return;
      const p = pos(ev);
      if (state.mode === "play") {
        // 岩の上／正面なら、少し指がずれても1タップ破壊する
        const canSmash = rockAt(p.x, p.y) || frontRock();
        if (!input.swiped || canSmash) onTap(p.x, p.y);
      }
      input.down = false;
    };
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    window.addEventListener("keydown", (ev) => {
      if (state.mode !== "play") return;
      if (ev.key === "ArrowLeft" || ev.key === "a") {
        state.targetX = clampBoatX(state.targetX - nudgeStep());
      }
      if (ev.key === "ArrowRight" || ev.key === "d") {
        state.targetX = clampBoatX(state.targetX + nudgeStep());
      }
      if (ev.key === " " || ev.key === "Enter") onTap(state.boatX, smashZone().top + 40);
    });
  }

  startBtn.addEventListener("click", startGame);
  againBtn.addEventListener("click", startGame);
  window.addEventListener("resize", resize);
  window.addEventListener("orientationchange", () => setTimeout(resize, 200));

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) running = false;
    else if (!running) {
      running = true;
      lastTs = 0;
      requestAnimationFrame(frame);
    }
  });

  window.__KURUPPA__ = {
    getState: () => ({
      mode: state.mode,
      progress: state.progress,
      lane: state.lane,
      boatX: state.boatX,
      targetX: state.targetX,
      rockHp: CONFIG.rockHp,
      items: { ...state.collected },
      totalItems: state.totalItems,
      smashed: state.smashed,
      hits: state.hits,
      dizzy: isDizzy(),
      invincible: isInvincible(),
      frozen: isFrozen(),
      objectCount: state.objects.length,
      boatY: state.boatY,
      viewH: viewH,
      viewW: viewW,
      riverLeft: riverLeft(),
      riverRight: riverRight(),
      bossSpawned: !!state._bossSpawned,
    }),
    start: startGame,
    tap: () => onTap(state.boatX, smashZone().top + 40),
    swipe: (dir) => {
      const step = Math.max(36, viewW * 0.12);
      state.targetX = clampBoatX(state.targetX + (dir < 0 ? -step : step));
      state.boatX = state.targetX;
    },
    setX: (x) => {
      state.targetX = clampBoatX(x);
      state.boatX = state.targetX;
    },
    give: (type) => collect(makeItem(type, state.lane, state.boatY + 90)),
    spawnRockInFront: () => {
      // 船の正面（現在Xに最も近いレーン）に岩を出す
      let nearest = 1;
      let best = Infinity;
      for (let i = 0; i < CONFIG.lanes; i++) {
        const d = Math.abs(laneX(i) - state.boatX);
        if (d < best) {
          best = d;
          nearest = i;
        }
      }
      const rock = makeRock(nearest, smashZone().top + 50);
      state.objects.push(rock);
      return true;
    },
    smashFront: () => {
      const rock = frontRock();
      if (rock) damageRock(rock, 9, false);
    },
    forceHit: () => {
      let nearest = 1;
      let best = Infinity;
      for (let i = 0; i < CONFIG.lanes; i++) {
        const d = Math.abs(laneX(i) - state.boatX);
        if (d < best) {
          best = d;
          nearest = i;
        }
      }
      const rock = makeRock(nearest, state.boatY);
      hitRock(rock);
    },
    forceGoal: reachGoal,
    setProgress: (p) => {
      state.progress = Math.max(0, Math.min(1, p));
      if (state.mode === "play" || state.mode === "goal") state.boatY = boatYAt(state.progress);
      if (state.mode === "play" && state.progress >= CONFIG.bossProgress) spawnBossWave();
    },
  };

  resize();
  bindInput();
  running = true;
  requestAnimationFrame(frame);

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
})();

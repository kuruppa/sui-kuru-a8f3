# X固定ポスト用 画像生成プロンプト

> 用途：こいこいのX固定ポストに添付する画像1枚
> 世界観：静か・誠実・余白多め・煽らない
> 配色：落ち着いたグリーン系（ヘッダーと揃える）

---

## 推奨プロンプト（日本語・そのまま使える）

```
X（Twitter）の投稿用画像を作成してください。横長（16:9）または正方形（1:1）。

【デザイン】
- 落ち着いたグリーンのグラデーション背景（明るめ〜淡い緑、清潔感）
- 余白を多めに。シンプルで誠実な印象
- 中央に日本語テキストを配置（読みやすく、大きめ）
- フォントは明朝体または上品なゴシック。装飾は最小限
- ビジネス煽り・ネオン・紫のグラデーション・キラキラ・バッジ・FOLLOW MEボタンは禁止

【テキスト（メイン）】
違和感を、自分で決めた道に変える

【テキスト（サブ・小さめ・任意）】
納得して選べる働き方を

【トーン】
静か、誠実、余白、信頼感。コーチングブランドのヘッダー画像のような上品さ。
```

---

## 推奨プロンプト（英語・Midjourney / DALL·E向け）

```
Create a clean social media post image for X (Twitter), 16:9 landscape or 1:1 square.

Design:
- Soft muted green gradient background (fresh, calm, professional)
- Lots of white space, minimal, sincere, not salesy
- Centered Japanese typography, large and highly readable
- Elegant serif or refined sans-serif font
- No neon, no purple gradients, no glitter, no badges, no "FOLLOW ME" buttons, no hype graphics

Main text (exact Japanese):
違和感を、自分で決めた道に変える

Optional small subtitle (exact Japanese):
納得して選べる働き方を

Mood: quiet, trustworthy, coaching brand header style, calm atmosphere
```

---

## サブコピー違いのバリエーション

### A. タグライン重視（推奨・プロフヘッダーと一致）
メイン：`違和感を、自分で決めた道に変える`
サブ：なし、または `納得して選べる働き方を`

### B. 思想フック重視
メイン：`他人の正解より、自分の納得を`
サブ：`働き方コーチ・こいこい`

### C. 最短
メインだけ：`自分で決めた働き方へ`
（テキスト少なめ・余白最大）

---

## 生成時の指定（共通）

- サイズ：X投稿向けなら **16:9** または **1:1**
- 文字は**必ず正確な日本語**で（誤字・文字化け禁止）
- 人物写真・イラストキャラは不要（テキスト＋背景のみでOK）
- ロゴや顔写真は入れない

---

## 完成チェック

- [ ] スマホで文字が読めるか
- [ ] 煽り感がないか
- [ ] ヘッダー（緑）とトーンが揃っているか
- [ ] メイン文言が1つに絞れているか
- [ ] CTA（登録！等）が画像内に入っていないか（CTAは投稿本文のリンク）

#!/usr/bin/env node
"use strict";

import puppeteer from "puppeteer-core";

const BASE = process.env.GAME_URL || "http://127.0.0.1:8765/index.html";
const CHROME = process.env.CHROME_PATH || "/usr/bin/google-chrome";

function assert(cond, msg) {
  if (!cond) throw new Error(msg);
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: "new",
    args: ["--no-sandbox", "--disable-gpu", "--window-size=390,844"],
    defaultViewport: { width: 390, height: 844, isMobile: true, hasTouch: true },
  });
  const page = await browser.newPage();
  await page.goto(BASE, { waitUntil: "networkidle0", timeout: 20000 });

  const title = await page.title();
  assert(title.includes("スイスイくるっぱ"), `title was ${title}`);

  await page.click("#start-btn");
  await page.waitForFunction(() => window.__KURUPPA__ && window.__KURUPPA__.getState().mode === "play");

  const afterStart = await page.evaluate(() => window.__KURUPPA__.getState());
  assert(afterStart.mode === "play", "did not enter play");
  assert(afterStart.lane === 1, "should start in center lane");

  await page.evaluate(() => window.__KURUPPA__.swipe(1));
  const afterSwipe = await page.evaluate(() => window.__KURUPPA__.getState());
  assert(afterSwipe.lane === 2, `swipe right failed, lane=${afterSwipe.lane}`);

  await page.evaluate(() => window.__KURUPPA__.forceHit());
  const afterHit = await page.evaluate(() => window.__KURUPPA__.getState());
  assert(afterHit.dizzy, "rock hit should make kuruppa dizzy");
  assert(afterHit.mode === "play", "dizzy must not be game over");
  assert(afterHit.hits === 1, "hit counter should increase");

  await page.evaluate(() => window.__KURUPPA__.give("strawberry"));
  await page.evaluate(() => window.__KURUPPA__.give("ramen"));
  await page.evaluate(() => window.__KURUPPA__.give("flag"));
  const afterItems = await page.evaluate(() => window.__KURUPPA__.getState());
  assert(afterItems.totalItems === 3, `items=${afterItems.totalItems}`);
  assert(afterItems.invincible, "ramen should grant invincible");
  assert(afterItems.fast, "strawberry should grant speed");

  await page.evaluate(() => window.__KURUPPA__.forceGoal());
  await page.waitForSelector("#goal-ui:not(.hidden)");
  const goalText = await page.$eval("#goal-score", (el) => el.textContent);
  assert(goalText.includes("3"), `goal score text=${goalText}`);
  const afterGoal = await page.evaluate(() => window.__KURUPPA__.getState());
  assert(afterGoal.mode === "goal", "should reach goal");

  await page.click("#again-btn");
  await page.waitForFunction(() => window.__KURUPPA__.getState().mode === "play" && window.__KURUPPA__.getState().totalItems === 0);
  const again = await page.evaluate(() => window.__KURUPPA__.getState());
  assert(again.mode === "play", "retry should return to play");
  assert(again.totalItems === 0, "retry should reset items");

  console.log("SMOKE OK", afterItems, goalText);
  await browser.close();
})().catch(async (err) => {
  console.error(err);
  process.exit(1);
});

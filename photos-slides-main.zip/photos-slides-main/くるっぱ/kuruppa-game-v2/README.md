# くるっぱアドベンチャー（久留米編）

## 起動方法

### いちばん簡単

1. **`start-server.bat`** をダブルクリック（ブラウザが自動で開きます）
2. 開かない場合は手動で **http://localhost:8877/** を開く

キャラ画像がないときは、先に **`copy-sprites.bat`** を実行してください。

### 手動（PowerShell）

```powershell
cd "c:\Users\newor\こいこい用\photos-slides\kuruppa-game-v2"
python -m http.server 8877 --directory .
```

ブラウザ: http://localhost:8877/

### 8766 が動かないとき

以前の説明で使った **8766** は、サーバーを起動していないと接続できません。  
修正版は **8877** を使います。古い黒い窓（ターミナル）が残っていたら閉じてから、`start-server.bat` を再度実行してください。

**注意:** `index.html` をエクスプローラーから直接開く（`file://`）と画像が読めないことがあります。必ず上記のようにローカルサーバー経由で開いてください。

## 原版

`../kuruppa-game/` が原版です（ポート 8765 など別ポートで起動可能）。

@echo off
chcp 65001 >nul
set "SRC=%~dp0..\kuruppa-game\sprites"
set "DST=%~dp0sprites"
if not exist "%SRC%" (
  echo 原版 sprites が見つかりません: %SRC%
  pause
  exit /b 1
)
if not exist "%DST%" mkdir "%DST%"
copy /Y "%SRC%\*.png" "%DST%\"
echo コピー完了:
dir /b "%DST%"
pause

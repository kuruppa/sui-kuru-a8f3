@echo off
chcp 65001 >nul
set "PORT=8877"
set "ROOT=%~dp0"
cd /d "%ROOT%"
echo.
echo  くるっぱアドベンチャー（久留米編）
echo  この窓を閉じるとゲームは止まります。
echo.
if not exist "%ROOT%sprites\kuruppa-stand.png" (
  echo [エラー] sprites フォルダに画像がありません。
  echo kuruppa-game\sprites から PNG をコピーしてください。
  pause
  exit /b 1
)
echo  起動中… ブラウザで次を開いてください:
echo  http://localhost:%PORT%/
echo.
start "" "http://localhost:%PORT%/"
python -m http.server %PORT% --directory "%ROOT%"
if errorlevel 1 (
  echo.
  echo Python が見つかりません。Python 3 をインストールしてください。
  pause
)

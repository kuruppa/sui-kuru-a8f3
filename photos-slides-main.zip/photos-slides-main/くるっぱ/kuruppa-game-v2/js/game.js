(() => {
  "use strict";

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const statusEl = document.getElementById("status");

  const W = canvas.width;
  const H = canvas.height;
  const GRAVITY = 0.62;
  const MOVE_SPEED = 4.6;
  const JUMP_VEL = -12.2;
  const WORLD_W = 3200;
  const GROUND_Y = H - 48;

  const keys = new Set();
  let jumpBuffer = 0;
  let loopRunning = false;
  let loaded = 0;

  const sprites = {
    stand: loadImage("sprites/kuruppa-stand.png"),
    walk: loadImage("sprites/kuruppa-walk.png"),
    jump: loadImage("sprites/kuruppa-jump.png"),
    front: loadImage("sprites/kuruppa-front.png"),
  };
  const needLoad = Object.keys(sprites).length;

  const inventory = { ramen: 0, yakitori: 0, udon: 0 };
  /** @type {Array<{type:string,x:number,y:number,vx:number,vy:number,life:number,w:number,h:number}>} */
  const projectiles = [];

  const solids = [
    { x: 0, y: GROUND_Y, w: WORLD_W, h: 48 },
    { x: 280, y: H - 128, w: 160, h: 24 },
    { x: 520, y: H - 200, w: 120, h: 24 },
    { x: 720, y: H - 160, w: 100, h: 24 },
    { x: 900, y: H - 240, w: 140, h: 24 },
    { x: 1120, y: H - 180, w: 120, h: 24 },
    { x: 1320, y: H - 280, w: 160, h: 24 },
    { x: 1560, y: H - 200, w: 100, h: 24 },
    { x: 1740, y: H - 320, w: 180, h: 24 },
    { x: 1980, y: H - 220, w: 120, h: 24 },
    { x: 2180, y: H - 160, w: 140, h: 24 },
    { x: 2420, y: H - 260, w: 160, h: 24 },
    { x: 2660, y: H - 180, w: 120, h: 24 },
    { x: 2860, y: H - 140, w: 200, h: 24 },
  ];

  const gaps = [
    { x: 640, w: 80 },
    { x: 1480, w: 96 },
    { x: 2280, w: 88 },
  ];

  /** @type {Array<{type:"ramen"|"yakitori"|"udon",x:number,y:number,r:number,taken:boolean}>} */
  const foodPickups = [
    { type: "ramen", x: 350, y: H - 175, r: 18, taken: false },
    { type: "yakitori", x: 780, y: H - 215, r: 18, taken: false },
    { type: "udon", x: 1150, y: H - 235, r: 18, taken: false },
    { type: "ramen", x: 1500, y: H - 255, r: 18, taken: false },
    { type: "yakitori", x: 1920, y: H - 175, r: 18, taken: false },
    { type: "udon", x: 2350, y: H - 315, r: 18, taken: false },
    { type: "ramen", x: 2700, y: H - 235, r: 18, taken: false },
  ];

  const droplets = [];
  for (let i = 0; i < 14; i++) {
    droplets.push({
      x: 180 + i * 200 + (i % 2) * 30,
      y: H - 95 - (i % 4) * 50,
      r: 11,
      taken: false,
    });
  }

  const enemies = [
    { x: 420, y: H - 88, w: 36, h: 36, vx: 1.4, alive: true },
    { x: 1050, y: H - 88, w: 36, h: 36, vx: -1.6, alive: true },
    { x: 1450, y: H - 88, w: 36, h: 36, vx: 1.3, alive: true },
    { x: 1850, y: H - 88, w: 36, h: 36, vx: 1.5, alive: true },
    { x: 2550, y: H - 88, w: 36, h: 36, vx: -1.3, alive: true },
    { x: 2920, y: H - 88, w: 36, h: 36, vx: 1.2, alive: true },
  ];

  const goal = { x: WORLD_W - 120, y: H - 200, w: 48, h: 152 };

  const player = {
    x: 64,
    y: H - 200,
    w: 52,
    h: 64,
    vx: 0,
    vy: 0,
    onGround: false,
    facing: 1,
    anim: 0,
    won: false,
    dead: false,
    attackCd: 0,
  };

  let cameraX = 0;
  let score = 0;
  let dropletCount = 0;

  const FOOD_LABEL = {
    ramen: "ラーメン",
    yakitori: "やきとり",
    udon: "うどん",
  };

  function loadImage(src) {
    const img = new Image();
    img.onload = () => {
      loaded += 1;
      if (loaded >= needLoad && !loopRunning) {
        loopRunning = true;
        statusEl.textContent =
          "水滴を集めてゴールへ！グルメを拾って 1・2・3 で攻撃";
        requestAnimationFrame(loop);
      }
    };
    img.onerror = () => {
      statusEl.textContent = "スプライトの読み込みに失敗しました。";
    };
    img.src = src;
    return img;
  }

  function resetGame() {
    player.x = 64;
    player.y = H - 200;
    player.vx = 0;
    player.vy = 0;
    player.onGround = false;
    player.facing = 1;
    player.won = false;
    player.dead = false;
    player.attackCd = 0;
    cameraX = 0;
    score = 0;
    dropletCount = 0;
    jumpBuffer = 0;
    inventory.ramen = 0;
    inventory.yakitori = 0;
    inventory.udon = 0;
    projectiles.length = 0;
    for (const d of droplets) d.taken = false;
    for (const f of foodPickups) f.taken = false;
    for (const e of enemies) e.alive = true;
    statusEl.textContent =
      "水滴を集めてゴールへ！グルメを拾って 1・2・3 で攻撃";
  }

  function isJumpKey(key, code) {
    return (
      key === " " ||
      key === "ArrowUp" ||
      key === "w" ||
      key === "W" ||
      code === "Space" ||
      code === "ArrowUp" ||
      code === "KeyW"
    );
  }

  window.addEventListener(
    "keydown",
    (e) => {
      const moveKeys = [
        "ArrowLeft",
        "ArrowRight",
        "ArrowUp",
        " ",
        "a",
        "d",
        "w",
        "A",
        "D",
        "W",
      ];
      if (moveKeys.includes(e.key) || isJumpKey(e.key, e.code)) {
        e.preventDefault();
      }
      if (e.key === "r" || e.key === "R") resetGame();
      if (isJumpKey(e.key, e.code)) jumpBuffer = 12;
      if (e.key === "1") tryAttack("ramen");
      if (e.key === "2") tryAttack("yakitori");
      if (e.key === "3") tryAttack("udon");
      keys.add(e.key);
      if (e.code) keys.add(e.code);
    },
    { passive: false }
  );

  window.addEventListener("keyup", (e) => {
    keys.delete(e.key);
    if (e.code) keys.delete(e.code);
  });

  function isDown(...names) {
    return names.some((k) => keys.has(k));
  }

  function wantsMoveLeft() {
    return isDown("ArrowLeft", "a", "A", "KeyA");
  }

  function wantsMoveRight() {
    return isDown("ArrowRight", "d", "D", "KeyD");
  }

  function rectOverlap(a, b) {
    return (
      a.x < b.x + b.w &&
      a.x + a.w > b.x &&
      a.y < b.y + b.h &&
      a.y + a.h > b.y
    );
  }

  function inGap(x, w) {
    const cx = x + w / 2;
    return gaps.some((g) => cx > g.x && cx < g.x + g.w);
  }

  function resolveAxis(entity, solidsList, axis) {
    for (const s of solidsList) {
      if (!rectOverlap(entity, s)) continue;
      if (axis === "x") {
        if (entity.vx > 0) entity.x = s.x - entity.w;
        else if (entity.vx < 0) entity.x = s.x + s.w - entity.w;
        entity.vx = 0;
      } else if (entity.vy > 0) {
        entity.y = s.y - entity.h;
        entity.vy = 0;
        entity.onGround = true;
      } else if (entity.vy < 0) {
        entity.y = s.y + s.h;
        entity.vy = 0;
      }
    }
  }

  function tryJump() {
    if (jumpBuffer <= 0 || !player.onGround || player.won || player.dead) {
      return;
    }
    player.vy = JUMP_VEL;
    player.onGround = false;
    jumpBuffer = 0;
  }

  function tryAttack(type) {
    if (player.won || player.dead || player.attackCd > 0) return;
    if (inventory[type] <= 0) {
      statusEl.textContent = `${FOOD_LABEL[type]}を持っていません`;
      return;
    }
    inventory[type] -= 1;
    player.attackCd = 18;
    const cx = player.x + player.w / 2;
    const cy = player.y + player.h / 2;
    const dir = player.facing;

    if (type === "ramen") {
      projectiles.push({
        type: "ramen",
        x: cx + dir * 20,
        y: cy - 8,
        vx: dir * 9,
        vy: -1,
        life: 45,
        w: 56,
        h: 28,
      });
    } else if (type === "yakitori") {
      projectiles.push({
        type: "yakitori",
        x: cx + dir * 24,
        y: cy - 4,
        vx: dir * 11,
        vy: -2.5,
        life: 55,
        w: 40,
        h: 12,
      });
    } else if (type === "udon") {
      projectiles.push({
        type: "udon",
        x: cx + dir * 30,
        y: cy,
        vx: dir * 6,
        vy: 0,
        life: 28,
        w: 90,
        h: 36,
      });
    }
    statusEl.textContent = `${FOOD_LABEL[type]}で攻撃！`;
  }

  function updatePlayer() {
    if (player.won || player.dead) return;

    player.onGround = false;

    if (wantsMoveLeft()) {
      player.vx = -MOVE_SPEED;
      player.facing = -1;
    } else if (wantsMoveRight()) {
      player.vx = MOVE_SPEED;
      player.facing = 1;
    } else {
      player.vx *= 0.72;
      if (Math.abs(player.vx) < 0.15) player.vx = 0;
    }

    player.vy += GRAVITY;
    player.x += player.vx;
    resolveAxis(player, solids, "x");
    player.y += player.vy;
    resolveAxis(player, solids, "y");

    if (player.x < 0) player.x = 0;
    if (player.x + player.w > WORLD_W) player.x = WORLD_W - player.w;

    const footY = player.y + player.h;
    if (footY >= GROUND_Y && !inGap(player.x, player.w)) {
      player.y = GROUND_Y - player.h;
      player.vy = 0;
      player.onGround = true;
    }

    tryJump();
    if (jumpBuffer > 0) jumpBuffer -= 1;

    if (player.y > H + 40) {
      player.dead = true;
      statusEl.textContent = "筑後川に落ちちゃった… R でリトライ";
    }

    if (Math.abs(player.vx) > 0.3 && player.onGround) player.anim += 0.18;
    if (player.attackCd > 0) player.attackCd -= 1;

    for (const d of droplets) {
      if (d.taken) continue;
      const dx = player.x + player.w / 2 - d.x;
      const dy = player.y + player.h / 2 - d.y;
      if (dx * dx + dy * dy < (d.r + 22) ** 2) {
        d.taken = true;
        dropletCount += 1;
        score += 10;
      }
    }

    for (const f of foodPickups) {
      if (f.taken) continue;
      const dx = player.x + player.w / 2 - f.x;
      const dy = player.y + player.h / 2 - f.y;
      if (dx * dx + dy * dy < (f.r + 24) ** 2) {
        f.taken = true;
        inventory[f.type] += 1;
        score += 15;
        statusEl.textContent = `${FOOD_LABEL[f.type]}をゲット！（${inventory[f.type]}個）`;
      }
    }

    for (const e of enemies) {
      if (!e.alive) continue;
      if (!rectOverlap(player, e)) continue;
      const stomp = player.vy > 0 && player.y + player.h - e.y < e.h * 0.55;
      if (stomp) {
        e.alive = false;
        player.vy = JUMP_VEL * 0.55;
        score += 25;
      } else {
        player.dead = true;
        statusEl.textContent = "くるっぱがやられた… R でリトライ";
      }
    }

    if (rectOverlap(player, goal)) {
      player.won = true;
      statusEl.textContent = `ゴール！スコア ${score} — R でもう一度`;
    }
  }

  function updateProjectiles() {
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const p = projectiles[i];
      p.life -= 1;
      p.x += p.vx;
      p.y += p.vy;
      if (p.type === "yakitori") p.vy += 0.18;
      if (p.type === "ramen") p.vy += 0.05;

      const box = { x: p.x, y: p.y, w: p.w, h: p.h };
      for (const e of enemies) {
        if (!e.alive) continue;
        const eb = { x: e.x, y: e.y, w: e.w, h: e.h };
        if (rectOverlap(box, eb)) {
          e.alive = false;
          score += 30;
          p.life = 0;
          break;
        }
      }
      if (p.life <= 0 || p.x < -80 || p.x > WORLD_W + 80) {
        projectiles.splice(i, 1);
      }
    }
  }

  function updateEnemies() {
    for (const e of enemies) {
      if (!e.alive) continue;
      e.x += e.vx;
      const box = { x: e.x, y: e.y, w: e.w, h: e.h };
      let hit = false;
      for (const s of solids) {
        if (rectOverlap(box, s)) hit = true;
      }
      if (hit || e.x < 40 || e.x > WORLD_W - 60) {
        e.vx *= -1;
        e.x += e.vx * 2;
      }
    }
  }

  function updateCamera() {
    const target = player.x + player.w / 2 - W / 2;
    cameraX += (target - cameraX) * 0.12;
    cameraX = Math.max(0, Math.min(cameraX, WORLD_W - W));
  }

  function drawKurumeBackground() {
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#5eb0e8");
    sky.addColorStop(0.45, "#9ed4f5");
    sky.addColorStop(0.72, "#d4e8c8");
    sky.addColorStop(1, "#8fbc6a");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    const parallax = (factor) => -cameraX * factor;

    ctx.save();
    ctx.translate(parallax(0.08), 0);

    ctx.fillStyle = "rgba(255,255,255,0.5)";
    for (let i = 0; i < 5; i++) {
      const cx = (i * 200 + 60) % (W + 120);
      ctx.beginPath();
      ctx.ellipse(cx, 55 + i * 10, 55, 20, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.15), 0);
    drawMinoRange(80, H - 200, 420, 200);
    drawMinoRange(520, H - 220, 380, 210);
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.28), 0);
    drawMinoRange(-40, H - 170, 500, 165);
    ctx.fillStyle = "rgba(45,90,50,0.35)";
    ctx.fillRect(0, H - 120, W + 200, 80);
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.42), 0);
    const riverY = H - 72;
    const riverGrad = ctx.createLinearGradient(0, riverY - 30, 0, riverY + 40);
    riverGrad.addColorStop(0, "#4a9fd4");
    riverGrad.addColorStop(0.5, "#2e7eb8");
    riverGrad.addColorStop(1, "#1a5f8f");
    ctx.fillStyle = riverGrad;
    ctx.beginPath();
    ctx.moveTo(-20, riverY);
    for (let x = 0; x <= W + 40; x += 60) {
      const wave = Math.sin((x + cameraX * 0.5) * 0.04) * 6;
      ctx.lineTo(x, riverY + wave);
    }
    ctx.lineTo(W + 40, H);
    ctx.lineTo(-20, H);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 2;
    for (let x = 0; x < W; x += 80) {
      const y = riverY + Math.sin((x + cameraX) * 0.08) * 4;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + 25, y - 6, x + 50, y);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(30,80,50,0.5)";
    ctx.fillRect(0, riverY + 8, W, 24);
    ctx.restore();

    ctx.fillStyle = "#6a9e4a";
    ctx.fillRect(0, GROUND_Y, W, H - GROUND_Y);
    ctx.fillStyle = "#5a8e3a";
    for (let x = -(cameraX % 36); x < W; x += 36) {
      ctx.fillRect(x, GROUND_Y, 32, 6);
    }

    ctx.fillStyle = "rgba(0,0,0,0.12)";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("耳納連山", 24 + parallax(0.15), H - 215);
    ctx.fillText("筑後川", 24 + parallax(0.42), H - 88);
  }

  function drawMinoRange(ox, baseY, width, height) {
    const peaks = [
      { x: 0.15, h: 0.95 },
      { x: 0.35, h: 0.75 },
      { x: 0.55, h: 1 },
      { x: 0.72, h: 0.7 },
      { x: 0.88, h: 0.85 },
    ];
    const grad = ctx.createLinearGradient(ox, baseY - height, ox, baseY);
    grad.addColorStop(0, "#6b8f71");
    grad.addColorStop(0.4, "#4d7356");
    grad.addColorStop(1, "#3a5c44");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(ox, baseY);
    for (const p of peaks) {
      ctx.lineTo(ox + width * p.x, baseY - height * p.h);
    }
    ctx.lineTo(ox + width, baseY);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.55)";
    ctx.beginPath();
    ctx.moveTo(ox + width * 0.5, baseY - height);
    ctx.lineTo(ox + width * 0.58, baseY - height * 0.72);
    ctx.lineTo(ox + width * 0.48, baseY - height * 0.78);
    ctx.closePath();
    ctx.fill();
  }

  function drawJojimaTile(x, y, w, h) {
    const tileW = 28;
    const rows = Math.ceil(h / 12);
    for (let row = 0; row < rows; row++) {
      const ty = y + row * 12;
      const rowH = Math.min(12, y + h - ty);
      for (let tx = x; tx < x + w; tx += tileW) {
        const tw = Math.min(tileW, x + w - tx);
        const base = row % 2 === 0 ? "#4a4f58" : "#3d424a";
        ctx.fillStyle = base;
        ctx.fillRect(tx, ty, tw, rowH);
        ctx.fillStyle = "#5c6370";
        ctx.beginPath();
        ctx.arc(tx + tw / 2, ty, tw / 2, Math.PI, 0);
        ctx.fill();
        ctx.strokeStyle = "#2e3339";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(tx + tw / 2, ty, tw / 2 - 1, Math.PI, 0);
        ctx.stroke();
        ctx.fillStyle = "rgba(255,255,255,0.08)";
        ctx.fillRect(tx + 2, ty + 2, tw - 4, rowH - 3);
      }
    }
    ctx.strokeStyle = "#2a2e34";
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
  }

  function drawWaterDrop(cx, cy, r) {
    const bob = Math.sin(Date.now() * 0.007 + cx) * 2.5;
    const y = cy + bob;
    ctx.save();
    ctx.translate(cx, y);
    const grad = ctx.createRadialGradient(-r * 0.2, -r * 0.3, 1, 0, 0, r * 1.4);
    grad.addColorStop(0, "#e8f7ff");
    grad.addColorStop(0.35, "#6ecfff");
    grad.addColorStop(0.75, "#2e8fd4");
    grad.addColorStop(1, "#1a6fa8");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, -r * 1.3);
    ctx.bezierCurveTo(r * 0.9, -r * 0.2, r * 0.75, r * 0.85, 0, r);
    ctx.bezierCurveTo(-r * 0.75, r * 0.85, -r * 0.9, -r * 0.2, 0, -r * 1.3);
    ctx.fill();
    ctx.strokeStyle = "#1565a0";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.65)";
    ctx.beginPath();
    ctx.ellipse(-r * 0.25, -r * 0.35, r * 0.22, r * 0.35, -0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawWorld() {
    ctx.save();
    ctx.translate(-cameraX, 0);

    for (const g of gaps) {
      const water = ctx.createLinearGradient(g.x, GROUND_Y, g.x, H);
      water.addColorStop(0, "#3d8ec4");
      water.addColorStop(1, "#1e5f8a");
      ctx.fillStyle = water;
      ctx.fillRect(g.x, GROUND_Y, g.w, H - GROUND_Y);
    }

    for (const s of solids) {
      if (s.y >= GROUND_Y) continue;
      drawJojimaTile(s.x, s.y, s.w, s.h);
    }

    for (const d of droplets) {
      if (d.taken) continue;
      drawWaterDrop(d.x, d.y, d.r);
    }

    for (const f of foodPickups) {
      if (f.taken) continue;
      drawFoodPickup(f);
    }

    for (const p of projectiles) drawProjectile(p);

    for (const e of enemies) {
      if (!e.alive) continue;
      ctx.fillStyle = "#5d4037";
      ctx.fillRect(e.x, e.y, e.w, e.h);
      ctx.fillStyle = "#fff";
      ctx.fillRect(e.x + 8, e.y + 10, 8, 8);
      ctx.fillRect(e.x + 20, e.y + 10, 8, 8);
    }

    const poleX = goal.x + goal.w / 2;
    ctx.fillStyle = "#666";
    ctx.fillRect(poleX - 3, goal.y, 6, goal.h);
    ctx.fillStyle = player.won ? "#43a047" : "#e53935";
    ctx.beginPath();
    ctx.moveTo(poleX + 3, goal.y + 12);
    ctx.lineTo(poleX + 52, goal.y + 36);
    ctx.lineTo(poleX + 3, goal.y + 60);
    ctx.closePath();
    ctx.fill();

    drawPlayer();
    ctx.restore();
  }

  function drawFoodPickup(f) {
    const bob = Math.sin(Date.now() * 0.005 + f.x) * 3;
    const y = f.y + bob;
    ctx.save();
    ctx.translate(f.x, y);
    if (f.type === "ramen") {
      ctx.fillStyle = "#f5e6c8";
      ctx.beginPath();
      ctx.ellipse(0, 4, 16, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#c45c26";
      ctx.fillRect(-14, -8, 28, 14);
      ctx.fillStyle = "#ffd54f";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("ラ", 0, 2);
    } else if (f.type === "yakitori") {
      ctx.strokeStyle = "#5d4037";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-14, 8);
      ctx.lineTo(14, -8);
      ctx.stroke();
      ctx.fillStyle = "#c45c26";
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath();
        ctx.arc(i * 9 - 2, i * 4 - 2, 6, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (f.type === "udon") {
      ctx.fillStyle = "#efe0c8";
      ctx.beginPath();
      ctx.ellipse(0, 6, 18, 11, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#d4a574";
      ctx.lineWidth = 2;
      for (let i = -2; i <= 2; i++) {
        ctx.beginPath();
        ctx.moveTo(-12 + i * 5, -2);
        ctx.quadraticCurveTo(-8 + i * 5, 10, -4 + i * 5, 4);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  function drawProjectile(p) {
    ctx.save();
    ctx.translate(p.x, p.y);
    if (p.facing !== undefined) {
      /* noop */
    }
    if (p.type === "ramen") {
      ctx.fillStyle = "rgba(196,92,38,0.85)";
      ctx.beginPath();
      ctx.ellipse(p.w / 2, p.h / 2, p.w / 2, p.h / 2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffeb3b";
      ctx.font = "bold 14px sans-serif";
      ctx.fillText("汁", p.w / 2 - 7, p.h / 2 + 5);
    } else if (p.type === "yakitori") {
      ctx.strokeStyle = "#4e342e";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, p.h);
      ctx.lineTo(p.w, 0);
      ctx.stroke();
      ctx.fillStyle = "#bf360c";
      ctx.beginPath();
      ctx.arc(p.w - 6, 4, 8, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.type === "udon") {
      ctx.fillStyle = "rgba(239,224,200,0.9)";
      ctx.fillRect(0, 0, p.w, p.h);
      ctx.strokeStyle = "#bc8f5e";
      ctx.lineWidth = 2;
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(8 + i * 16, 4);
        ctx.quadraticCurveTo(20 + i * 16, p.h, 12 + i * 16, p.h - 4);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  function drawPlayer() {
    let img = sprites.stand;
    if (!player.onGround) img = sprites.jump;
    else if (Math.abs(player.vx) > 0.3) {
      img = Math.floor(player.anim) % 2 === 0 ? sprites.walk : sprites.stand;
    }
    if (player.won) img = sprites.front;

    const scale = player.h / (img.naturalHeight || 200);
    const dw = (img.naturalWidth || 180) * scale;
    const dh = player.h;
    const dx = player.x + (player.w - dw) / 2;
    const dy = player.y + player.h - dh;

    ctx.save();
    if (player.facing < 0) {
      ctx.translate(dx + dw, dy);
      ctx.scale(-1, 1);
      ctx.drawImage(img, 0, 0, dw, dh);
    } else {
      ctx.drawImage(img, dx, dy, dw, dh);
    }
    ctx.restore();
  }

  function drawHud() {
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(12, 12, 280, 92);
    ctx.fillStyle = "#fff";
    ctx.font = "bold 15px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(`水滴: ${dropletCount}  スコア: ${score}`, 24, 36);
    ctx.font = "13px sans-serif";
    ctx.fillText(
      `🍜${inventory.ramen}  🍢${inventory.yakitori}  🍥${inventory.udon}`,
      24,
      58
    );
    ctx.fillText("攻撃: 1=ラーメン 2=やきとり 3=うどん", 24, 78);
    ctx.font = "bold 14px sans-serif";
    ctx.fillText(
      player.won ? "クリア！" : player.dead ? "…" : "がんばれ！",
      24,
      96
    );
  }

  function loop() {
    if (!loopRunning || loaded < needLoad) return;
    updatePlayer();
    updateProjectiles();
    updateEnemies();
    updateCamera();
    drawKurumeBackground();
    drawWorld();
    drawHud();
    requestAnimationFrame(loop);
  }

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) loopRunning = false;
    else if (loaded >= needLoad) {
      loopRunning = true;
      requestAnimationFrame(loop);
    }
  });
})();

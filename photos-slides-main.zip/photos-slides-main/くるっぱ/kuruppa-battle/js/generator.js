(function (KG) {
  var STAT_BASE = { hp: 55, atk: 50, def: 50, spd: 50 };

  function hashStr(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return Math.abs(h);
  }

  function pick(arr, seed) {
    return arr[seed % arr.length];
  }

  function clampStat(val) {
    return Math.max(20, Math.min(100, Math.round(val)));
  }

  function sumPowers(items) {
    var sum = { hp: 0, atk: 0, def: 0, spd: 0 };
    for (var i = 0; i < items.length; i++) {
      var p = items[i].power || {};
      sum.hp += p.hp || 0;
      sum.atk += p.atk || 0;
      sum.def += p.def || 0;
      sum.spd += p.spd || 0;
    }
    return sum;
  }

  function buildStatsFromItems(items) {
    var power = sumPowers(items);
    return {
      hp: clampStat(STAT_BASE.hp + power.hp),
      atk: clampStat(STAT_BASE.atk + power.atk),
      def: clampStat(STAT_BASE.def + power.def),
      spd: clampStat(STAT_BASE.spd + power.spd),
    };
  }

  function buildWeaponFromItem(item) {
    var cat = item.category || KG.categorizeSpecialty(item.label || item.text || "");
    var pool = KG.WEAPON_TEMPLATES[cat] || KG.WEAPON_TEMPLATES.food;
    var tmpl = pool[hashStr(item.label || item.text || "") % pool.length];
    var label = item.label || item.text;
    return {
      name: label + tmpl.suffix,
      desc: item.prDesc || tmpl.desc,
      type: cat,
    };
  }

  function buildTraitFromCharacter(traitsText) {
    var text = (traitsText || "").trim() || "明るく親しみやすいご当地キャラ";
    var effect = "guard";
    if (/元気|速|活発|アクティブ/.test(text)) effect = "speed";
    else if (/力強|パワ|熱/.test(text)) effect = "boost";
    else if (/優し|癒|温|やさ/.test(text)) effect = "heal";
    return {
      name: "キャラクター性",
      desc: text,
      effect: effect,
    };
  }

  function buildTraitFromItems(items) {
    var primary =
      items.find(function (i) { return i.kind === "名所"; }) ||
      items.find(function (i) { return i.kind === "名産"; }) ||
      items[0];
    var kind = (primary && primary.kind) || "その他";
    var base = KG.TRAIT_BY_KIND[kind] || KG.TRAIT_BY_KIND["その他"];
    var label = (primary && (primary.label || primary.text)) || "郷土";
    return {
      name: label + base.suffix,
      desc: base.desc,
      effect: base.effect,
    };
  }

  function buildWeaknessFromItems(items, seed) {
    var tmpl = pick(KG.WEAKNESS_TEMPLATES, seed);
    var last = items[items.length - 1];
    var cat = KG.categorizeSpecialty((last && (last.label || last.text)) || "");
    return { name: tmpl.name, desc: tmpl.desc, type: cat };
  }

  function powerFromKind(kind, text) {
    var seed = hashStr(kind + "-" + text);
    var bases = {
      名産: { hp: 4, atk: 10, def: 4, spd: 5 },
      名所: { hp: 6, atk: 6, def: 6, spd: 9 },
      特徴: { hp: 5, atk: 7, def: 8, spd: 7 },
      その他: { hp: 5, atk: 7, def: 5, spd: 6 },
    };
    var base = bases[kind] || bases["その他"];
    return {
      hp: base.hp + (seed % 4),
      atk: base.atk + ((seed >> 2) % 5),
      def: base.def + ((seed >> 4) % 4),
      spd: base.spd + ((seed >> 6) % 5),
    };
  }

  KG.buildChallengerProfile = function buildChallengerProfile(prInputs, meta) {
    var items = prInputs.map(function (input) {
      var text = input.text.trim();
      return {
        kind: input.kind,
        label: text,
        text: text,
        category: KG.categorizeSpecialty(text),
        prDesc: input.kind + "「" + text + "」のPR力",
        power: powerFromKind(input.kind, text),
      };
    });

    var seed = hashStr(meta.city + "|" + meta.name + "|" + items.map(function (i) { return i.label; }).join(","));

    return {
      name: meta.name.trim(),
      city: meta.city.trim(),
      iconUrl: meta.iconUrl || null,
      emoji: null,
      characterTraits: (meta.characterTraits || "").trim(),
      prItems: items,
      prLabels: items.map(function (i) { return i.kind + ":" + i.label; }),
      weapon: buildWeaponFromItem(items.find(function (i) { return i.kind === "名産"; }) || items[0]),
      trait: buildTraitFromCharacter(meta.characterTraits),
      weakness: buildWeaknessFromItems(items, seed),
      stats: buildStatsFromItems(items),
    };
  };

  KG.buildKuruppaProfile = function buildKuruppaProfile(hand) {
    var prItems = hand || KG.pickKuruppaPrHand(5);
    var seed = hashStr(prItems.map(function (i) { return i.id; }).join("|"));
    var weaponItem = prItems.find(function (i) { return i.kind === "名産"; }) || prItems[0];

    return {
      name: KG.KURUPPA_BASE.name,
      city: KG.KURUPPA_BASE.city,
      emoji: KG.KURUPPA_BASE.emoji,
      iconUrl: null,
      prItems: prItems,
      prLabels: prItems.map(function (i) { return i.kind + ":" + i.label; }),
      weapon: buildWeaponFromItem(weaponItem),
      trait: buildTraitFromItems(prItems),
      weakness: buildWeaknessFromItems(prItems, seed >> 3),
      stats: buildStatsFromItems(prItems),
    };
  };

  KG.analyzeDelay = function analyzeDelay(ms) {
    return new Promise(function (r) {
      setTimeout(r, ms || 1400);
    });
  };
})(window.KuruppaGame);

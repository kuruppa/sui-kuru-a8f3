(function (KG) {
  function createBattler(profile, side) {
    var maxHp = profile.stats.hp;
    return {
      side: side,
      profile: profile,
      hp: maxHp,
      maxHp: maxHp,
      buffs: { atk: 0, def: 0, spd: 0 },
    };
  }

  function effectiveStat(base, buff) {
    return Math.max(1, base + buff);
  }

  function calcDamage(attacker, defender, options) {
    options = options || {};
    var atk = effectiveStat(attacker.profile.stats.atk, attacker.buffs.atk);
    var def = effectiveStat(defender.profile.stats.def, defender.buffs.def);
    var raw = atk - def * 0.35 + (Math.random() * 12 - 4);
    if (options.weaknessHit) raw *= 1.45;
    if (options.critical) raw *= 1.25;
    return Math.max(3, Math.round(raw));
  }

  function rollTrait(battler) {
    var effect = battler.profile.trait.effect;
    var r = Math.random();

    if (effect === "speed" && r < 0.35) {
      battler.buffs.spd += 8;
      return { type: "trait", effect: "speed", value: 8 };
    }
    if (effect === "heal" && r < 0.28) {
      var heal = Math.round(battler.maxHp * 0.08);
      battler.hp = Math.min(battler.maxHp, battler.hp + heal);
      return { type: "trait", effect: "heal", value: heal };
    }
    if (effect === "counter" && r < 0.22) {
      return { type: "trait", effect: "counter", ready: true };
    }
    if (effect === "boost" && r < 0.3) {
      battler.buffs.atk += 10;
      return { type: "trait", effect: "boost", value: 10 };
    }
    if (effect === "guard" && r < 0.25) {
      return { type: "trait", effect: "guard", ready: true };
    }
    return null;
  }

  KG.createBattleState = function createBattleState(fighterA, fighterB) {
    return {
      a: createBattler(fighterA, "a"),
      b: createBattler(fighterB, "b"),
      turn: 0,
      maxTurns: 10,
    };
  };

  KG.executeTurn = function executeTurn(state, turnNum) {
    var a = state.a;
    var b = state.b;
    var first =
      effectiveStat(a.profile.stats.spd, a.buffs.spd) >=
      effectiveStat(b.profile.stats.spd, b.buffs.spd)
        ? a
        : b;
    var second = first === a ? b : a;
    var events = [];
    var pendingCounter = null;
    var pendingGuard = null;
    var order = [first, second];

    for (var i = 0; i < order.length; i++) {
      var actor = order[i];
      if (actor.hp <= 0) continue;
      var target = actor === a ? b : a;
      if (target.hp <= 0) continue;

      var traitEvent = rollTrait(actor);
      if (traitEvent) {
        traitEvent.actor = actor;
        traitEvent.turn = turnNum;
        events.push(traitEvent);
      }

      if (traitEvent && traitEvent.effect === "counter") pendingCounter = actor;
      if (traitEvent && traitEvent.effect === "guard") pendingGuard = actor;

      var weaknessHit = actor.profile.weapon.type === target.profile.weakness.type;
      var critical = Math.random() < 0.12;
      var damage = calcDamage(actor, target, { weaknessHit: weaknessHit, critical: critical });

      if (pendingGuard === target) {
        damage = Math.round(damage * 0.45);
        pendingGuard = null;
        events.push({ type: "guard", actor: target, turn: turnNum });
      }

      target.hp = Math.max(0, target.hp - damage);
      events.push({
        type: "attack",
        actor: actor,
        target: target,
        damage: damage,
        weaknessHit: weaknessHit,
        critical: critical,
        turn: turnNum,
      });

      if (pendingCounter === target && target.hp > 0) {
        var counterDmg = Math.round(calcDamage(target, actor) * 0.6);
        actor.hp = Math.max(0, actor.hp - counterDmg);
        events.push({
          type: "counter",
          actor: target,
          target: actor,
          damage: counterDmg,
          turn: turnNum,
        });
        pendingCounter = null;
      }
    }

    var winner = null;
    if (a.hp <= 0 && b.hp <= 0) winner = null;
    else if (a.hp <= 0) winner = b;
    else if (b.hp <= 0) winner = a;

    return { events: events, winner: winner, a: a, b: b };
  };
})(window.KuruppaGame);

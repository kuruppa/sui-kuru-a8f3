/** 久留米・くるっぱ PR合戦データ */
(function (KG) {
  KG.KURUPPA_BASE = {
    name: "くるっぱ",
    city: "福岡県久留米市",
    emoji: "🐸",
  };

  KG.KURUPPA_PR_POOL = [
    {
      id: "kurume-ramen",
      kind: "名産",
      label: "久留米ラーメン",
      category: "food",
      prDesc: "とんこつ発祥の地。呼び戻しスープの濃厚なコクで全国区のPR力",
      power: { hp: 6, atk: 14, def: 4, spd: 7 },
    },
    {
      id: "yakitori",
      kind: "名産",
      label: "焼き鳥（日本一の街）",
      category: "food",
      prDesc: "人口あたり店舗数日本トップクラス。ダルムも串に刺す久留米流の破壊力",
      power: { hp: 5, atk: 13, def: 3, spd: 10 },
    },
    {
      id: "kurume-gasuri",
      kind: "名産",
      label: "久留米絣",
      category: "craft",
      prDesc: "国指定重要無形文化財。太宰治も愛したかすれ模様の伝統美",
      power: { hp: 6, atk: 7, def: 12, spd: 5 },
    },
    {
      id: "chikugo-minou",
      kind: "名所",
      label: "筑後川・耳納連山",
      category: "nature",
      prDesc: "九州最大の河川と連山が織りなす、水と緑のシンボル",
      power: { hp: 12, atk: 8, def: 9, spd: 5 },
    },
    {
      id: "fruit-kingdom",
      kind: "名産",
      label: "フルーツ王国",
      category: "food",
      prDesc: "巨峰発祥の地。いちご・柿・梨・キウイ…四季の果実で魅了",
      power: { hp: 8, atk: 9, def: 5, spd: 9 },
    },
    {
      id: "sake-jojima",
      kind: "名産",
      label: "酒どころ（城島灘）",
      category: "food",
      prDesc: "良質な水と米が育む日本酒。城島酒蔵びらきの熱気で押し切る",
      power: { hp: 7, atk: 10, def: 7, spd: 6 },
    },
    {
      id: "suitengu",
      kind: "名所",
      label: "水天宮（全国総本宮）",
      category: "history",
      prDesc: "全国水天宮の総本宮。子授け・安産の信仰が築く揺るぎない守り",
      power: { hp: 10, atk: 5, def: 11, spd: 4 },
    },
    {
      id: "koura-taisha",
      kind: "名所",
      label: "高良大社",
      category: "history",
      prDesc: "筑後国一の宮。九州最大級の社殿と絶景夜景が相手を圧倒",
      power: { hp: 11, atk: 8, def: 10, spd: 6 },
    },
    {
      id: "bridgestone",
      kind: "名所",
      label: "ブリヂストン創業の地",
      category: "industry",
      prDesc: "世界的大企業発祥の街。石橋文化センターが放つものづくりと芸術の力",
      power: { hp: 8, atk: 11, def: 8, spd: 7 },
    },
    {
      id: "celebrities",
      kind: "特徴",
      label: "有名人輩出の街",
      category: "history",
      prDesc: "松田聖子、松本零士…信じられないほどのスターが生まれた文化の街",
      power: { hp: 6, atk: 10, def: 5, spd: 12 },
    },
  ];

  KG.pickKuruppaPrHand = function pickKuruppaPrHand(count) {
    const n = count || 5;
    const shuffled = KG.KURUPPA_PR_POOL.slice().sort(function () {
      return Math.random() - 0.5;
    });
    return shuffled.slice(0, n);
  };

  KG.PR_KINDS = ["名産", "名所", "その他"];

  KG.WEAPON_TEMPLATES = {
    food: [
      { suffix: "PRスマッシュ", desc: "名産の味覚で相手の注目を奪う" },
      { suffix: "グルメビーム", desc: "ご当地グルメの魅力を放射" },
    ],
    craft: [
      { suffix: "工芸アピール", desc: "伝統工芸の美しさで差をつける" },
      { suffix: "職人の一押し", desc: "匠の技で刺すようなPR" },
    ],
    nature: [
      { suffix: "自然パワー", desc: "名所の自然が相手を圧倒" },
      { suffix: "観光インパクト", desc: "行ってみたくなる破壊力" },
    ],
    festival: [{ suffix: "祭り仕込み", desc: "お祭りの熱気で会場を沸かす" }],
    history: [
      { suffix: "歴史解説", desc: "深い歴史で相手を説得" },
      { suffix: "文化遺産", desc: "登録文化財級の説得力" },
    ],
    industry: [{ suffix: "ものづくり", desc: "技術力で差をつける" }],
  };

  KG.TRAIT_BY_KIND = {
    名所: { effect: "speed", suffix: "観光旋風", desc: "名所の魅力で話題性が上昇" },
    名産: { effect: "boost", suffix: "特産ブースト", desc: "名産PRで攻撃力が上がる" },
    特徴: { effect: "guard", suffix: "キャラの魅力", desc: "ゆるキャラの愛嬌でダメージ軽減" },
    その他: { effect: "heal", suffix: "意外性", desc: "ひねりでHPを回復" },
  };

  KG.WEAKNESS_TEMPLATES = [
    { name: "知名度ギャップ", desc: "全国区の相手に押されやすい", type: "history" },
    { name: "情報不足", desc: "PR材料が少ないと弱体化", type: "industry" },
    { name: "マメ疲れ", desc: "長期戦で話題性が落ちる", type: "nature" },
  ];

  KG.SPECIALTY_KEYWORDS = {
    food: ["米", "うどん", "そば", "ラーメン", "明太子", "もち", "酒", "焼き", "肉", "魚", "果物", "茶", "スイーツ", "カレー", "パン", "巨峰", "キウイ", "いちご", "フルーツ", "日本酒", "酒蔵"],
    craft: ["陶", "染", "和紙", "漆", "織", "工芸", "ガラス", "木工", "絣"],
    nature: ["山", "海", "川", "温泉", "森林", "花", "公園", "水車", "筑後", "耳納"],
    festival: ["祭", "花火", "灯", "踊", "神輿", "酒蔵びらき"],
    history: ["城", "寺", "社", "宮", "史", "古", "遺跡", "伝統", "橋", "文化", "美術館"],
    industry: ["工場", "技術", "IT", "航空", "自動車", "半導体", "ブリヂストン", "タイヤ", "ものづくり"],
  };

  KG.categorizeSpecialty = function categorizeSpecialty(text) {
    var t = text.trim();
    var keys = Object.keys(KG.SPECIALTY_KEYWORDS);
    for (var i = 0; i < keys.length; i++) {
      var cat = keys[i];
      var words = KG.SPECIALTY_KEYWORDS[cat];
      for (var j = 0; j < words.length; j++) {
        if (t.indexOf(words[j]) !== -1) return cat;
      }
    }
    return "food";
  };
})(window.KuruppaGame = window.KuruppaGame || {});

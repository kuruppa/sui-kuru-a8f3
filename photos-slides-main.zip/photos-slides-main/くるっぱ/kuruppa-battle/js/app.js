(function () {
  "use strict";

  var KG = window.KuruppaGame;
  var MAX_PR_SLOTS = 5;

  var steps = {
    setup: document.getElementById("step-setup"),
    battle: document.getElementById("step-battle"),
    result: document.getElementById("step-result"),
  };

  var els = {
    form: document.getElementById("challenge-form"),
    chName: document.getElementById("ch-name"),
    chCity: document.getElementById("ch-city"),
    chTraits: document.getElementById("ch-traits"),
    chIcon: document.getElementById("ch-icon"),
    iconPreview: document.getElementById("icon-preview"),
    btnClearIcon: document.getElementById("btn-clear-icon"),
    prSlots: document.getElementById("pr-slots"),
    kuruppaPoolList: document.getElementById("kuruppa-pool-list"),
    btnDemo: document.getElementById("btn-demo"),
    arenaFighters: document.getElementById("arena-fighters"),
    battleStatus: document.getElementById("battle-status"),
    commentaryLog: document.getElementById("commentary-log"),
    turnLabel: document.getElementById("turn-label"),
    btnSkip: document.getElementById("btn-skip"),
    resultTitle: document.getElementById("result-title"),
    resultCard: document.getElementById("result-card"),
    shareText: document.getElementById("share-text"),
    btnCopy: document.getElementById("btn-copy"),
    btnRetry: document.getElementById("btn-retry"),
  };

  var iconUrl = null;
  var fighters = null;
  var battleState = null;
  var skipRequested = false;

  function showStep(name) {
    Object.keys(steps).forEach(function (key) {
      steps[key].classList.toggle("active", key === name);
    });
  }

  function readPrInputs() {
    var rows = els.prSlots.querySelectorAll(".pr-slot-row");
    var result = [];
    for (var i = 0; i < rows.length; i++) {
      var text = rows[i].querySelector(".pr-text").value.trim();
      if (text) {
        result.push({
          kind: rows[i].querySelector(".pr-kind").value,
          text: text,
        });
      }
    }
    return result.slice(0, MAX_PR_SLOTS);
  }

  function validateChallenge() {
    if (!els.chName.value.trim()) {
      alert("ゆるキャラ名を入力してください。");
      return false;
    }
    if (!els.chCity.value.trim()) {
      alert("自治体を入力してください。");
      return false;
    }
    if (!els.chTraits.value.trim()) {
      alert("キャラの性格・特徴を入力してください。");
      return false;
    }
    if (readPrInputs().length === 0) {
      alert("PR要素を1つ以上入力してください（最大5個）。");
      return false;
    }
    return true;
  }

  function renderAvatar(profile) {
    if (profile.iconUrl) {
      return '<img src="' + profile.iconUrl + '" alt="' + profile.name + '" class="avatar-img" />';
    }
    var initial = (profile.name || "?").charAt(0);
    return '<span class="avatar-initial">' + (profile.emoji || initial) + "</span>";
  }

  function renderPrTags(profile) {
    return (profile.prItems || [])
      .map(function (item) {
        return '<span class="pr-tag">' + item.kind + ":" + (item.label || item.text) + "</span>";
      })
      .join("");
  }

  function renderArenaBattler(battler) {
    var pct = Math.round((battler.hp / battler.maxHp) * 100);
    return (
      '<div class="arena-fighter side-' + battler.side + '" data-side="' + battler.side + '">' +
      '<div class="avatar">' + renderAvatar(battler.profile) + "</div>" +
      '<div class="name">' + battler.profile.name + "</div>" +
      '<div class="hp-wrap"><div class="hp-label">PR残量 ' + pct + "%</div>" +
      '<div class="hp-bar-bg"><div class="hp-bar" style="width:' + pct + '%"></div></div></div></div>'
    );
  }

  function updateArena() {
    els.arenaFighters.innerHTML =
      renderArenaBattler(battleState.a) +
      '<div class="arena-vs">VS</div>' +
      renderArenaBattler(battleState.b);
  }

  function appendCommentary(text, kind) {
    var p = document.createElement("p");
    p.className = "commentary-line" + (kind && kind !== "normal" ? " " + kind : "");
    p.textContent = text;
    els.commentaryLog.appendChild(p);
    els.commentaryLog.scrollTop = els.commentaryLog.scrollHeight;
  }

  function delay(ms) {
    return new Promise(function (r) {
      setTimeout(r, ms);
    });
  }

  function flashFighter(side, className) {
    var el = els.arenaFighters.querySelector('[data-side="' + side + '"]');
    if (!el) return;
    el.classList.add(className);
    setTimeout(function () {
      el.classList.remove(className);
    }, 400);
  }

  function showResult(winner, loser) {
    showStep("result");
    var isKuruppaWin = winner.profile.name === "くるっぱ";
    els.resultTitle.textContent = isKuruppaWin
      ? "くるっぱの守りが勝った！"
      : winner.profile.name + " がくるっぱに勝利！";
    els.resultCard.innerHTML =
      '<div class="result-avatar-wrap">' + renderAvatar(winner.profile) + "</div>" +
      '<p class="winner-name">' + winner.profile.name + "</p>" +
      '<p class="winner-city">' + winner.profile.city + "</p>" +
      '<div class="pr-tags">' + renderPrTags(winner.profile) + "</div>";
    els.shareText.value = KG.buildShareText(winner, loser, battleState.turn, fighters.a);
  }

  async function playBattle() {
    skipRequested = false;
    els.btnSkip.classList.remove("hidden");
    els.commentaryLog.innerHTML = "";
    els.battleStatus.textContent = "PR FIGHT!";

    var openLines = KG.openingCommentary(fighters.a, fighters.b);
    for (var i = 0; i < openLines.length; i++) {
      if (skipRequested) break;
      appendCommentary(openLines[i], i < 4 ? "highlight" : "normal");
      await delay(900);
    }

    while (battleState.turn < battleState.maxTurns) {
      if (skipRequested) break;

      battleState.turn += 1;
      els.turnLabel.textContent = "TURN " + battleState.turn + " / 10";
      var result = KG.executeTurn(battleState, battleState.turn);

      var attacks = result.events.filter(function (e) { return e.type === "attack"; });
      var lastAttack = attacks[attacks.length - 1];
      if (lastAttack) {
        flashFighter(lastAttack.actor.side, "attacking");
        flashFighter(lastAttack.target.side, "hit");
      }

      updateArena();

      var commLines = KG.commentaryForTurn(result, battleState.turn);
      for (var j = 0; j < commLines.length; j++) {
        if (skipRequested) break;
        appendCommentary(commLines[j].text, commLines[j].kind);
        await delay(800);
      }

      if (result.winner) {
        battleState.a.hp = result.a.hp;
        battleState.b.hp = result.b.hp;
        break;
      }

      await delay(500);
    }

    var winner =
      battleState.a.hp <= 0
        ? battleState.b
        : battleState.b.hp <= 0
          ? battleState.a
          : battleState.a.hp >= battleState.b.hp
            ? battleState.a
            : battleState.b;
    var loser = winner === battleState.a ? battleState.b : battleState.a;

    els.battleStatus.textContent = "PR WIN!";
    var closeLines = KG.closingCommentary(winner, loser);
    for (var k = 0; k < closeLines.length; k++) {
      appendCommentary(closeLines[k], "highlight");
      await delay(900);
    }

    if (skipRequested) {
      showResult(winner, loser);
      return;
    }

    await delay(600);
    showResult(winner, loser);
  }

  async function startFromForm(e) {
    if (e) e.preventDefault();
    if (!validateChallenge()) return;

    var kuruppaHand = KG.pickKuruppaPrHand(5);
    var challenger = KG.buildChallengerProfile(readPrInputs(), {
      name: els.chName.value,
      city: els.chCity.value,
      iconUrl: iconUrl,
      characterTraits: els.chTraits.value,
    });

    fighters = {
      a: KG.buildKuruppaProfile(kuruppaHand),
      b: challenger,
    };

    battleState = KG.createBattleState(fighters.a, fighters.b);
    showStep("battle");
    updateArena();
    els.turnLabel.textContent = "";
    els.battleStatus.textContent = "READY";
    await playBattle();
  }

  function loadDemo() {
    els.chName.value = "もっちー";
    els.chCity.value = "もちもち県もち市";
    els.chTraits.value = "粘り強くて明るい性格。もちもちボディがトレードマークで、地元の子どもに大人気。";
    iconUrl = null;
    els.iconPreview.innerHTML = "📷";
    els.btnClearIcon.classList.add("hidden");
    els.chIcon.value = "";

    var demoItems = [
      { kind: "名産", text: "もち" },
      { kind: "名所", text: "温泉街" },
      { kind: "名所", text: "山頂展望台" },
      { kind: "その他", text: "もち祭り" },
      { kind: "名産", text: "米" },
    ];
    var rows = els.prSlots.querySelectorAll(".pr-slot-row");
    for (var i = 0; i < rows.length; i++) {
      if (demoItems[i]) {
        rows[i].querySelector(".pr-kind").value = demoItems[i].kind;
        rows[i].querySelector(".pr-text").value = demoItems[i].text;
      } else {
        rows[i].querySelector(".pr-text").value = "";
      }
    }
  }

  function renderKuruppaPool() {
    els.kuruppaPoolList.innerHTML = KG.KURUPPA_PR_POOL.map(function (item) {
      return '<li><span class="pool-kind">' + item.kind + "</span>" + item.label + "</li>";
    }).join("");
  }

  els.chIcon.addEventListener("change", function () {
    var file = els.chIcon.files && els.chIcon.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      alert("画像は2MB以下にしてください。");
      els.chIcon.value = "";
      return;
    }
    var reader = new FileReader();
    reader.onload = function () {
      iconUrl = reader.result;
      els.iconPreview.innerHTML = '<img src="' + iconUrl + '" alt="プレビュー" />';
      els.btnClearIcon.classList.remove("hidden");
    };
    reader.readAsDataURL(file);
  });

  els.btnClearIcon.addEventListener("click", function () {
    iconUrl = null;
    els.chIcon.value = "";
    els.iconPreview.innerHTML = "📷";
    els.btnClearIcon.classList.add("hidden");
  });

  els.form.addEventListener("submit", startFromForm);
  els.btnDemo.addEventListener("click", function () {
    loadDemo();
    startFromForm();
  });
  els.btnSkip.addEventListener("click", function () {
    skipRequested = true;
    els.btnSkip.classList.add("hidden");
  });
  els.btnRetry.addEventListener("click", function () {
    fighters = null;
    showStep("setup");
  });
  els.btnCopy.addEventListener("click", function () {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(els.shareText.value).then(function () {
        els.btnCopy.textContent = "コピーしました！";
        setTimeout(function () {
          els.btnCopy.textContent = "コピー";
        }, 2000);
      });
    } else {
      els.shareText.select();
      document.execCommand("copy");
    }
  });

  renderKuruppaPool();
})();

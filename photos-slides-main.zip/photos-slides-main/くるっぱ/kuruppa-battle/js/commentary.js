(function (KG) {
  function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function profileIntro(profile, role) {
    var lines = [];
    lines.push(
      role + "、" + profile.city + "ゆるキャラ「" + profile.name + "」の登場です！" +
      (profile.characterTraits
        ? " キャラクターの特徴は「" + profile.characterTraits + "」。この個性がPR合戦の鍵を握ります。"
        : "")
    );
    (profile.prItems || []).forEach(function (item, idx) {
      var desc = item.prDesc || (item.kind + "として地域を代表する「" + item.label + "」");
      lines.push(
        "【PR" + (idx + 1) + "】" + item.label + "（" + item.kind + "）。 " + desc +
        " 観光客の心を掴み、自治体のファンを増やす切り札です。"
      );
    });
    return lines;
  }

  KG.openingCommentary = function openingCommentary(a, b) {
    var lines = [
      "━━━━━━━━━━━━━━━━━━━━",
      "【くるっぱPR合戦】全10ターン制・自治体魅力バトル、実況開始！",
      "名産・名所・文化を武器に、地域の「行ってみたい！」を競う特殊ルールの一戦です。",
      "数字のステータスは非公開。実況を通じて、両自治体の魅力がそのままPRとなります。",
      "━━━━━━━━━━━━━━━━━━━━",
    ];
    lines = lines.concat(profileIntro(a, "■ 守備側"));
    lines.push("── 挑戦者、リングイン！ ──");
    lines = lines.concat(profileIntro(b, "■ チャレンジャー"));
    lines.push(
      "両者、それぞれのPR武器を総動員して10ターンの攻防。",
      "勝敗以上に大切なのは、あなたの街の「語り」を届けること。",
      "さあ、PR合戦…始め！"
    );
    return lines;
  };

  function attackNarrative(actor, target, damage, options) {
    options = options || {};
    var item = (actor.profile.prItems || [])[Math.floor(Math.random() * (actor.profile.prItems || []).length)];
    var prName = item ? item.label : actor.profile.weapon.name;
    var prDesc = item && item.prDesc ? item.prDesc : actor.profile.weapon.desc;
    var city = actor.profile.city;
    var lines = [];

    lines.push(
      actor.profile.name + "、ここぞとばかり「" + prName + "」のPRを炸裂させます！" +
      prDesc + " まさに" + city + "の誇りが凝縮されたアピールです。"
    );

    if (actor.profile.characterTraits) {
      lines.push(
        "解説席から見ても、" + actor.profile.name + "の「" + actor.profile.characterTraits +
        "」というキャラクター性が、PRの説得力を一段と高めています。"
      );
    }

    lines.push(
      target.profile.name + "側も負けじと応戦！ しかし" + actor.profile.name + "の攻勢は" + damage +
      "ポイント分、視聴者の心に刺さりました。SNSでシェアしたくなるようなインパクトです！"
    );

    if (options.weaknessHit) {
      lines.push(
        "なんと、このPRは" + target.profile.name + "の弱点にドンピシャ！ " +
        target.profile.city + "ファンも「うわ、刺さる…！」と盛り上がっています。"
      );
    }
    if (options.critical) {
      lines.push(
        "クリティカルPR！ 全国区の話題性を獲得した一撃！" +
        city + "の魅力がタイムラインを埋め尽くす展開に！"
      );
    }
    return lines;
  }

  function traitNarrative(actor, effect, value) {
    var traitName = actor.profile.trait.name;
    var city = actor.profile.city;
    if (effect === "heal") {
      return actor.profile.name + "、「" + traitName + "」で地域の温かさを再アピール！ " +
        "ファン心を回復し、PR力+" + value + "。 " + city + "ならではの癒やしが会場を包みます。";
    }
    if (effect === "speed") {
      return actor.profile.name + "、話題性急上昇！ 「" + traitName + "」で次々とPRネタを連発。" +
        city + "の観光スポットが次々と検索され始めた模様です！";
    }
    if (effect === "boost") {
      return "ここで" + actor.profile.name + "、「" + traitName + "」全開！" +
        city + "の名産・名所の魅力を畳み掛けるような攻めのPRにシフトしました！";
    }
    if (effect === "guard") {
      return actor.profile.name + "、「" + traitName + "」で地域の誇りを盾に！" +
        "他県からの攻勢をものともせず、" + city + "のブランドを守り抜きます！";
    }
    if (effect === "counter") {
      return actor.profile.name + "、受けて即反撃のPR構え！ 「" + traitName + "」で" +
        city + "の隠れた魅力を逆手に取る戦略的アピールです！";
    }
    return "";
  }

  KG.commentaryForTurn = function commentaryForTurn(turnResult, turnNum) {
    var lines = [];
    var events = turnResult.events;
    var a = turnResult.a;
    var b = turnResult.b;

    lines.push({
      text: "── 第" + turnNum + "ターン / 残り" + Math.max(0, 10 - turnNum) + "ターン ── " +
        "両者、まだ語り尽くしていないPRネタを温存しているか、それとも総力戦か！",
      kind: "highlight",
    });

    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      if (ev.type === "trait") {
        var t = traitNarrative(ev.actor, ev.effect, ev.value);
        if (t) lines.push({ text: t, kind: "highlight" });
      } else if (ev.type === "guard") {
        lines.push({
          text: ev.actor.profile.name + "、地域ブランド防衛成功！" +
            ev.actor.profile.city + "のイメージを損なわず、ダメージを大幅カットしました。",
          kind: "normal",
        });
      } else if (ev.type === "attack") {
        attackNarrative(ev.actor, ev.target, ev.damage, {
          weaknessHit: ev.weaknessHit,
          critical: ev.critical,
        }).forEach(function (t) {
          lines.push({ text: t, kind: ev.critical || ev.weaknessHit ? "critical" : "normal" });
        });
      } else if (ev.type === "counter") {
        lines.push({
          text: "逆転のPR反撃！" + ev.actor.profile.name + "が" + ev.target.profile.name +
            "の攻勢を跳ね返し、" + ev.damage + "ポイント分の魅力を差し戻しました！" +
            ev.actor.profile.city + "の底力、ここにあり！",
          kind: "highlight",
        });
      }
    }

    [a, b].forEach(function (f) {
      if (f.hp > 0 && f.hp / f.maxHp <= 0.25) {
        lines.push({
          text: f.profile.name + "、PR力残りわずか！ でも" + f.profile.city +
            "の魅力は尽きません。逆転の一話を残すか、名誉ある敗北か…！",
          kind: "highlight",
        });
      }
    });

    return lines;
  };

  KG.closingCommentary = function closingCommentary(winner, loser) {
    var wItems = (winner.profile.prItems || []).map(function (i) { return i.label; }).join("・");
    var lItems = (loser.profile.prItems || []).map(function (i) { return i.label; }).join("・");
    return [
      "━━━━━━━━━━━━━━━━━━━━",
      "10ターン、PR合戦終了！ 勝者、" + winner.profile.name + "（" + winner.profile.city + "）！",
      winner.profile.name + "が押し切ったPR武器は「" + wItems + "」。" +
        winner.profile.city + "の魅力が、今日一番「行ってみたい！」と思わせたのは間違いありません。",
      "敗れはしたものの、" + loser.profile.name + "（" + loser.profile.city + "）も健闘！" +
        "「" + lItems + "」など、語り尽くせない見どころを全国に発信しました。",
      "勝敗はつきましたが、両自治体ともファンが増えるPR合戦 — それがくるっぱPR合戦の真の勝利です。",
      "ぜひ" + winner.profile.city + "も" + loser.profile.city + "も、実際に足を運んでみてください！",
      "━━━━━━━━━━━━━━━━━━━━",
    ];
  };

  function formatPrDetailed(profile) {
    return (profile.prItems || [])
      .map(function (i) { return i.kind + ":" + (i.label || i.text); })
      .join(" / ");
  }

  KG.buildShareText = function buildShareText(winner, loser, totalTurns, kuruppaProfile) {
    var kuruppaHand = (kuruppaProfile.prItems || []).map(function (i) { return i.label; }).join("・");
    var challenger = winner.profile.name === "くるっぱ" ? loser.profile : winner.profile;

    return (
      "【くるっぱPR合戦 結果｜" + totalTurns + "ターン制】\n\n" +
      "🐸 くるっぱ（久留米市）\n" +
      "　今回のPR: " + kuruppaHand + "\n" +
      "　🆚\n" +
      challenger.name + "（" + challenger.city + "）\n" +
      "　PR: " + formatPrDetailed(challenger) + "\n" +
      (challenger.characterTraits ? "　キャラ: " + challenger.characterTraits + "\n" : "") +
      "\n🏆 勝者：" + winner.profile.name + "！\n\n" +
      "#くるっぱPR合戦 #くるっぱ #自治体PR"
    );
  };
})(window.KuruppaGame);

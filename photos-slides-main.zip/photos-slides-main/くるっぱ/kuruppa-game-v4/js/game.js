(() => {
  "use strict";

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const statusEl = document.getElementById("status");

  const W = canvas.width;
  const H = canvas.height;
  const GRAVITY = 0.62;
  const MOVE_SPEED = 4.6;
  const JUMP_VEL = -12.2;
  const WORLD_W = 3200;
  const GROUND_Y = H - 48;
  const BASE_W = 52;
  const BASE_H = 64;
  const UDON_MS = 3000;
  const RAMEN_FX_MS = 1400;
  const EAT_FRAMES = 14;

  const keys = new Set();
  let jumpBuffer = 0;
  let loopRunning = false;
  let loaded = 0;
  let started = false;

  const startOverlay = document.getElementById("start-overlay");
  const startBtn = document.getElementById("start-btn");

  const sprites = {
    stand: loadImage("sprites/kuruppa-stand.png"),
    walk: loadImage("sprites/kuruppa-walk.png"),
    jump: loadImage("sprites/kuruppa-jump.png"),
    front: loadImage("sprites/kuruppa-front.png"),
  };
  const needLoad = Object.keys(sprites).length;

  const inventory = { yakitori: 0, ramen: 0 };
  /** @type {Array<{type:string,x:number,y:number,vx:number,vy:number,life:number,w:number,h:number,spin:number}>} */
  const projectiles = [];
  /** 敵吹き飛び演出パーティクル */
  const knockFx = [];

  const solids = [
    { x: 0, y: GROUND_Y, w: WORLD_W, h: 48, ground: true, broken: false },
    { x: 280, y: H - 128, w: 160, h: 24, broken: false },
    { x: 520, y: H - 200, w: 120, h: 24, broken: false },
    { x: 720, y: H - 160, w: 100, h: 24, broken: false },
    { x: 900, y: H - 240, w: 140, h: 24, broken: false },
    { x: 1120, y: H - 180, w: 120, h: 24, broken: false },
    { x: 1320, y: H - 280, w: 160, h: 24, broken: false },
    { x: 1560, y: H - 200, w: 100, h: 24, broken: false },
    { x: 1740, y: H - 320, w: 180, h: 24, broken: false },
    { x: 1980, y: H - 220, w: 120, h: 24, broken: false },
    { x: 2180, y: H - 160, w: 140, h: 24, broken: false },
    { x: 2420, y: H - 260, w: 160, h: 24, broken: false },
    { x: 2660, y: H - 180, w: 120, h: 24, broken: false },
    { x: 2860, y: H - 140, w: 200, h: 24, broken: false },
  ];

  const gaps = [];

  /** @type {Array<{type:"ramen"|"yakitori"|"udon",x:number,y:number,r:number,taken:boolean}>} */
  const foodPickups = [
    { type: "yakitori", x: 480, y: H - 175, r: 18, taken: false },
    { type: "udon", x: 650, y: H - 160 - 38, r: 18, taken: false },
    { type: "yakitori", x: 980, y: H - 215, r: 18, taken: false },
    { type: "udon", x: 1080, y: H - 180 - 38, r: 18, taken: false },
    { type: "ramen", x: 1680, y: H - 88, r: 18, taken: false },
    { type: "udon", x: 1680, y: H - 200 - 38, r: 18, taken: false },
    { type: "yakitori", x: 1920, y: H - 175, r: 18, taken: false },
  ];
  /** 水流攻撃の飛沫パーティクル */
  const waterParticles = [];

  /** 足場の上または地上に配置（瓦ブロック内に埋まらないよう調整） */
  const droplets = [
    { x: 140, y: H - 88, r: 11, taken: false },
    { x: 360, y: H - 128 - 38, r: 11, taken: false },
    { x: 580, y: H - 200 - 38, r: 11, taken: false },
    { x: 770, y: H - 160 - 38, r: 11, taken: false },
    { x: 970, y: H - 240 - 38, r: 11, taken: false },
    { x: 760, y: H - 88, r: 11, taken: false },
    { x: 1180, y: H - 180 - 38, r: 11, taken: false },
    { x: 1400, y: H - 280 - 38, r: 11, taken: false },
    { x: 1610, y: H - 200 - 38, r: 11, taken: false },
    { x: 1830, y: H - 320 - 38, r: 11, taken: false },
    { x: 2040, y: H - 220 - 38, r: 11, taken: false },
    { x: 2500, y: H - 260 - 38, r: 11, taken: false },
    { x: 2720, y: H - 180 - 38, r: 11, taken: false },
    { x: 2960, y: H - 140 - 38, r: 11, taken: false },
  ];

  const enemies = [
    { x: 420, y: H - 88, w: 36, h: 36, vx: 1.4, alive: true, fly: false },
    { x: 1050, y: H - 88, w: 36, h: 36, vx: -1.6, alive: true, fly: false },
    { x: 1450, y: H - 88, w: 36, h: 36, vx: 1.3, alive: true, fly: false },
    { x: 1850, y: H - 88, w: 36, h: 36, vx: 1.5, alive: true, fly: false },
    { x: 2550, y: H - 88, w: 36, h: 36, vx: -1.3, alive: true, fly: false },
    { x: 2920, y: H - 88, w: 36, h: 36, vx: 1.2, alive: true, fly: false },
    { x: 580, y: 160, w: 40, h: 32, vx: 1.7, alive: true, fly: true, baseY: 160, phase: 0 },
    { x: 980, y: 120, w: 40, h: 32, vx: -2.0, alive: true, fly: true, baseY: 120, phase: 1.2 },
    { x: 1680, y: 150, w: 40, h: 32, vx: 1.9, alive: true, fly: true, baseY: 150, phase: 2.4 },
    { x: 2200, y: 110, w: 40, h: 32, vx: -1.6, alive: true, fly: true, baseY: 110, phase: 0.6 },
    { x: 2680, y: 140, w: 40, h: 32, vx: 1.8, alive: true, fly: true, baseY: 140, phase: 3.1 },
  ];

  for (const e of enemies) {
    e.homeX = e.x;
    e.homeY = e.y;
    e.homeVx = e.vx;
    e.homeBaseY = e.baseY;
    e.homePhase = e.phase || 0;
    e.knocked = false;
    e.knockVx = 0;
    e.knockVy = 0;
    e.knockSpin = 0;
    e.knockFlash = 0;
    e.knockTrail = [];
    e.needsRespawn = false;
    e.canRespawn = false;
  }

  const goal = { x: WORLD_W - 120, y: H - 200, w: 48, h: 152 };

  const player = {
    x: 64,
    y: H - 200,
    w: BASE_W,
    h: BASE_H,
    vx: 0,
    vy: 0,
    onGround: false,
    facing: 1,
    anim: 0,
    won: false,
    dead: false,
    /** 敵撃破時の空中吹っ飛び演出中 */
    dying: false,
    deathSpin: 0,
    deathPause: 0,
    attackCd: 0,
    /** ラーメン顔ビーム演出終了時刻 */
    ramenFxUntil: 0,
    ramenFxStart: 0,
    ramenBeamHit: false,
    beamOriginX: 0,
    beamOriginY: 0,
    beamDir: 1,
    /** ラーメン取得：↓でスライディング攻撃 */
    hasRamen: false,
    /** スライディング攻撃の残りフレーム */
    slideFrames: 0,
    /** スライディング攻撃のクールダウン残りフレーム */
    slideCd: 0,
    /** スライディング攻撃の終了時刻（ms） */
    slideUntil: 0,
    /** うどん：ジャンプ1.5倍の終了時刻 (ms) */
    jumpBoostUntil: 0,
    /** やきとり食べ中の残りフレーム / 投げ待ち */
    eatFrames: 0,
    pendingThrow: false,
    /** 縮んだ直後の無敵 */
    hurtUntil: 0,
  };

  let cameraX = 0;
  let score = 0;
  let dropletCount = 0;

  function loadImage(src) {
    const img = new Image();
    img.onload = () => {
      loaded += 1;
      if (loaded >= needLoad && !loopRunning) {
        loopRunning = true;
        statusEl.textContent = "スタートボタンを押してゲーム開始！";
        requestAnimationFrame(loop);
      }
    };
    img.onerror = () => {
      statusEl.textContent = "スプライトの読み込みに失敗しました。";
    };
    img.src = src;
    return img;
  }

  function now() {
    return performance.now();
  }

  function isHurtIFrames() {
    return now() < player.hurtUntil;
  }

  function isRamenFx() {
    return now() < player.ramenFxUntil;
  }

  function activeSolids() {
    return solids.filter((s) => !s.broken);
  }

  function hasJumpBoost() {
    return now() < player.jumpBoostUntil;
  }

  function jumpPower() {
    return JUMP_VEL * (hasJumpBoost() ? 1.5 : 1);
  }

  function isWorldOnScreen(wx, wy, w, h) {
    const margin = 24;
    return (
      wx + w > cameraX - margin &&
      wx < cameraX + W + margin &&
      wy + h > -margin &&
      wy < H + margin
    );
  }

  function respawnEnemy(e) {
    e.x = e.homeX;
    e.y = e.homeY;
    e.vx = e.homeVx;
    if (e.fly) {
      e.baseY = e.homeBaseY;
      e.phase = e.homePhase;
    }
    e.alive = true;
    e.knocked = false;
    e.knockVx = 0;
    e.knockVy = 0;
    e.knockSpin = 0;
    e.knockFlash = 0;
    e.knockTrail = [];
    e.needsRespawn = false;
    e.canRespawn = false;
  }

  function respawnAllEnemies() {
    for (const e of enemies) respawnEnemy(e);
  }

  function spawnKnockBurst(x, y, strong) {
    const count = strong ? 16 : 9;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = (strong ? 6 : 3.5) + Math.random() * (strong ? 8 : 5);
      knockFx.push({
        kind: "spark",
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - (strong ? 2 : 0),
        life: 22 + Math.random() * 20,
        size: 3 + Math.random() * (strong ? 6 : 4),
        color: Math.random() > 0.45 ? "#ffeb3b" : "#ff7043",
      });
    }
    knockFx.push({
      kind: "ring",
      x,
      y,
      life: strong ? 26 : 18,
      maxLife: strong ? 26 : 18,
      size: strong ? 52 : 34,
    });
    knockFx.push({
      kind: "text",
      x,
      y: y - 8,
      life: 24,
      text: strong ? "ドカーン！" : "バキッ！",
    });
  }

  function launchKnockedEnemy(e, fromX, fromY, strong) {
    const ex = e.x + e.w / 2;
    const ey = e.y + e.h / 2;
    const dx = ex - fromX;
    const dy = ey - fromY;
    const len = Math.hypot(dx, dy) || 1;
    const power = strong ? 18 + Math.random() * 10 : 13 + Math.random() * 7;
    e.alive = false;
    e.knocked = true;
    e.knockVx = (dx / len) * power + (Math.random() - 0.5) * 3;
    e.knockVy = (dy / len) * power - (strong ? 14 : 10) - Math.random() * 4;
    e.knockSpin = (Math.random() - 0.5) * (strong ? 0.65 : 0.45);
    e.knockFlash = strong ? 30 : 18;
    e.knockTrail = [{ x: ex, y: ey }];
    spawnKnockBurst(ex, ey, !!strong);
  }

  const WATER_ATTACK_RANGE = 540;
  // relAngle: 0=正面、マイナス=下方向、プラス=上方向
  const WATER_ATTACK_ANGLE_MIN = -Math.PI / 4; // 下45度
  const WATER_ATTACK_ANGLE_MAX = Math.PI / 2; // 上90度

  function enemyInWaterCone(e, ox, oy, facing, maxLen) {
    const ex = e.x + e.w / 2;
    const ey = e.y + e.h / 2;
    const vx = ex - ox;
    const vy = ey - oy;
    const len = Math.hypot(vx, vy);
    if (len < 12 || len > maxLen) return false;

    // 進行方向を0度、下45度〜上90度の扇形
    const relAngle = facing > 0 ? Math.atan2(-vy, vx) : Math.atan2(-vy, -vx);
    const margin = 0.08;
    return (
      relAngle >= WATER_ATTACK_ANGLE_MIN - margin &&
      relAngle <= WATER_ATTACK_ANGLE_MAX + margin
    );
  }

  function activateRamenBlast() {
    const t = now();
    player.ramenFxStart = t;
    player.ramenFxUntil = t + RAMEN_FX_MS;
    player.ramenBeamHit = false;
    player.beamDir = player.facing;
    player.beamOriginX = player.x + player.w / 2;
    player.beamOriginY = player.y + player.h * 0.38;
    waterParticles.length = 0;
    statusEl.textContent = "水流攻撃！";
  }

  function spawnWaterParticle(ox, oy, facing, power) {
    // relAngleを当たり判定と同じ範囲（下45度〜上90度）でばらす
    const relAngle =
      WATER_ATTACK_ANGLE_MIN +
      Math.random() * (WATER_ATTACK_ANGLE_MAX - WATER_ATTACK_ANGLE_MIN);
    // canvas座標の角度に変換（0=右、上は負）
    const ang = facing > 0 ? -relAngle : Math.PI + relAngle;
    const speed = (power || 1) * (14 + Math.random() * 18);
    waterParticles.push({
      x: ox + (Math.random() - 0.5) * 28,
      y: oy + (Math.random() - 0.5) * 20,
      vx: Math.cos(ang) * speed,
      vy: Math.sin(ang) * speed,
      life: 22 + Math.random() * 30,
      maxLife: 52,
      size: 10 + Math.random() * 18,
      stretch: 1.2 + Math.random() * 1.6,
    });
  }

  function updateWaterParticles() {
    if (!isRamenFx()) {
      waterParticles.length = 0;
      return;
    }
    const ox = player.beamOriginX;
    const oy = player.beamOriginY;
    const facing = player.beamDir;
    const burst = 22;
    for (let i = 0; i < burst; i++) {
      spawnWaterParticle(ox, oy, facing, 1);
    }

    for (let i = waterParticles.length - 1; i >= 0; i--) {
      const p = waterParticles[i];
      p.life -= 1;
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.28;
      p.vx *= 0.97;
      if (p.life <= 0) waterParticles.splice(i, 1);
    }
  }

  function updateRamenBeam() {
    if (!isRamenFx() || player.ramenBeamHit) return;
    const elapsed = now() - player.ramenFxStart;
    if (elapsed < 140) return;

    player.ramenBeamHit = true;
    const ox = player.beamOriginX;
    const oy = player.beamOriginY;
    const facing = player.beamDir;
    let hit = 0;
    for (const e of enemies) {
      if (!e.alive || e.knocked || e.needsRespawn) continue;
      if (!enemyInWaterCone(e, ox, oy, facing, WATER_ATTACK_RANGE)) continue;
      launchKnockedEnemy(e, ox, oy, true);
      hit += 1;
    }
    score += hit * 40;
    if (hit > 0) {
      statusEl.textContent = `水流攻撃！${hit}体を吹き飛ばした！`;
    }
  }

  function activateUdonJumpBoost() {
    player.jumpBoostUntil = now() + UDON_MS;
    statusEl.textContent = "うどんゲット！ジャンプ力1.5倍（3秒）！";
  }

  function startGame() {
    if (loaded < needLoad) return;
    started = true;
    if (startOverlay) startOverlay.hidden = true;
    resetGame();
    statusEl.textContent =
      "水滴を集めてゴールへ！水滴5つで水流攻撃（↓はラーメン必須） 1=串投げ";
  }

  function resetGame() {
    player.x = 64;
    player.y = H - 200;
    player.w = BASE_W;
    player.h = BASE_H;
    player.vx = 0;
    player.vy = 0;
    player.onGround = false;
    player.facing = 1;
    player.won = false;
    player.dead = false;
    player.dying = false;
    player.deathSpin = 0;
    player.deathPause = 0;
    player.attackCd = 0;
    player.ramenFxUntil = 0;
    player.ramenFxStart = 0;
    player.ramenBeamHit = false;
    player.hasRamen = false;
    player.slideFrames = 0;
    player.slideCd = 0;
    player.slideUntil = 0;
    player.jumpBoostUntil = 0;
    player.eatFrames = 0;
    player.pendingThrow = false;
    player.hurtUntil = 0;
    cameraX = 0;
    score = 0;
    dropletCount = 0;
    jumpBuffer = 0;
    inventory.yakitori = 0;
    inventory.ramen = 0;
    projectiles.length = 0;
    knockFx.length = 0;
    waterParticles.length = 0;
    for (const d of droplets) d.taken = false;
    for (const f of foodPickups) f.taken = false;
    respawnAllEnemies();
    for (const s of solids) s.broken = false;
    if (started) {
      statusEl.textContent =
        "水滴を集めてゴールへ！水滴5つで水流攻撃（↓はラーメン必須） 1=串投げ";
    }
  }

  function isJumpKey(key, code) {
    return (
      key === " " ||
      key === "ArrowUp" ||
      key === "w" ||
      key === "W" ||
      code === "Space" ||
      code === "ArrowUp" ||
      code === "KeyW"
    );
  }

  window.addEventListener("keydown", (e) => {
    if (
      ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", " ", "a", "d", "w"].includes(
        e.key
      )
    ) {
      e.preventDefault();
    }
    if (e.key === "r" || e.key === "R") {
      if (started) resetGame();
    }
    if (!started) {
      keys.add(e.key);
      return;
    }
    if (isJumpKey(e.key, e.code)) jumpBuffer = 5;
    if (e.key === "1") tryThrowYakitori();
    keys.add(e.key);
  });

  window.addEventListener("keyup", (e) => keys.delete(e.key));

  function isDown(...names) {
    return names.some((k) => keys.has(k));
  }

  function rectOverlap(a, b) {
    return (
      a.x < b.x + b.w &&
      a.x + a.w > b.x &&
      a.y < b.y + b.h &&
      a.y + a.h > b.y
    );
  }

  function inGap(x, w) {
    const cx = x + w / 2;
    return gaps.some((g) => cx > g.x && cx < g.x + g.w);
  }

  function resolveAxis(entity, solidsList, axis) {
    for (const s of solidsList) {
      if (!rectOverlap(entity, s)) continue;
      if (axis === "x") {
        if (entity.vx > 0) entity.x = s.x - entity.w;
        else if (entity.vx < 0) entity.x = s.x + s.w - entity.w;
        entity.vx = 0;
      } else if (entity.vy > 0) {
        entity.y = s.y - entity.h;
        entity.vy = 0;
        entity.onGround = true;
      } else if (entity.vy < 0) {
        entity.y = s.y + s.h;
        entity.vy = 0;
      }
    }
  }

  function startEnemyDefeat() {
    if (player.dying || player.dead || player.won) return;
    player.dying = true;
    player.deathPause = 18;
    player.deathSpin = 0;
    player.vx = 0;
    player.vy = 0;
    player.ramenFxUntil = 0;
    player.eatFrames = 0;
    player.pendingThrow = false;
    statusEl.textContent = "びっくらこいたぁ〜！";
  }

  function tryJump() {
    if (
      jumpBuffer <= 0 ||
      !player.onGround ||
      player.won ||
      player.dead ||
      player.dying
    ) {
      return;
    }
    player.vy = jumpPower();
    player.onGround = false;
    jumpBuffer = 0;
  }

  function tryThrowYakitori() {
    if (player.won || player.dead || player.dying || player.attackCd > 0) return;
    if (player.eatFrames > 0 || player.pendingThrow) return;
    if (inventory.yakitori <= 0) {
      statusEl.textContent = "やきとりを持っていません";
      return;
    }
    inventory.yakitori -= 1;
    player.attackCd = 10;
    player.eatFrames = EAT_FRAMES;
    player.pendingThrow = true;
    statusEl.textContent = "やきとりを食べた！串を投げる…";
  }

  function throwSkewer() {
    const cx = player.x + player.w / 2;
    const cy = player.y + player.h * 0.42;
    const dir = player.facing;
    projectiles.push({
      type: "yakitori",
      x: cx + dir * 8 - 5,
      y: cy - 24,
      vx: dir * 12.5,
      vy: -1.2,
      life: 70,
      w: 10,
      h: 48,
    });
    statusEl.textContent = "串を投げた！";
  }

  function updatePlayer() {
    if (player.won || player.dead) return;

    // 敵にやられた：びっくりして空へ飛び去る
    if (player.dying) {
      if (player.deathPause > 0) {
        player.deathPause -= 1;
        if (player.deathPause === 0) {
          player.vy = -18;
          player.vx = player.facing * 1.2;
        }
        return;
      }
      player.vy += GRAVITY * 0.85;
      player.x += player.vx;
      player.y += player.vy;
      player.deathSpin += 0.28;
      if (player.y + player.h < -80 || player.y > H + 120) {
        player.dying = false;
        player.dead = true;
        statusEl.textContent = "くるっぱがやられた… R でリトライ";
      }
      return;
    }

    const wasOnGround = player.onGround;
    const downPressed = isDown("ArrowDown", "s", "S");
    const slidingNow = now() < player.slideUntil;
    if (player.slideCd > 0) player.slideCd -= 1;
    player.onGround = false;

    if (player.eatFrames > 0) {
      player.eatFrames -= 1;
      if (player.eatFrames === 0 && player.pendingThrow) {
        player.pendingThrow = false;
        throwSkewer();
      }
    }

    if (slidingNow) {
      player.vy = 0;
      player.vx = player.facing * MOVE_SPEED * 1.35;
    } else if (
      downPressed &&
      inventory.ramen > 0 &&
      wasOnGround &&
      player.slideCd <= 0 &&
      player.attackCd <= 0 &&
      player.eatFrames === 0 &&
      !player.pendingThrow &&
      !isRamenFx()
    ) {
      inventory.ramen -= 1;
      if (inventory.ramen < 0) inventory.ramen = 0;
      player.hasRamen = inventory.ramen > 0;
      player.slideFrames = 1;
      player.slideUntil = now() + 3000; // 3秒持続
      player.slideCd = 35;
      player.vy = 0;
      player.vx = player.facing * MOVE_SPEED * 1.35;
      statusEl.textContent = "スライディング！";
    } else if (player.eatFrames > 0) {
      player.vx *= 0.55;
      if (Math.abs(player.vx) < 0.15) player.vx = 0;
    } else if (isDown("ArrowLeft", "a", "A")) {
      player.vx = -MOVE_SPEED;
      player.facing = -1;
    } else if (isDown("ArrowRight", "d", "D")) {
      player.vx = MOVE_SPEED;
      player.facing = 1;
    } else {
      player.vx *= 0.72;
      if (Math.abs(player.vx) < 0.15) player.vx = 0;
    }

    if (slidingNow) {
      player.vy = 0;
    } else {
      player.vy += GRAVITY;
    }
    player.x += player.vx;
    resolveAxis(player, activeSolids(), "x");
    player.y += player.vy;
    resolveAxis(player, activeSolids(), "y");

    if (player.x < 0) player.x = 0;
    if (player.x + player.w > WORLD_W) player.x = WORLD_W - player.w;

    const footY = player.y + player.h;
    if (footY >= GROUND_Y && !inGap(player.x, player.w)) {
      player.y = GROUND_Y - player.h;
      player.vy = 0;
      player.onGround = true;
    }

    tryJump();
    if (jumpBuffer > 0) jumpBuffer -= 1;

    if (player.y > H + 40) {
      player.dead = true;
      statusEl.textContent = "筑後川に落ちちゃった… R でリトライ";
    }

    if (Math.abs(player.vx) > 0.3 && player.onGround) player.anim += 0.18;
    if (player.attackCd > 0) player.attackCd -= 1;

    for (const d of droplets) {
      if (d.taken) continue;
      const dx = player.x + player.w / 2 - d.x;
      const dy = player.y + player.h / 2 - d.y;
      if (dx * dx + dy * dy < (d.r + 22) ** 2) {
        d.taken = true;
        dropletCount += 1;
        score += 10;
        if (dropletCount % 5 === 0 && !isRamenFx()) {
          activateRamenBlast();
        }
      }
    }

    for (const f of foodPickups) {
      if (f.taken) continue;
      const dx = player.x + player.w / 2 - f.x;
      const dy = player.y + player.h / 2 - f.y;
      if (dx * dx + dy * dy < (f.r + 24) ** 2) {
        f.taken = true;
        score += 15;
        if (f.type === "ramen") {
          inventory.ramen += 1;
          player.hasRamen = inventory.ramen > 0;
          statusEl.textContent = `ラーメンを食べた！（${inventory.ramen}回分）↓でスライディング攻撃！`;
        } else if (f.type === "udon") {
          activateUdonJumpBoost();
        } else {
          inventory.yakitori += 1;
          statusEl.textContent = `やきとりをゲット！（${inventory.yakitori}個） 1で串投げ`;
        }
      }
    }

    for (const e of enemies) {
      if (!e.alive || e.knocked || e.needsRespawn) continue;
      if (!rectOverlap(player, e)) continue;

      if (slidingNow && !isRamenFx()) {
        launchKnockedEnemy(
          e,
          player.x + player.w / 2 + player.facing * 20,
          player.y + player.h / 2,
          true
        );
        score += 30;
        continue;
      }

      const stomp = player.vy > 0 && player.y + player.h - e.y < e.h * 0.55;
      if (stomp) {
        launchKnockedEnemy(
          e,
          player.x + player.w / 2,
          player.y + player.h / 2,
          false
        );
        player.vy = jumpPower() * 0.55;
        score += 25;
        continue;
      }

      if (isHurtIFrames()) continue;

      startEnemyDefeat();
    }

    if (!slidingNow) player.slideFrames = 0;

    if (rectOverlap(player, goal)) {
      player.won = true;
      statusEl.textContent = `ゴール！スコア ${score} — R でもう一度`;
    }
  }

  function updateProjectiles() {
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const p = projectiles[i];
      p.life -= 1;
      p.x += p.vx;
      p.y += p.vy;
      if (p.type === "yakitori") p.vy += 0.12;

      const box = { x: p.x, y: p.y, w: p.w, h: p.h };
      for (const e of enemies) {
        if (!e.alive || e.knocked || e.needsRespawn) continue;
        const eb = { x: e.x, y: e.y, w: e.w, h: e.h };
        if (rectOverlap(box, eb)) {
          launchKnockedEnemy(e, p.x + p.w / 2, p.y + p.h / 2, false);
          score += 30;
          p.life = 0;
          break;
        }
      }
      if (p.life <= 0 || p.x < -80 || p.x > WORLD_W + 80) {
        projectiles.splice(i, 1);
      }
    }
  }

  function updateKnockFx() {
    for (let i = knockFx.length - 1; i >= 0; i--) {
      const p = knockFx[i];
      p.life -= 1;
      if (p.kind === "spark") {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.22;
        p.vx *= 0.96;
      }
      if (p.life <= 0) knockFx.splice(i, 1);
    }
  }

  function updateEnemies() {
    const solidsNow = activeSolids();
    for (const e of enemies) {
      if (e.knocked) {
        const prevX = e.x + e.w / 2;
        const prevY = e.y + e.h / 2;
        e.x += e.knockVx;
        e.y += e.knockVy;
        e.knockVy += 0.38;
        e.knockSpin += 0.22;
        if (e.knockFlash > 0) e.knockFlash -= 1;
        if (!e.knockTrail) e.knockTrail = [];
        if (e.knockTrail.length === 0 || Math.hypot(
          e.x + e.w / 2 - e.knockTrail[e.knockTrail.length - 1].x,
          e.y + e.h / 2 - e.knockTrail[e.knockTrail.length - 1].y
        ) > 10) {
          e.knockTrail.push({ x: e.x + e.w / 2, y: e.y + e.h / 2 });
        }
        if (e.knockTrail.length > 14) e.knockTrail.shift();
        if (Math.random() < 0.35) {
          knockFx.push({
            kind: "spark",
            x: prevX,
            y: prevY,
            vx: (Math.random() - 0.5) * 2,
            vy: (Math.random() - 0.5) * 2,
            life: 10,
            size: 2 + Math.random() * 3,
            color: "rgba(255,255,255,0.9)",
          });
        }
        if (
          e.x < cameraX - 180 ||
          e.x > cameraX + W + 180 ||
          e.y < -160 ||
          e.y > H + 160
        ) {
          e.knocked = false;
          e.needsRespawn = true;
          e.canRespawn = false;
          e.knockTrail = [];
        }
        continue;
      }

      if (e.needsRespawn) {
        const passedRight = cameraX > e.homeX + 140;
        const passedLeft = cameraX + W < e.homeX - 140;
        if (passedRight || passedLeft) e.canRespawn = true;
        if (e.canRespawn && isWorldOnScreen(e.homeX, e.homeY, e.w, e.h)) {
          respawnEnemy(e);
        }
        continue;
      }

      if (!e.alive) continue;

      if (e.fly) {
        e.phase = (e.phase || 0) + 0.1;
        e.x += e.vx;
        e.y = e.baseY + Math.sin(e.phase) * 30;
        if (e.x < 80 || e.x > WORLD_W - 100) {
          e.vx *= -1;
          e.x += e.vx * 2;
        }
        continue;
      }

      e.x += e.vx;
      const box = { x: e.x, y: e.y, w: e.w, h: e.h };
      let hit = false;
      for (const s of solidsNow) {
        if (rectOverlap(box, s)) hit = true;
      }
      if (hit || e.x < 40 || e.x > WORLD_W - 60) {
        e.vx *= -1;
        e.x += e.vx * 2;
      }
    }
  }

  function updateCamera() {
    const target = player.x + player.w / 2 - W / 2;
    cameraX += (target - cameraX) * 0.12;
    cameraX = Math.max(0, Math.min(cameraX, WORLD_W - W));
  }

  function drawKurumeBackground() {
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#5eb0e8");
    sky.addColorStop(0.45, "#9ed4f5");
    sky.addColorStop(0.72, "#d4e8c8");
    sky.addColorStop(1, "#8fbc6a");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    const parallax = (factor) => -cameraX * factor;

    ctx.save();
    ctx.translate(parallax(0.08), 0);

    ctx.fillStyle = "rgba(255,255,255,0.5)";
    for (let i = 0; i < 5; i++) {
      const cx = (i * 200 + 60) % (W + 120);
      ctx.beginPath();
      ctx.ellipse(cx, 55 + i * 10, 55, 20, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.15), 0);
    drawMinoRange(80, H - 200, 420, 200);
    drawMinoRange(520, H - 220, 380, 210);
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.28), 0);
    drawMinoRange(-40, H - 170, 500, 165);
    ctx.fillStyle = "rgba(45,90,50,0.35)";
    ctx.fillRect(0, H - 120, W + 200, 80);
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.42), 0);
    const riverY = H - 72;
    const riverGrad = ctx.createLinearGradient(0, riverY - 30, 0, riverY + 40);
    riverGrad.addColorStop(0, "#4a9fd4");
    riverGrad.addColorStop(0.5, "#2e7eb8");
    riverGrad.addColorStop(1, "#1a5f8f");
    ctx.fillStyle = riverGrad;
    ctx.beginPath();
    ctx.moveTo(-20, riverY);
    for (let x = 0; x <= W + 40; x += 60) {
      const wave = Math.sin((x + cameraX * 0.5) * 0.04) * 6;
      ctx.lineTo(x, riverY + wave);
    }
    ctx.lineTo(W + 40, H);
    ctx.lineTo(-20, H);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 2;
    for (let x = 0; x < W; x += 80) {
      const y = riverY + Math.sin((x + cameraX) * 0.08) * 4;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + 25, y - 6, x + 50, y);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(30,80,50,0.5)";
    ctx.fillRect(0, riverY + 8, W, 24);
    ctx.restore();

    ctx.fillStyle = "#6a9e4a";
    ctx.fillRect(0, GROUND_Y, W, H - GROUND_Y);
    ctx.fillStyle = "#5a8e3a";
    for (let x = -(cameraX % 36); x < W; x += 36) {
      ctx.fillRect(x, GROUND_Y, 32, 6);
    }

    ctx.fillStyle = "rgba(0,0,0,0.12)";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("耳納連山", 24 + parallax(0.15), H - 215);
    ctx.fillText("筑後川", 24 + parallax(0.42), H - 88);
  }

  function drawMinoRange(ox, baseY, width, height) {
    const peaks = [
      { x: 0.15, h: 0.95 },
      { x: 0.35, h: 0.75 },
      { x: 0.55, h: 1 },
      { x: 0.72, h: 0.7 },
      { x: 0.88, h: 0.85 },
    ];
    const grad = ctx.createLinearGradient(ox, baseY - height, ox, baseY);
    grad.addColorStop(0, "#6b8f71");
    grad.addColorStop(0.4, "#4d7356");
    grad.addColorStop(1, "#3a5c44");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(ox, baseY);
    for (const p of peaks) {
      ctx.lineTo(ox + width * p.x, baseY - height * p.h);
    }
    ctx.lineTo(ox + width, baseY);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.55)";
    ctx.beginPath();
    ctx.moveTo(ox + width * 0.5, baseY - height);
    ctx.lineTo(ox + width * 0.58, baseY - height * 0.72);
    ctx.lineTo(ox + width * 0.48, baseY - height * 0.78);
    ctx.closePath();
    ctx.fill();
  }

  function drawJojimaTile(x, y, w, h) {
    const tileW = 28;
    const rows = Math.ceil(h / 12);
    for (let row = 0; row < rows; row++) {
      const ty = y + row * 12;
      const rowH = Math.min(12, y + h - ty);
      for (let tx = x; tx < x + w; tx += tileW) {
        const tw = Math.min(tileW, x + w - tx);
        const base = row % 2 === 0 ? "#4a4f58" : "#3d424a";
        ctx.fillStyle = base;
        ctx.fillRect(tx, ty, tw, rowH);
        ctx.fillStyle = "#5c6370";
        ctx.beginPath();
        ctx.arc(tx + tw / 2, ty, tw / 2, Math.PI, 0);
        ctx.fill();
        ctx.strokeStyle = "#2e3339";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(tx + tw / 2, ty, tw / 2 - 1, Math.PI, 0);
        ctx.stroke();
        ctx.fillStyle = "rgba(255,255,255,0.08)";
        ctx.fillRect(tx + 2, ty + 2, tw - 4, rowH - 3);
      }
    }
    ctx.strokeStyle = "#2a2e34";
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
  }

  function drawWaterDrop(cx, cy, r) {
    const bob = Math.sin(Date.now() * 0.007 + cx) * 2.5;
    const y = cy + bob;
    ctx.save();
    ctx.translate(cx, y);
    const grad = ctx.createRadialGradient(-r * 0.2, -r * 0.3, 1, 0, 0, r * 1.4);
    grad.addColorStop(0, "#e8f7ff");
    grad.addColorStop(0.35, "#6ecfff");
    grad.addColorStop(0.75, "#2e8fd4");
    grad.addColorStop(1, "#1a6fa8");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, -r * 1.3);
    ctx.bezierCurveTo(r * 0.9, -r * 0.2, r * 0.75, r * 0.85, 0, r);
    ctx.bezierCurveTo(-r * 0.75, r * 0.85, -r * 0.9, -r * 0.2, 0, -r * 1.3);
    ctx.fill();
    ctx.strokeStyle = "#1565a0";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.65)";
    ctx.beginPath();
    ctx.ellipse(-r * 0.25, -r * 0.35, r * 0.22, r * 0.35, -0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawWorld() {
    ctx.save();
    ctx.translate(-cameraX, isRamenFx() ? (Math.random() - 0.5) * 6 : 0);

    for (const g of gaps) {
      const water = ctx.createLinearGradient(g.x, GROUND_Y, g.x, H);
      water.addColorStop(0, "#3d8ec4");
      water.addColorStop(1, "#1e5f8a");
      ctx.fillStyle = water;
      ctx.fillRect(g.x, GROUND_Y, g.w, H - GROUND_Y);
    }

    for (const s of solids) {
      if (s.ground || s.broken || s.y >= GROUND_Y) continue;
      drawJojimaTile(s.x, s.y, s.w, s.h);
    }

    for (const d of droplets) {
      if (d.taken) continue;
      drawWaterDrop(d.x, d.y, d.r);
    }

    for (const f of foodPickups) {
      if (f.taken) continue;
      drawFoodPickup(f);
    }

    for (const p of projectiles) drawProjectile(p);

    drawKnockFxWorld();

    for (const e of enemies) {
      if (e.knocked) {
        drawKnockedEnemy(e);
        continue;
      }
      if (!e.alive) continue;
      if (e.fly) drawFlyingEnemy(e);
      else drawGroundEnemy(e);
    }

    const poleX = goal.x + goal.w / 2;
    ctx.fillStyle = "#666";
    ctx.fillRect(poleX - 3, goal.y, 6, goal.h);
    ctx.fillStyle = player.won ? "#43a047" : "#e53935";
    ctx.beginPath();
    ctx.moveTo(poleX + 3, goal.y + 12);
    ctx.lineTo(poleX + 52, goal.y + 36);
    ctx.lineTo(poleX + 3, goal.y + 60);
    ctx.closePath();
    ctx.fill();

    drawPlayer();
    drawWaterStream();
    ctx.restore();
  }

  function drawWaterStream() {
    if (!isRamenFx()) return;

    const elapsed = now() - player.ramenFxStart;
    const grow = Math.min(1, elapsed / 120);
    const fade =
      elapsed < 550 ? 1 : Math.max(0, 1 - (elapsed - 550) / (RAMEN_FX_MS - 550));
    if (fade <= 0) return;

    const ox = player.beamOriginX;
    const oy = player.beamOriginY;
    const facing = player.beamDir;
    const reach = WATER_ATTACK_RANGE * (0.35 + grow * 0.65);
    const t = elapsed * 0.11;

    const buildTsunamiWedge = (radius, bulge) => {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      const segments = 28;
      for (let i = 0; i <= segments; i++) {
        const rel =
          WATER_ATTACK_ANGLE_MIN +
          (i / segments) * (WATER_ATTACK_ANGLE_MAX - WATER_ATTACK_ANGLE_MIN);
        const ang = facing > 0 ? -rel : Math.PI + rel;
        const wave =
          Math.sin(t * 2.8 + i * 0.65) * bulge +
          Math.sin(t * 4.2 + i * 1.3) * (bulge * 0.45);
        const r = radius + wave * (0.35 + (i / segments) * 0.65);
        ctx.lineTo(Math.cos(ang) * r, Math.sin(ang) * r);
      }
      ctx.closePath();
    };

    ctx.save();
    ctx.translate(ox, oy);

    // 津波本体（厚い水塊）
    buildTsunamiWedge(reach, 32);
    const bodyGrad = ctx.createRadialGradient(0, 0, 8, 0, 0, reach);
    bodyGrad.addColorStop(0, `rgba(230, 248, 255, ${0.98 * fade})`);
    bodyGrad.addColorStop(0.2, `rgba(100, 190, 245, ${0.92 * fade})`);
    bodyGrad.addColorStop(0.55, `rgba(30, 120, 210, ${0.88 * fade})`);
    bodyGrad.addColorStop(0.85, `rgba(15, 80, 170, ${0.8 * fade})`);
    bodyGrad.addColorStop(1, `rgba(8, 50, 120, ${0.65 * fade})`);
    ctx.fillStyle = bodyGrad;
    ctx.fill();

    // 内側のうねり
    buildTsunamiWedge(reach * 0.78, 24);
    ctx.fillStyle = `rgba(160, 220, 255, ${0.55 * fade})`;
    ctx.fill();

    buildTsunamiWedge(reach * 0.52, 16);
    ctx.fillStyle = `rgba(210, 240, 255, ${0.45 * fade})`;
    ctx.fill();

    // 先端の白波（津波の波頭）
    ctx.save();
    buildTsunamiWedge(reach, 38);
    ctx.clip();
    for (let band = 0; band < 6; band++) {
      const bandR = reach * (0.55 + band * 0.08);
      ctx.strokeStyle = `rgba(255, 255, 255, ${(0.55 - band * 0.06) * fade})`;
      ctx.lineWidth = 18 - band * 2;
      ctx.lineCap = "round";
      ctx.beginPath();
      if (facing > 0) {
        const startAng = -WATER_ATTACK_ANGLE_MIN;
        const endAng = -WATER_ATTACK_ANGLE_MAX;
        ctx.arc(0, 0, bandR, startAng, endAng, false);
      } else {
        const startAng = Math.PI + WATER_ATTACK_ANGLE_MIN;
        const endAng = Math.PI + WATER_ATTACK_ANGLE_MAX;
        ctx.arc(0, 0, bandR, startAng, endAng, false);
      }
      ctx.stroke();
    }
    ctx.restore();

    // 外縁の泡
    ctx.lineWidth = 16;
    ctx.strokeStyle = `rgba(255, 255, 255, ${0.9 * fade})`;
    ctx.lineCap = "round";
    ctx.beginPath();
    if (facing > 0) {
      const startAng = -WATER_ATTACK_ANGLE_MIN;
      const endAng = -WATER_ATTACK_ANGLE_MAX;
      ctx.arc(0, 0, reach * 0.96, startAng, endAng, false);
    } else {
      const startAng = Math.PI + WATER_ATTACK_ANGLE_MIN;
      const endAng = Math.PI + WATER_ATTACK_ANGLE_MAX;
      ctx.arc(0, 0, reach * 0.96, startAng, endAng, false);
    }
    ctx.stroke();

    ctx.lineWidth = 8;
    ctx.strokeStyle = `rgba(180, 230, 255, ${0.75 * fade})`;
    ctx.stroke();

    // 口元の爆発的な水しぶき
    const mouthGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, 72);
    mouthGrad.addColorStop(0, `rgba(255, 255, 255, ${0.98 * fade})`);
    mouthGrad.addColorStop(0.35, `rgba(170, 230, 255, ${0.85 * fade})`);
    mouthGrad.addColorStop(1, `rgba(60, 150, 230, ${0})`);
    ctx.fillStyle = mouthGrad;
    ctx.beginPath();
    ctx.arc(0, 0, 58 + Math.sin(t * 3.5) * 10, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();

    // 飛沫（大きめ）
    for (const p of waterParticles) {
      const a = Math.max(0, p.life / p.maxLife);
      const ang = Math.atan2(p.vy, p.vx);
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(ang);
      ctx.globalAlpha = a * fade * 0.9;
      const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, p.size);
      grad.addColorStop(0, "rgba(255,255,255,0.98)");
      grad.addColorStop(0.4, "rgba(150, 215, 255, 0.9)");
      grad.addColorStop(1, "rgba(40, 120, 210, 0)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.ellipse(0, 0, p.size * p.stretch, p.size * 0.85, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    ctx.globalAlpha = 1;

    if (fade > 0.35) {
      ctx.fillStyle = `rgba(255, 255, 255, ${0.92 * fade})`;
      ctx.strokeStyle = `rgba(20, 90, 180, ${0.9 * fade})`;
      ctx.lineWidth = 4;
      ctx.font = `bold ${22 + Math.sin(t * 3) * 3}px sans-serif`;
      ctx.textAlign = "center";
      const tx = ox + (facing > 0 ? reach * 0.28 : -reach * 0.28);
      const ty = oy - reach * 0.22 - Math.sin(t * 4) * 6;
      ctx.strokeText("津波ドゴォォン！", tx, ty);
      ctx.fillText("津波ドゴォォン！", tx, ty);
    }
  }

  function drawGroundEnemy(e) {
    ctx.fillStyle = "#5d4037";
    ctx.fillRect(e.x, e.y, e.w, e.h);
    ctx.fillStyle = "#fff";
    ctx.fillRect(e.x + 8, e.y + 10, 8, 8);
    ctx.fillRect(e.x + 20, e.y + 10, 8, 8);
  }

  function drawKnockFxWorld() {
    for (const p of knockFx) {
      const alpha = Math.max(0, p.life / (p.maxLife || 24));
      if (p.kind === "spark") {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.min(1, p.life / 12);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      } else if (p.kind === "ring") {
        ctx.strokeStyle = `rgba(255, 235, 59, ${alpha})`;
        ctx.lineWidth = 4;
        const r = p.size * (1 - alpha * 0.35);
        ctx.beginPath();
        ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
        ctx.stroke();
      } else if (p.kind === "text") {
        ctx.fillStyle = `rgba(255, 87, 34, ${Math.min(1, p.life / 10)})`;
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 3;
        ctx.font = "bold 18px sans-serif";
        ctx.textAlign = "center";
        ctx.strokeText(p.text, p.x, p.y);
        ctx.fillText(p.text, p.x, p.y);
      }
    }
  }

  function drawKnockedEnemy(e) {
    const cx = e.x + e.w / 2;
    const cy = e.y + e.h / 2;

    if (e.knockTrail && e.knockTrail.length > 1) {
      ctx.save();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.55)";
      ctx.lineWidth = 3;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(e.knockTrail[0].x, e.knockTrail[0].y);
      for (let i = 1; i < e.knockTrail.length; i++) {
        ctx.lineTo(e.knockTrail[i].x, e.knockTrail[i].y);
      }
      ctx.stroke();
      ctx.strokeStyle = "rgba(255, 152, 0, 0.45)";
      ctx.lineWidth = 8;
      ctx.beginPath();
      const t0 = e.knockTrail[0];
      const t1 = e.knockTrail[e.knockTrail.length - 1];
      ctx.moveTo(t0.x, t0.y);
      ctx.lineTo(t1.x, t1.y);
      ctx.stroke();
      ctx.restore();
    }

    if (e.knockFlash > 0) {
      ctx.save();
      ctx.fillStyle = `rgba(255, 255, 255, ${0.25 + (e.knockFlash % 4) * 0.08})`;
      ctx.beginPath();
      ctx.arc(cx, cy, e.w * 0.9, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    const speed = Math.hypot(e.knockVx || 0, e.knockVy || 0);
    if (speed > 2) {
      const ang = Math.atan2(e.knockVy, e.knockVx);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(ang);
      ctx.strokeStyle = "rgba(255,255,255,0.7)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) {
        const off = -18 - i * 12;
        ctx.beginPath();
        ctx.moveTo(off, -6 + i * 6);
        ctx.lineTo(off - 16 - speed, -6 + i * 6);
        ctx.stroke();
      }
      ctx.restore();
    }

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(e.knockSpin || 0);
    const scale = 1 + (e.knockFlash > 0 ? 0.18 : 0);
    ctx.scale(scale, scale);
    if (e.fly) {
      ctx.fillStyle = "#ffe082";
      ctx.fillRect(-e.w / 2, -e.h / 2, e.w, e.h);
      ctx.fillStyle = "#6d4c41";
      ctx.beginPath();
      ctx.ellipse(0, 0, e.w * 0.35, e.h * 0.35, 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = "#5d4037";
      ctx.fillRect(-e.w / 2, -e.h / 2, e.w, e.h);
      ctx.fillStyle = "#fff";
      ctx.fillRect(-e.w / 2 + 8, -e.h / 2 + 10, 8, 8);
      ctx.fillRect(-e.w / 2 + 20, -e.h / 2 + 10, 8, 8);
    }
    ctx.restore();
  }

  function drawFlyingEnemy(e) {
    const cx = e.x + e.w / 2;
    const cy = e.y + e.h / 2;
    const flap = Math.sin((e.phase || 0) * 2.2) * 0.55;
    const facing = e.vx >= 0 ? 1 : -1;

    ctx.save();
    ctx.translate(cx, cy);

    // 羽
    ctx.fillStyle = "#ffe082";
    ctx.strokeStyle = "#f9a825";
    ctx.lineWidth = 1.5;
    for (const side of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(side * 4, 2);
      ctx.quadraticCurveTo(
        side * (28 + flap * 8),
        -18 - flap * 10,
        side * 8,
        10
      );
      ctx.quadraticCurveTo(side * 16, 4, side * 4, 2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    // 体
    ctx.fillStyle = "#6d4c41";
    ctx.beginPath();
    ctx.ellipse(0, 2, 14, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#8d6e63";
    ctx.beginPath();
    ctx.ellipse(facing * 6, -2, 8, 7, 0, 0, Math.PI * 2);
    ctx.fill();

    // 目
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(facing * 8, -4, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#111";
    ctx.beginPath();
    ctx.arc(facing * 9, -4, 1.6, 0, Math.PI * 2);
    ctx.fill();

    // くちばし
    ctx.fillStyle = "#ff7043";
    ctx.beginPath();
    ctx.moveTo(facing * 14, -1);
    ctx.lineTo(facing * 22, 2);
    ctx.lineTo(facing * 14, 5);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  function drawFoodPickup(f) {
    const bob = Math.sin(Date.now() * 0.005 + f.x) * 3;
    const y = f.y + bob;
    ctx.save();
    ctx.translate(f.x, y);
    if (f.type === "ramen") {
      ctx.fillStyle = "#f5e6c8";
      ctx.beginPath();
      ctx.ellipse(0, 4, 16, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#c45c26";
      ctx.fillRect(-14, -8, 28, 14);
      ctx.fillStyle = "#ffd54f";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("ラ", 0, 2);
    } else if (f.type === "yakitori") {
      ctx.strokeStyle = "#5d4037";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, -18);
      ctx.lineTo(0, 18);
      ctx.stroke();
      ctx.fillStyle = "#c45c26";
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath();
        ctx.arc(0, i * 10, 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = "#efe0c8";
      ctx.beginPath();
      ctx.arc(0, 16, 3, 0, Math.PI * 2);
      ctx.fill();
    } else if (f.type === "udon") {
      ctx.fillStyle = "#efe0c8";
      ctx.beginPath();
      ctx.ellipse(0, 6, 18, 11, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#d4a574";
      ctx.lineWidth = 2;
      for (let i = -2; i <= 2; i++) {
        ctx.beginPath();
        ctx.moveTo(-12 + i * 5, -2);
        ctx.quadraticCurveTo(-8 + i * 5, 10, -4 + i * 5, 4);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  function drawProjectile(p) {
    ctx.save();
    ctx.translate(p.x + p.w / 2, p.y + p.h / 2);
    const halfH = p.h / 2;
    ctx.strokeStyle = "#4e342e";
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(0, -halfH);
    ctx.lineTo(0, halfH);
    ctx.stroke();
    ctx.fillStyle = "#bf360c";
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(0, -8 + i * 10, 6.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = "#efe0c8";
    ctx.beginPath();
    ctx.arc(0, halfH - 2, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawPlayer() {
    if (player.dead) return;

    const blinkHurt =
      !player.dying && isHurtIFrames() && Math.floor(now() / 80) % 2 === 0;
    if (blinkHurt) return;

    let img = sprites.stand;
    if (player.dying || player.eatFrames > 0 || isRamenFx()) img = sprites.front;
    else if (!player.onGround) img = sprites.jump;
    else if (Math.abs(player.vx) > 0.3) {
      img = Math.floor(player.anim) % 2 === 0 ? sprites.walk : sprites.stand;
    }
    if (player.won) img = sprites.front;

    const scale = player.h / (img.naturalHeight || 200);
    const dw = (img.naturalWidth || 180) * scale;
    const dh = player.h;
    const cx = player.x + player.w / 2;
    const cy = player.y + player.h / 2;

    if (player.dying) {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(player.deathSpin);
      ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
      ctx.restore();

      const pop = player.deathPause > 0 ? 1.2 : 1;
      ctx.save();
      ctx.fillStyle = "#ffeb3b";
      ctx.strokeStyle = "#c62828";
      ctx.lineWidth = 3;
      ctx.font = `bold ${Math.round(28 * pop)}px sans-serif`;
      ctx.textAlign = "center";
      ctx.strokeText("！", cx + 28, player.y - 4);
      ctx.fillText("！", cx + 28, player.y - 4);
      ctx.restore();
      return;
    }

    ctx.save();
    ctx.translate(cx, cy);
    if (player.facing > 0) {
      ctx.scale(-1, 1);
    }
    ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
    ctx.restore();

    if (player.eatFrames > 0) {
      ctx.save();
      ctx.translate(cx + player.facing * 18, player.y + player.h * 0.35);
      ctx.fillStyle = "#c45c26";
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#5d4037";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-10, 6);
      ctx.lineTo(10, -6);
      ctx.stroke();
      ctx.restore();
    }

    if (hasJumpBoost()) {
      const left = Math.max(0, (player.jumpBoostUntil - now()) / 1000);
      ctx.fillStyle = "rgba(100, 180, 255, 0.9)";
      ctx.font = "bold 12px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(`ジャンプ×1.5 ${left.toFixed(1)}s`, cx, player.y - 8);
    }
  }

  function drawHud() {
    if (!started) return;

    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(12, 12, 300, 100);
    ctx.fillStyle = "#fff";
    ctx.font = "bold 15px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(`水滴: ${dropletCount}  スコア: ${score}`, 24, 36);
    ctx.font = "13px sans-serif";
    ctx.fillText(`🍢やきとり×${inventory.yakitori}（1で串投げ）`, 24, 58);

    let effect = "";
    if (isRamenFx()) {
      effect = "水流攻撃発動中！";
    } else if (hasJumpBoost()) {
      const left = Math.max(0, (player.jumpBoostUntil - now()) / 1000);
      effect = `ジャンプ1.5倍 ${left.toFixed(1)}秒`;
    } else if (now() < player.slideUntil) {
      effect = "スライディング！";
    } else if (player.eatFrames > 0) {
      effect = "やきとり食べ中…";
    } else {
      const toWater = dropletCount % 5;
      effect =
        inventory.ramen > 0
          ? `水流（${toWater}/5） ↓でスライディング（${inventory.ramen}回分）`
          : `水流（${toWater}/5） 水滴5つで発動、↓はラーメン必須`;
    }
    ctx.fillText(effect, 24, 78);
    ctx.font = "bold 14px sans-serif";
    ctx.fillText(
      player.won
        ? "クリア！"
        : player.dying
          ? "びっくら！"
          : player.dead
            ? "…"
            : "がんばれ！",
      24,
      98
    );
  }

  function loop() {
    if (!loopRunning || loaded < needLoad) return;
    if (started) {
      updatePlayer();
      updateRamenBeam();
      updateWaterParticles();
      updateProjectiles();
      updateKnockFx();
      updateEnemies();
      updateCamera();
    }
    drawKurumeBackground();
    drawWorld();
    drawHud();
    requestAnimationFrame(loop);
  }

  if (startBtn) {
    startBtn.addEventListener("click", () => startGame());
  }

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) loopRunning = false;
    else if (loaded >= needLoad) {
      loopRunning = true;
      requestAnimationFrame(loop);
    }
  });
})();

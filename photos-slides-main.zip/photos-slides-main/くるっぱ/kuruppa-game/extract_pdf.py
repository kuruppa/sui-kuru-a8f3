"""Extract images from kuruppa character PDF."""
import os
import sys

try:
    import fitz
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pymupdf", "-q"])
    import fitz

PDF = r"c:\Users\newor\Downloads\p1eq74hec6j96qkjrorn301gpb4.pdf"
OUT = os.path.join(os.path.dirname(__file__), "assets")
os.makedirs(OUT, exist_ok=True)

doc = fitz.open(PDF)
print("pages", doc.page_count)
img_idx = 0
for pi in range(doc.page_count):
    page = doc[pi]
    for img in page.get_images(full=True):
        xref = img[0]
        base = doc.extract_image(xref)
        ext = base["ext"]
        path = os.path.join(OUT, f"extracted_{img_idx}.{ext}")
        with open(path, "wb") as f:
            f.write(base["image"])
        print("image", path, base["width"], base["height"])
        img_idx += 1
    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
    rp = os.path.join(OUT, f"page_{pi}.png")
    pix.save(rp)
    print("render", rp, pix.width, pix.height)
doc.close()

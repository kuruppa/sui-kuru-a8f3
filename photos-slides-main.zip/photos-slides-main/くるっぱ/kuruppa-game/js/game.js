(() => {
  "use strict";

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const statusEl = document.getElementById("status");

  const W = canvas.width;
  const H = canvas.height;
  const GRAVITY = 0.62;
  const MOVE_SPEED = 4.6;
  const JUMP_VEL = -12.2;
  const WORLD_W = 3200;

  const keys = new Set();

  const sprites = {
    stand: loadImage("sprites/kuruppa-stand.png"),
    walk: loadImage("sprites/kuruppa-walk.png"),
    jump: loadImage("sprites/kuruppa-jump.png"),
    front: loadImage("sprites/kuruppa-front.png"),
  };

  /** @type {Array<{x:number,y:number,w:number,h:number}>} */
  const solids = [
    { x: 0, y: H - 48, w: WORLD_W, h: 48 },
    { x: 280, y: H - 128, w: 160, h: 24 },
    { x: 520, y: H - 200, w: 120, h: 24 },
    { x: 720, y: H - 160, w: 100, h: 24 },
    { x: 900, y: H - 240, w: 140, h: 24 },
    { x: 1120, y: H - 180, w: 120, h: 24 },
    { x: 1320, y: H - 280, w: 160, h: 24 },
    { x: 1560, y: H - 200, w: 100, h: 24 },
    { x: 1740, y: H - 320, w: 180, h: 24 },
    { x: 1980, y: H - 220, w: 120, h: 24 },
    { x: 2180, y: H - 160, w: 140, h: 24 },
    { x: 2420, y: H - 260, w: 160, h: 24 },
    { x: 2660, y: H - 180, w: 120, h: 24 },
    { x: 2860, y: H - 140, w: 200, h: 24 },
  ];

  /** Gaps in ground */
  const gaps = [
    { x: 640, w: 80 },
    { x: 1480, w: 96 },
    { x: 2280, w: 88 },
  ];

  /** @type {Array<{x:number,y:number,r:number,taken:boolean}>} */
  const coins = [];
  for (let i = 0; i < 18; i++) {
    coins.push({
      x: 200 + i * 155 + (i % 3) * 20,
      y: H - 100 - (i % 4) * 55,
      r: 14,
      taken: false,
    });
  }

  /** @type {Array<{x:number,y:number,w:number,h:number,vx:number,alive:boolean}>} */
  const enemies = [
    { x: 420, y: H - 88, w: 36, h: 36, vx: 1.4, alive: true },
    { x: 1050, y: H - 88, w: 36, h: 36, vx: -1.6, alive: true },
    { x: 1850, y: H - 88, w: 36, h: 36, vx: 1.5, alive: true },
    { x: 2550, y: H - 88, w: 36, h: 36, vx: -1.3, alive: true },
  ];

  const goal = { x: WORLD_W - 120, y: H - 200, w: 48, h: 152 };

  const player = {
    x: 64,
    y: H - 200,
    w: 52,
    h: 64,
    vx: 0,
    vy: 0,
    onGround: false,
    facing: 1,
    anim: 0,
    won: false,
    dead: false,
  };

  let cameraX = 0;
  let score = 0;
  let loaded = 0;
  let loopRunning = false;
  const needLoad = Object.keys(sprites).length;

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      loopRunning = false;
    } else if (loaded >= needLoad && !loopRunning) {
      loopRunning = true;
      requestAnimationFrame(loop);
    }
  });

  function loadImage(src) {
    const img = new Image();
    img.onload = () => {
      loaded += 1;
      if (loaded >= needLoad) {
        statusEl.textContent = "きゅうりを集めて、右端のゴールへ！";
        if (!loopRunning) {
          loopRunning = true;
          requestAnimationFrame(loop);
        }
      }
    };
    img.onerror = () => {
      statusEl.textContent =
        "スプライトの読み込みに失敗しました。prepare_sprites.py を実行してください。";
    };
    img.src = src;
    return img;
  }

  function resetGame() {
    player.x = 64;
    player.y = H - 200;
    player.vx = 0;
    player.vy = 0;
    player.onGround = false;
    player.facing = 1;
    player.won = false;
    player.dead = false;
    cameraX = 0;
    score = 0;
    for (const c of coins) c.taken = false;
    for (const e of enemies) e.alive = true;
    statusEl.textContent = "きゅうりを集めて、右端のゴールへ！";
  }

  window.addEventListener("keydown", (e) => {
    if (["ArrowLeft", "ArrowRight", "ArrowUp", " ", "a", "d", "w"].includes(e.key)) {
      e.preventDefault();
    }
    if (e.key === "r" || e.key === "R") resetGame();
    keys.add(e.key);
  });
  window.addEventListener("keyup", (e) => keys.delete(e.key));

  function isDown(...names) {
    return names.some((k) => keys.has(k));
  }

  function rectOverlap(a, b) {
    return (
      a.x < b.x + b.w &&
      a.x + a.w > b.x &&
      a.y < b.y + b.h &&
      a.y + a.h > b.y
    );
  }

  function inGap(x, w) {
    const cx = x + w / 2;
    return gaps.some((g) => cx > g.x && cx < g.x + g.w);
  }

  function resolveAxis(entity, solidsList, axis) {
    for (const s of solidsList) {
      if (!rectOverlap(entity, s)) continue;
      if (axis === "x") {
        if (entity.vx > 0) entity.x = s.x - entity.w;
        else if (entity.vx < 0) entity.x = s.x + s.w - entity.w;
        entity.vx = 0;
      } else {
        if (entity.vy > 0) {
          entity.y = s.y - entity.h;
          entity.vy = 0;
          entity.onGround = true;
        } else if (entity.vy < 0) {
          entity.y = s.y + s.h;
          entity.vy = 0;
        }
      }
    }
  }

  function updatePlayer() {
    if (player.won || player.dead) return;

    player.onGround = false;
    if (isDown("ArrowLeft", "a", "A")) {
      player.vx = -MOVE_SPEED;
      player.facing = -1;
    } else if (isDown("ArrowRight", "d", "D")) {
      player.vx = MOVE_SPEED;
      player.facing = 1;
    } else {
      player.vx *= 0.72;
      if (Math.abs(player.vx) < 0.15) player.vx = 0;
    }

    if (
      (isDown(" ", "ArrowUp", "w", "W")) &&
      player.onGround
    ) {
      player.vy = JUMP_VEL;
      player.onGround = false;
    }

    player.vy += GRAVITY;
    player.x += player.vx;
    resolveAxis(player, solids, "x");
    player.y += player.vy;
    resolveAxis(player, solids, "y");

    if (player.x < 0) player.x = 0;
    if (player.x + player.w > WORLD_W) player.x = WORLD_W - player.w;

    const footY = player.y + player.h;
    if (footY >= H - 48 && !inGap(player.x, player.w)) {
      player.y = H - 48 - player.h;
      player.vy = 0;
      player.onGround = true;
    }

    if (player.y > H + 40) {
      player.dead = true;
      statusEl.textContent = "落ちちゃった… R でリトライ";
    }

    if (Math.abs(player.vx) > 0.3 && player.onGround) {
      player.anim += 0.18;
    }

    for (const c of coins) {
      if (c.taken) continue;
      const dx = player.x + player.w / 2 - c.x;
      const dy = player.y + player.h / 2 - c.y;
      if (dx * dx + dy * dy < (c.r + 24) ** 2) {
        c.taken = true;
        score += 10;
      }
    }

    for (const e of enemies) {
      if (!e.alive) continue;
      const hit = rectOverlap(player, e);
      if (!hit) continue;
      const stomp =
        player.vy > 0 && player.y + player.h - e.y < e.h * 0.55;
      if (stomp) {
        e.alive = false;
        player.vy = JUMP_VEL * 0.55;
        score += 25;
      } else {
        player.dead = true;
        statusEl.textContent = "くるっぱがやられた… R でリトライ";
      }
    }

    if (rectOverlap(player, goal)) {
      player.won = true;
      statusEl.textContent = `ゴール！ スコア ${score} — R でもう一度`;
    }
  }

  function updateEnemies() {
    for (const e of enemies) {
      if (!e.alive) continue;
      e.x += e.vx;
      const box = { x: e.x, y: e.y, w: e.w, h: e.h };
      let hit = false;
      for (const s of solids) {
        if (rectOverlap(box, s)) hit = true;
      }
      const onFloor = e.y + e.h >= H - 48 && !inGap(e.x, e.w);
      if (hit || e.x < 40 || e.x > WORLD_W - 60 || onFloor) {
        e.vx *= -1;
        e.x += e.vx * 2;
      }
    }
  }

  function updateCamera() {
    const target = player.x + player.w / 2 - W / 2;
    cameraX += (target - cameraX) * 0.12;
    cameraX = Math.max(0, Math.min(cameraX, WORLD_W - W));
  }

  function drawMinoRange(ox, baseY, width, height) {
    const peaks = [
      { x: 0.12, h: 0.88 },
      { x: 0.32, h: 0.72 },
      { x: 0.52, h: 1 },
      { x: 0.7, h: 0.78 },
      { x: 0.9, h: 0.92 },
    ];
    const grad = ctx.createLinearGradient(ox, baseY - height, ox, baseY);
    grad.addColorStop(0, "#6b8f71");
    grad.addColorStop(0.45, "#4d7356");
    grad.addColorStop(1, "#3a5c44");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(ox, baseY);
    for (const p of peaks) {
      ctx.lineTo(ox + width * p.x, baseY - height * p.h);
    }
    ctx.lineTo(ox + width, baseY);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.5)";
    ctx.beginPath();
    ctx.moveTo(ox + width * 0.51, baseY - height);
    ctx.lineTo(ox + width * 0.6, baseY - height * 0.7);
    ctx.lineTo(ox + width * 0.47, baseY - height * 0.76);
    ctx.closePath();
    ctx.fill();
  }

  function drawBackground() {
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#5eb0e8");
    sky.addColorStop(0.5, "#9ed4f5");
    sky.addColorStop(0.78, "#d4e8c8");
    sky.addColorStop(1, "#8fbc6a");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    const parallax = (factor) => -cameraX * factor;

    ctx.save();
    ctx.translate(parallax(0.1), 0);
    ctx.fillStyle = "rgba(255,255,255,0.45)";
    for (let i = 0; i < 5; i++) {
      const cx = (i * 190 + 40) % (W + 100);
      ctx.beginPath();
      ctx.ellipse(cx, 50 + i * 8, 50, 18, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.18), 0);
    drawMinoRange(60, H - 195, 400, 185);
    drawMinoRange(500, H - 210, 360, 195);
    ctx.restore();

    ctx.save();
    ctx.translate(parallax(0.3), 0);
    drawMinoRange(-30, H - 165, 480, 155);
    ctx.fillStyle = "rgba(45,90,50,0.3)";
    ctx.fillRect(0, H - 115, W + 160, 70);
    ctx.restore();

    ctx.fillStyle = "rgba(0,0,0,0.1)";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("耳納連山", 20 + parallax(0.18), H - 205);

    ctx.fillStyle = "#6a9e4a";
    ctx.fillRect(0, H - 48, W, 48);
    ctx.fillStyle = "#5a8e3a";
    for (let x = -(cameraX % 36); x < W; x += 36) {
      ctx.fillRect(x, H - 48, 32, 6);
    }
  }

  function drawJojimaTile(x, y, w, h) {
    const tileW = 28;
    const rows = Math.ceil(h / 12);
    for (let row = 0; row < rows; row++) {
      const ty = y + row * 12;
      const rowH = Math.min(12, y + h - ty);
      for (let tx = x; tx < x + w; tx += tileW) {
        const tw = Math.min(tileW, x + w - tx);
        const base = row % 2 === 0 ? "#4a4f58" : "#3d424a";
        ctx.fillStyle = base;
        ctx.fillRect(tx, ty, tw, rowH);
        ctx.fillStyle = "#5c6370";
        ctx.beginPath();
        ctx.arc(tx + tw / 2, ty, tw / 2, Math.PI, 0);
        ctx.fill();
        ctx.strokeStyle = "#2e3339";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(tx + tw / 2, ty, tw / 2 - 1, Math.PI, 0);
        ctx.stroke();
        ctx.fillStyle = "rgba(255,255,255,0.08)";
        ctx.fillRect(tx + 2, ty + 2, tw - 4, rowH - 3);
      }
    }
    ctx.strokeStyle = "#2a2e34";
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
  }

  function drawCucumber(cx, cy, r) {
    const bob = Math.sin(Date.now() * 0.006 + cx) * 2;
    const y = cy + bob;
    ctx.save();
    ctx.translate(cx, y);
    ctx.rotate(-0.35);
    const grad = ctx.createLinearGradient(-r, 0, r, 0);
    grad.addColorStop(0, "#3d7a34");
    grad.addColorStop(0.5, "#5cb34a");
    grad.addColorStop(1, "#2e6b28");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(0, 0, r * 1.5, r * 0.65, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#245a20";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.strokeStyle = "rgba(30,80,25,0.5)";
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 5 - 8, -2);
      ctx.lineTo(i * 5 + 8, 2);
      ctx.stroke();
    }
    ctx.fillStyle = "#6ec45c";
    ctx.beginPath();
    ctx.ellipse(-r * 1.35, 0, 4, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawWorld() {
    ctx.save();
    ctx.translate(-cameraX, 0);

    for (const g of gaps) {
      ctx.fillStyle = "#4a8fd4";
      ctx.fillRect(g.x, H - 48, g.w, 48);
    }

    for (const s of solids) {
      if (s.y >= H - 48) continue;
      drawJojimaTile(s.x, s.y, s.w, s.h);
    }

    for (const c of coins) {
      if (c.taken) continue;
      drawCucumber(c.x, c.y, c.r);
    }

    for (const e of enemies) {
      if (!e.alive) continue;
      ctx.fillStyle = "#6d4c41";
      ctx.fillRect(e.x, e.y, e.w, e.h);
      ctx.fillStyle = "#fff";
      ctx.fillRect(e.x + 8, e.y + 10, 8, 8);
      ctx.fillRect(e.x + 20, e.y + 10, 8, 8);
      ctx.fillStyle = "#333";
      ctx.fillRect(e.x + 10, e.y + 26, 16, 4);
    }

    const poleX = goal.x + goal.w / 2;
    ctx.fillStyle = "#888";
    ctx.fillRect(poleX - 3, goal.y, 6, goal.h);
    ctx.fillStyle = player.won ? "#4caf50" : "#e53935";
    ctx.beginPath();
    ctx.moveTo(poleX + 3, goal.y + 12);
    ctx.lineTo(poleX + 52, goal.y + 36);
    ctx.lineTo(poleX + 3, goal.y + 60);
    ctx.closePath();
    ctx.fill();

    drawPlayer();

    ctx.restore();
  }

  function drawPlayer() {
    let img = sprites.stand;
    if (!player.onGround) img = sprites.jump;
    else if (Math.abs(player.vx) > 0.3) {
      img = Math.floor(player.anim) % 2 === 0 ? sprites.walk : sprites.stand;
    }
    if (player.won) img = sprites.front;

    const scale = player.h / (img.naturalHeight || 200);
    const dw = (img.naturalWidth || 180) * scale;
    const dh = player.h;
    const dx = player.x + (player.w - dw) / 2;
    const dy = player.y + player.h - dh;

    ctx.save();
    if (player.facing < 0) {
      ctx.translate(dx + dw, dy);
      ctx.scale(-1, 1);
      ctx.drawImage(img, 0, 0, dw, dh);
    } else {
      ctx.drawImage(img, dx, dy, dw, dh);
    }
    ctx.restore();
  }

  function drawHud() {
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.fillRect(12, 12, 200, 56);
    ctx.fillStyle = "#fff";
    ctx.font = "bold 16px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(`きゅうり: ${score}`, 24, 38);
    ctx.fillText(player.won ? "クリア！" : player.dead ? "…" : "がんばれ！", 24, 58);
  }

  function loop() {
    if (!loopRunning || loaded < needLoad) return;
    updatePlayer();
    updateEnemies();
    updateCamera();

    drawBackground();
    drawWorld();
    drawHud();

    requestAnimationFrame(loop);
  }
})();

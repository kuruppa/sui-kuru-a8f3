"""Copy selected Kuruppa sprites from PDF extraction and trim white background."""
import os
import shutil

try:
    from PIL import Image
except ImportError:
    import subprocess
    import sys

    subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow", "-q"])
    from PIL import Image

BASE = os.path.join(os.path.dirname(__file__), "assets")
OUT = os.path.join(os.path.dirname(__file__), "sprites")
os.makedirs(OUT, exist_ok=True)

MAPPING = {
    "extracted_301.jpeg": "kuruppa-stand.png",
    "extracted_306.jpeg": "kuruppa-walk.png",
    "extracted_305.jpeg": "kuruppa-jump.png",
    "extracted_42.jpeg": "kuruppa-front.png",
}


def white_to_alpha(img: Image.Image, threshold: int = 248) -> Image.Image:
    img = img.convert("RGBA")
    data = img.getdata()
    new = []
    for r, g, b, a in data:
        if r >= threshold and g >= threshold and b >= threshold:
            new.append((r, g, b, 0))
        else:
            new.append((r, g, b, a))
    img.putdata(new)
    bbox = img.getbbox()
    if bbox:
        img = img.crop(bbox)
    return img


for src_name, dst_name in MAPPING.items():
    src = os.path.join(BASE, src_name)
    if not os.path.isfile(src):
        raise FileNotFoundError(src)
    img = Image.open(src)
    img = white_to_alpha(img)
    dst = os.path.join(OUT, dst_name)
    img.save(dst, "PNG")
    print("ok", dst_name, img.size)

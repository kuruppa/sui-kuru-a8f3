# -*- coding: utf-8 -*-
"""久留米大学講義 企画書 Word 生成"""

from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUTPUT = r"c:\Users\newor\こいこい用\photos-slides\kurume_univ_lecture_plan.docx"


def set_japanese_font(run, name="游明朝", size=10.5):
    run.font.name = name
    run.font.size = Pt(size)
    r = run._element
    rPr = r.get_or_add_rPr()
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), name)
    rFonts.set(qn("w:hAnsi"), name)
    rFonts.set(qn("w:eastAsia"), name)
    rPr.insert(0, rFonts)


def add_para(doc, text, bold=False, size=10.5, space_after=3, align=None):
    p = doc.add_paragraph()
    if align:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(text)
    run.bold = bold
    set_japanese_font(run, size=size)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(3)
    run = p.add_run(text)
    run.bold = True
    set_japanese_font(run, size=11 if level == 1 else 10.5)
    return p


def main():
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)

    # 表紙的タイトル
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(2)
    r = title.add_run("久留米大学「地域社会計画論」講義 企画書")
    r.bold = True
    set_japanese_font(r, size=14)

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.paragraph_format.space_after = Pt(12)
    r = sub.add_run("（座学後ワーク・意見収集プログラム）")
    set_japanese_font(r, size=10)

    meta = [
        ("作成", "久留米市 広報戦略"),
        ("講義日", "　　　年　　月　　日"),
        ("提出先", "人材育成室（講義6日前まで）"),
    ]
    for label, value in meta:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(1)
        r1 = p.add_run(f"{label}：")
        r1.bold = True
        set_japanese_font(r1)
        r2 = p.add_run(value)
        set_japanese_font(r2)

    add_heading(doc, "１．企画の目的")
    add_para(
        doc,
        "議会等から「若者の意見を聞く仕組みづくりが必要」という指摘を受けている。本講義を機に、"
        "大学生（若者）の声を移住・来訪の２つの視点から収集する。なお、継続的な仕組みづくりは"
        "講義内では行わず、回収した意見を整理したうえで、江藤教授と次年度に向けて別途相談する。",
    )

    add_heading(doc, "２．講義概要")
    items = [
        ("講義名", "地域社会計画論（久留米大学）"),
        ("担当教員", "江藤教授"),
        ("受講者", "1〜4年生　49名（9割以上が久留米市外から通学）"),
        ("講師", "久留米市（市の取組紹介）"),
        ("時間配分", "座学30〜40分／自由時間20〜30分"),
        ("集合", "12：45　アーチ形入口1F（庶務課前）"),
    ]
    for k, v in items:
        add_para(doc, f"　・{k}：{v}", space_after=1)

    add_heading(doc, "３．プログラム構成")
    add_para(doc, "【座学（30〜40分）】市の取組紹介", bold=True, space_after=2)
    add_para(
        doc,
        "　・久留米市の主要な施策・広報活動等を紹介する。"
        "　・最後に「これから移住・来訪の２つの視点で皆さんの本音を聞かせてください」と橋渡しする。",
        space_after=4,
    )
    add_para(doc, "【座学後ワーク（20〜25分）】意見収集", bold=True, space_after=2)
    steps = [
        ("導入（2分）", "目的説明。「正解はない。思ったことを書いて・話してほしい」"),
        ("個人ワーク（7分）", "意見収集シートに記入（書ける項目のみで可）"),
        ("ペア共有（5分）", "移住・来訪それぞれ1つずつ隣の人と共有"),
        ("全体共有（8分）", "挙手による発言。移住・来訪それぞれ3〜4件を講師がメモ"),
        ("締め（2分）", "回収・お礼。「意見は持ち帰って整理します」"),
    ]
    for step, desc in steps:
        add_para(doc, f"　{step}　{desc}", space_after=1)

    add_heading(doc, "４．意見収集シート（配布・回収）")
    add_para(
        doc,
        "久留米市外から通学する学生の特性を活かし、地元との比較を軸に意見を聞く。"
        "全項目の記入は求めず、個人ワークでは優先項目のみ記入してもらう。",
        space_after=3,
    )
    add_para(doc, "■ 移住の視点", bold=True, space_after=1)
    migration = [
        "地元と比較した住環境（家賃・治安・交通・生活インフラ・就労・若者の場）",
        "入学前のイメージと現在のギャップ",
        "卒業後も住み続けたいか／その理由",
        "長く住むために必要な条件、不安・不便な点",
        "広報で知りたかったのに載っていなかったこと",
    ]
    for m in migration:
        add_para(doc, f"　・{m}", space_after=1)

    add_para(doc, "■ 来訪の視点", bold=True, space_after=1)
    visit = [
        "地元と比較したイベント・グルメ・観光・夜の過ごし方",
        "友達に紹介したい場所・お店（最大3つ）とその理由",
        "地元の友達への「久留米の売り」／紹介しづらい点",
        "地元にはあるが久留米に足りないもの",
        "情報が届きにくい・探しにくいこと",
    ]
    for v in visit:
        add_para(doc, f"　・{v}", space_after=1)
    add_para(doc, "■ 自由記述：市に伝えたいこと／改善してほしいこと", space_after=2)

    add_heading(doc, "５．準備物・当日対応")
    prep = [
        "講義資料（PPT・4：3）…講義6日前までに人材育成室へ提出",
        "意見収集シート…50部印刷（大学側で印刷可の場合はデータ提出）",
        "市の配付資料・パンフ…50部（ボランティア募集・イベント告知等）",
        "筆記用具、回収用クリップまたは封筒",
    ]
    for p in prep:
        add_para(doc, f"　・{p}", space_after=1)

    add_heading(doc, "６．講義後の対応（次年度に向けた相談）")
    follow = [
        "回収シートを整理し、移住・来訪・地元比較のカテゴリに分類する",
        "江藤教授へ、次年度からの継続的な「若者の声を聞く場」のあり方を別途相談する",
        "（例：年1〜2回の意見交換、学期末の意見提出課題、後期フィールドワークへの活用等）",
        "継続の場づくり・学生募集は教授・大学側、聞く・整理・返すは市側、と役割分担する",
    ]
    for f in follow:
        add_para(doc, f"　・{f}", space_after=1)

    doc.save(OUTPUT)
    print(f"Saved: {OUTPUT}")


if __name__ == "__main__":
    main()

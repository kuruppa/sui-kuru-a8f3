import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import time
import re

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont

SEED_URLS = [
    "https://www.kurumepr.com/main/6.html",
    "https://www.kurumepr.com/main/7.html",
]
DOMAIN = "www.kurumepr.com"
OUTPUT_PDF = "kurumepr_all_pages.pdf"
MAX_DEPTH = 2

pdfmetrics.registerFont(UnicodeCIDFont("HeiseiKakuGo-W5"))
pdfmetrics.registerFont(UnicodeCIDFont("HeiseiMin-W3"))

FONT_GOTHIC = "HeiseiKakuGo-W5"
FONT_MINCHO = "HeiseiMin-W3"


def fetch_html(url):
    resp = requests.get(url, timeout=30)
    resp.encoding = resp.apparent_encoding
    return resp.text


def extract_links(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    links = set()
    for a in soup.find_all("a", href=True):
        href = a["href"]
        full_url = urljoin(base_url, href)
        parsed = urlparse(full_url)
        if parsed.netloc == DOMAIN:
            clean = full_url.split("#")[0].split("?")[0]
            if clean.endswith(".html"):
                links.add(clean)
    return links


def crawl_all_pages(seed_urls, max_depth=MAX_DEPTH):
    visited = set()
    to_visit = set(seed_urls)
    all_urls = set()

    for depth in range(max_depth):
        next_level = set()
        for url in sorted(to_visit):
            if url in visited:
                continue
            visited.add(url)
            try:
                print(f"  [depth={depth}] Crawling: {url}")
                html = fetch_html(url)
                found = extract_links(html, url)
                all_urls.update(found)
                next_level.update(found - visited)
                time.sleep(0.3)
            except Exception as e:
                print(f"  Error crawling {url}: {e}")
        to_visit = next_level
        print(f"  Depth {depth} done. Found {len(all_urls)} unique URLs so far.")

    all_urls.update(seed_urls)
    return sorted(all_urls)


def extract_page_content(url):
    try:
        html = fetch_html(url)
        soup = BeautifulSoup(html, "html.parser")

        for tag in soup.find_all(["script", "style", "nav"]):
            tag.decompose()

        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else url

        main = (
            soup.find("main")
            or soup.find("article")
            or soup.find("div", class_=re.compile(r"content|main|entry|post|detail", re.I))
        )
        if not main:
            main = soup.find("body") or soup

        paragraphs = []
        seen_texts = set()
        for el in main.find_all(
            ["h1", "h2", "h3", "h4", "p", "li", "td", "th", "dt", "dd", "figcaption", "blockquote", "div"]
        ):
            if el.name == "div" and not el.find(["h1", "h2", "h3", "h4", "p"], recursive=False):
                children_with_text = [c for c in el.children if isinstance(c, str) and c.strip()]
                if not children_with_text:
                    continue

            text = el.get_text(separator=" ", strip=True)
            if text and len(text) > 1 and text not in seen_texts:
                seen_texts.add(text)
                tag = el.name if el.name != "div" else "p"
                paragraphs.append((tag, text))

        if not paragraphs:
            body = soup.find("body") or soup
            body_text = body.get_text(separator="\n", strip=True)
            for line in body_text.split("\n"):
                line = line.strip()
                if line and len(line) > 1:
                    paragraphs.append(("p", line))

        return title, paragraphs
    except Exception as e:
        print(f"  Error fetching {url}: {e}")
        return url, [("p", f"(Error: {e})")]


def escape_xml(text):
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def build_pdf(pages_data):
    doc = SimpleDocTemplate(
        OUTPUT_PDF,
        pagesize=A4,
        leftMargin=20 * mm,
        rightMargin=20 * mm,
        topMargin=20 * mm,
        bottomMargin=20 * mm,
    )

    styles = getSampleStyleSheet()

    style_cover_title = ParagraphStyle(
        "CoverTitle", parent=styles["Title"],
        fontName=FONT_GOTHIC, fontSize=22, leading=30, alignment=1, spaceAfter=10,
    )
    style_cover_sub = ParagraphStyle(
        "CoverSub", parent=styles["Normal"],
        fontName=FONT_GOTHIC, fontSize=11, leading=16, alignment=1, spaceAfter=6,
    )
    style_toc_title = ParagraphStyle(
        "TocTitle", parent=styles["Heading1"],
        fontName=FONT_GOTHIC, fontSize=14, leading=20, spaceBefore=10, spaceAfter=6,
    )
    style_toc_item = ParagraphStyle(
        "TocItem", parent=styles["Normal"],
        fontName=FONT_MINCHO, fontSize=8, leading=12, spaceAfter=2,
    )
    style_page_title = ParagraphStyle(
        "PageTitle", parent=styles["Heading1"],
        fontName=FONT_GOTHIC, fontSize=13, leading=18, spaceBefore=4, spaceAfter=4,
        textColor="darkblue",
    )
    style_page_url = ParagraphStyle(
        "PageUrl", parent=styles["Normal"],
        fontName=FONT_GOTHIC, fontSize=7, leading=10, textColor="gray", spaceAfter=8,
    )
    style_h1 = ParagraphStyle(
        "H1", parent=styles["Heading1"],
        fontName=FONT_GOTHIC, fontSize=13, leading=18, spaceBefore=10, spaceAfter=4,
    )
    style_h2 = ParagraphStyle(
        "H2", parent=styles["Heading2"],
        fontName=FONT_GOTHIC, fontSize=12, leading=16, spaceBefore=8, spaceAfter=3,
    )
    style_h3 = ParagraphStyle(
        "H3", parent=styles["Heading3"],
        fontName=FONT_GOTHIC, fontSize=11, leading=14, spaceBefore=6, spaceAfter=2,
    )
    style_body = ParagraphStyle(
        "Body", parent=styles["Normal"],
        fontName=FONT_MINCHO, fontSize=9, leading=14, spaceAfter=3,
    )
    style_li = ParagraphStyle(
        "Li", parent=styles["Normal"],
        fontName=FONT_MINCHO, fontSize=9, leading=14, spaceAfter=2, leftIndent=10,
    )

    story = []

    story.append(Spacer(1, 40 * mm))
    story.append(Paragraph(escape_xml("久留米シティプロモーション"), style_cover_title))
    story.append(Paragraph(escape_xml("くるめのみりょく＋くるめのくらし 全ページまとめ"), style_cover_sub))
    seeds_str = " / ".join(SEED_URLS)
    story.append(Paragraph(escape_xml(f"取得元: {seeds_str}"), style_cover_sub))
    story.append(Paragraph(escape_xml(f"全{len(pages_data)}ページ収録（深さ{MAX_DEPTH}までクロール）"), style_cover_sub))
    story.append(Spacer(1, 20 * mm))

    story.append(Paragraph(escape_xml("目次"), style_toc_title))
    for i, (url, title, _) in enumerate(pages_data, 1):
        display_title = title if len(title) <= 70 else title[:70] + "..."
        story.append(Paragraph(escape_xml(f"{i}. {display_title}"), style_toc_item))

    for i, (url, title, paragraphs) in enumerate(pages_data, 1):
        story.append(PageBreak())
        story.append(Paragraph(escape_xml(f"{i}. {title}"), style_page_title))
        story.append(Paragraph(escape_xml(url), style_page_url))

        tag_style_map = {
            "h1": style_h1,
            "h2": style_h2,
            "h3": style_h3,
            "h4": style_h3,
        }

        if not paragraphs:
            story.append(Paragraph(escape_xml("（このページはJavaScriptで動的に読み込まれるコンテンツのため、テキスト抽出ができませんでした）"), style_body))

        for tag, text in paragraphs:
            escaped = escape_xml(text)
            if tag in tag_style_map:
                story.append(Paragraph(escaped, tag_style_map[tag]))
            elif tag == "li":
                story.append(Paragraph(f"・{escaped}", style_li))
            else:
                story.append(Paragraph(escaped, style_body))

    doc.build(story)
    print(f"\nPDF saved: {OUTPUT_PDF}")
    print(f"Total pages included: {len(pages_data)}")


def main():
    print("Phase 1: Crawling for all internal links...")
    all_urls = crawl_all_pages(SEED_URLS, max_depth=MAX_DEPTH)
    print(f"\nTotal unique URLs found: {len(all_urls)}\n")

    print("Phase 2: Extracting content from each page...")
    pages_data = []
    for i, url in enumerate(all_urls, 1):
        print(f"[{i}/{len(all_urls)}] Extracting: {url}")
        title, paragraphs = extract_page_content(url)
        pages_data.append((url, title, paragraphs))
        if i < len(all_urls):
            time.sleep(0.3)

    non_empty = sum(1 for _, _, p in pages_data if p)
    print(f"\nPages with content: {non_empty}/{len(pages_data)}")
    print("\nPhase 3: Building PDF...")
    build_pdf(pages_data)


if __name__ == "__main__":
    main()

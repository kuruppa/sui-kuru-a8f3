import os
import sys
import shutil
import zipfile
import tempfile
from pathlib import Path
from io import BytesIO
from PIL import Image
import pikepdf

SOURCE_DIR = Path(r"C:\Users\newor\Desktop\起業\研修講師関連\研修用ソース\情報発信とコンプライアンス")
OUTPUT_DIR = SOURCE_DIR / "compressed"

MAX_IMAGE_DIM = 800
JPEG_QUALITY = 25
PNG_COLORS = 32


def compress_image_bytes(data: bytes, filename: str) -> bytes:
    try:
        img = Image.open(BytesIO(data))
    except Exception:
        return data

    orig_format = img.format or "PNG"
    ext = Path(filename).suffix.lower()

    if img.mode == "RGBA" and ext in (".jpg", ".jpeg"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[3])
        img = bg
    elif img.mode not in ("RGB", "L"):
        if ext in (".jpg", ".jpeg"):
            img = img.convert("RGB")

    w, h = img.size
    if max(w, h) > MAX_IMAGE_DIM:
        ratio = MAX_IMAGE_DIM / max(w, h)
        img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)

    buf = BytesIO()
    if ext in (".jpg", ".jpeg"):
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        img.save(buf, format="JPEG", quality=JPEG_QUALITY, optimize=True)
    elif ext == ".png":
        if img.mode == "RGBA":
            img = img.quantize(colors=PNG_COLORS, method=Image.FASTOCTREE)
        elif img.mode == "RGB":
            img = img.quantize(colors=PNG_COLORS, method=Image.MEDIANCUT)
        img.save(buf, format="PNG", optimize=True)
    elif ext == ".emf" or ext == ".wmf":
        return data
    elif ext == ".tiff" or ext == ".tif":
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        img.save(buf, format="JPEG", quality=JPEG_QUALITY, optimize=True)
    else:
        img.save(buf, format=orig_format, optimize=True)

    result = buf.getvalue()
    if len(result) < len(data):
        return result
    return data


def compress_pptx(src: Path, dst: Path):
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        with zipfile.ZipFile(src, 'r') as zin:
            zin.extractall(tmpdir)

        media_dir = tmpdir / "ppt" / "media"
        if media_dir.exists():
            for img_file in media_dir.iterdir():
                if img_file.suffix.lower() in (".png", ".jpg", ".jpeg", ".tiff", ".tif", ".bmp", ".gif"):
                    data = img_file.read_bytes()
                    compressed = compress_image_bytes(data, img_file.name)
                    img_file.write_bytes(compressed)
                    saved = len(data) - len(compressed)
                    if saved > 0:
                        print(f"  Image {img_file.name}: {len(data)//1024}KB -> {len(compressed)//1024}KB (saved {saved//1024}KB)")

        with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zout:
            for root, dirs, files in os.walk(tmpdir):
                for file in files:
                    file_path = Path(root) / file
                    arcname = file_path.relative_to(tmpdir)
                    zout.write(file_path, arcname)

    orig_size = src.stat().st_size
    new_size = dst.stat().st_size
    print(f"  PPTX: {orig_size/1024/1024:.2f}MB -> {new_size/1024/1024:.2f}MB ({new_size/orig_size*100:.1f}%)")


def extract_pdf_image(xobj, w, h):
    raw_data = xobj.read_raw_bytes()
    filters = xobj.get("/Filter")

    if isinstance(filters, pikepdf.Array):
        filter_list = [str(f) for f in filters]
    else:
        filter_list = [str(filters)] if filters else []

    if "/DCTDecode" in filter_list:
        try:
            return Image.open(BytesIO(raw_data))
        except Exception:
            return None

    if "/FlateDecode" in filter_list:
        import zlib
        try:
            decompressed = zlib.decompress(raw_data)
        except Exception:
            try:
                decompressed = xobj.read_bytes()
            except Exception:
                return None
    elif not filter_list or filter_list == ['None']:
        try:
            decompressed = xobj.read_bytes()
        except Exception:
            return None
    else:
        try:
            decompressed = xobj.read_bytes()
        except Exception:
            return None

    cs = str(xobj.get("/ColorSpace", ""))
    bpc = int(xobj.get("/BitsPerComponent", 8))

    if "/DeviceRGB" in cs or "RGB" in cs:
        mode = "RGB"
        channels = 3
    elif "/DeviceCMYK" in cs or "CMYK" in cs:
        mode = "CMYK"
        channels = 4
    elif "/DeviceGray" in cs or "Gray" in cs:
        mode = "L"
        channels = 1
    else:
        mode = "RGB"
        channels = 3

    expected = w * h * channels * (bpc // 8)
    if len(decompressed) < expected:
        if channels == 3:
            mode = "L"
            channels = 1
            expected = w * h * channels
            if len(decompressed) < expected:
                return None
        else:
            return None

    try:
        img = Image.frombytes(mode, (w, h), decompressed[:expected])
        if mode == "CMYK":
            img = img.convert("RGB")
        return img
    except Exception:
        return None


def compress_pdf(src: Path, dst: Path):
    try:
        with pikepdf.open(src) as pdf:
            for page in pdf.pages:
                if "/Resources" not in page:
                    continue
                resources = page["/Resources"]
                if "/XObject" not in resources:
                    continue
                xobjects = resources["/XObject"]
                for key in list(xobjects.keys()):
                    xobj = xobjects[key]
                    if not isinstance(xobj, pikepdf.Stream):
                        continue
                    if xobj.get("/Subtype") != "/Image":
                        continue
                    try:
                        w = int(xobj.get("/Width", 0))
                        h = int(xobj.get("/Height", 0))
                        if w == 0 or h == 0:
                            continue

                        raw_data = xobj.read_raw_bytes()
                        pil_img = extract_pdf_image(xobj, w, h)

                        if pil_img is None:
                            continue

                        if max(w, h) > MAX_IMAGE_DIM:
                            ratio = MAX_IMAGE_DIM / max(w, h)
                            new_w, new_h = int(w * ratio), int(h * ratio)
                            pil_img = pil_img.resize((new_w, new_h), Image.LANCZOS)

                        if pil_img.mode not in ("RGB", "L"):
                            pil_img = pil_img.convert("RGB")

                        buf = BytesIO()
                        pil_img.save(buf, format="JPEG", quality=JPEG_QUALITY, optimize=True)
                        new_data = buf.getvalue()

                        if len(new_data) < len(raw_data):
                            xobj.write(new_data, filter=pikepdf.Name("/DCTDecode"))
                            xobj["/Width"] = pil_img.width
                            xobj["/Height"] = pil_img.height
                            xobj["/ColorSpace"] = pikepdf.Name("/DeviceRGB") if pil_img.mode == "RGB" else pikepdf.Name("/DeviceGray")
                            xobj["/BitsPerComponent"] = 8
                            if "/DecodeParms" in xobj:
                                del xobj["/DecodeParms"]
                            if "/SMask" in xobj:
                                del xobj["/SMask"]
                    except Exception as e:
                        continue

            pdf.remove_unreferenced_resources()
            pdf.save(dst, linearize=True, compress_streams=True,
                     stream_decode_level=pikepdf.StreamDecodeLevel.generalized)

        orig_size = src.stat().st_size
        new_size = dst.stat().st_size
        print(f"  PDF: {orig_size/1024/1024:.2f}MB -> {new_size/1024/1024:.2f}MB ({new_size/orig_size*100:.1f}%)")
    except Exception as e:
        print(f"  PDF error for {src.name}: {e}, copying original")
        shutil.copy2(src, dst)


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)

    source_subdir = SOURCE_DIR / "ソース"
    if source_subdir.exists():
        (OUTPUT_DIR / "ソース").mkdir(exist_ok=True)

    total_orig = 0
    total_new = 0

    for f in SOURCE_DIR.iterdir():
        if f.is_dir():
            continue
        total_orig += f.stat().st_size
        dst = OUTPUT_DIR / f.name
        print(f"\nProcessing: {f.name}")

        if f.suffix.lower() == ".pptx":
            compress_pptx(f, dst)
        elif f.suffix.lower() == ".pdf":
            compress_pdf(f, dst)
        else:
            shutil.copy2(f, dst)

        total_new += dst.stat().st_size

    if source_subdir.exists():
        for f in source_subdir.iterdir():
            if f.is_dir():
                continue
            total_orig += f.stat().st_size
            dst = OUTPUT_DIR / "ソース" / f.name
            print(f"\nProcessing: ソース/{f.name}")

            if f.suffix.lower() == ".pdf":
                compress_pdf(f, dst)
            else:
                shutil.copy2(f, dst)

            total_new += dst.stat().st_size

    print(f"\n{'='*60}")
    print(f"Total original: {total_orig/1024/1024:.2f} MB")
    print(f"Total compressed: {total_new/1024/1024:.2f} MB")
    print(f"Compression ratio: {total_new/total_orig*100:.1f}%")
    print(f"Output: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()

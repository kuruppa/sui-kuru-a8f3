import os, zipfile, tempfile
from pathlib import Path
from io import BytesIO
from PIL import Image

SRC = Path(r"C:\Users\newor\Desktop\表紙.pptx")
DST = SRC.parent / "表紙_compressed.pptx"
MAX_DIM, QUALITY = 1200, 72


def update_refs(tmp: Path, old: str, new: str):
    for pat in ("ppt/slides/_rels/*.rels", "ppt/_rels/*.rels"):
        for f in tmp.glob(pat):
            c = f.read_text(encoding="utf-8")
            if old in c:
                f.write_text(c.replace(old, new), encoding="utf-8")
    ct = tmp / "[Content_Types].xml"
    if ct.exists():
        c = ct.read_text(encoding="utf-8")
        if 'Extension="jpg"' not in c:
            c = c.replace("</Types>", '<Default Extension="jpg" ContentType="image/jpeg"/></Types>')
            ct.write_text(c, encoding="utf-8")


with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    with zipfile.ZipFile(SRC) as z:
        z.extractall(td)
    media = td / "ppt" / "media"
    for f in list(media.iterdir()):
        if f.suffix.lower() not in (".png", ".jpg", ".jpeg"):
            continue
        img = Image.open(BytesIO(f.read_bytes()))
        if img.mode == "RGBA":
            bg = Image.new("RGB", img.size, (255, 255, 255))
            bg.paste(img, mask=img.split()[3])
            img = bg
        elif img.mode != "RGB":
            img = img.convert("RGB")
        w, h = img.size
        if max(w, h) > MAX_DIM:
            r = MAX_DIM / max(w, h)
            img = img.resize((int(w * r), int(h * r)), Image.LANCZOS)
        buf = BytesIO()
        img.save(buf, "JPEG", quality=QUALITY, optimize=True)
        new = f.stem + ".jpg"
        if f.suffix.lower() != ".jpg":
            update_refs(td, f.name, new)
            f.unlink()
        (media / new).write_bytes(buf.getvalue())
        print(f"  {f.name} -> {len(buf.getvalue()) // 1024}KB")
    with zipfile.ZipFile(DST, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for root, _, files in os.walk(td):
            for fn in files:
                fp = Path(root) / fn
                z.write(fp, fp.relative_to(td))

o, n = SRC.stat().st_size, DST.stat().st_size
print(f"Result: {o/1024/1024:.2f}MB -> {n/1024/1024:.2f}MB ({n/o*100:.0f}%)")
print(DST)

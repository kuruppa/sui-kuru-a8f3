"""Merge all HEIC images in this folder into one vertical JPEG."""
from pathlib import Path

from PIL import Image
import pillow_heif

pillow_heif.register_heif_opener()


def main() -> None:
    folder = Path(__file__).resolve().parent
    paths = sorted(
        {p for p in folder.iterdir() if p.suffix.lower() == ".heic"},
        key=lambda p: p.name.lower(),
    )
    if not paths:
        raise SystemExit("No .heic files found in folder.")

    max_width = 1920
    images: list[Image.Image] = []
    for p in paths:
        im = Image.open(p)
        im = im.convert("RGB")
        w, h = im.size
        if w > max_width:
            new_h = max(1, int(h * max_width / w))
            im = im.resize((max_width, new_h), Image.Resampling.LANCZOS)
        images.append(im)

    total_w = max(im.size[0] for im in images)
    total_h = sum(im.size[1] for im in images)
    out = Image.new("RGB", (total_w, total_h), (255, 255, 255))
    y = 0
    for im in images:
        x = (total_w - im.size[0]) // 2
        out.paste(im, (x, y))
        y += im.size[1]

    out_path = folder / "merged.jpg"
    out.save(out_path, quality=92, optimize=True)
    print(f"Saved: {out_path} ({total_w}x{total_h})")


def archive_sources(folder: Path) -> int:
    """Move .heic files to _source_heic/ after merge (keeps originals, clears project root)."""
    archive = folder / "_source_heic"
    archive.mkdir(exist_ok=True)
    moved = 0
    for p in sorted(folder.iterdir()):
        if p.suffix.lower() != ".heic" or not p.is_file():
            continue
        dest = archive / p.name
        if dest.exists():
            continue
        p.rename(dest)
        moved += 1
    return moved


if __name__ == "__main__":
    import sys

    main()
    if "--archive" in sys.argv:
        n = archive_sources(Path(__file__).resolve().parent)
        print(f"Archived {n} HEIC file(s) to _source_heic/")

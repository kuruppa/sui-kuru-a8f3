"""Compress PDF to ~1/5 size and remove NotebookLM watermark from bottom-right of each page."""
import fitz
from PIL import Image
import io
import os

SRC = r'c:\Users\newor\Downloads\Gov-PM_Essentials.pdf'
DST = r'c:\Users\newor\Downloads\Gov-PM_Essentials_compressed.pdf'

# Watermark cover region (in pixel coords of the 1376x768 image)
WM_LEFT = 1270
WM_TOP = 732
WM_RIGHT = 1376
WM_BOTTOM = 768

JPEG_QUALITY = 88

src = fitz.open(SRC)
dst = fitz.open()

for i, page in enumerate(src):
    imgs = page.get_images(full=True)
    if len(imgs) != 1:
        print(f'Warning: page {i} has {len(imgs)} images, expected 1')

    xref = imgs[0][0]
    base = src.extract_image(xref)
    img_bytes = base['image']
    pil = Image.open(io.BytesIO(img_bytes)).convert('RGB')

    W, H = pil.size
    # Remove watermark by row-wise edge replication:
    # For each row in the watermark region, take the pixel just to the left
    # of the watermark and fill the watermark region with that color.
    # This handles both uniform backgrounds and rows where the watermark
    # crosses different regions (e.g., a white tip box and gray backdrop).
    px = pil.load()
    sample_x = WM_LEFT - 2
    for y in range(WM_TOP, WM_BOTTOM):
        c = px[sample_x, y]
        for x in range(WM_LEFT, WM_RIGHT):
            px[x, y] = c

    # Encode as JPEG
    buf = io.BytesIO()
    pil.save(buf, format='JPEG', quality=JPEG_QUALITY, optimize=True, progressive=True)
    jpeg_bytes = buf.getvalue()

    new_page = dst.new_page(width=page.rect.width, height=page.rect.height)
    new_page.insert_image(new_page.rect, stream=jpeg_bytes)
    print(f'page {i}: orig png {len(img_bytes)} -> jpeg {len(jpeg_bytes)} bytes')

dst.save(DST, garbage=4, deflate=True, clean=True)
dst.close()
src.close()

orig_size = os.path.getsize(SRC)
new_size = os.path.getsize(DST)
print(f'\nOriginal: {orig_size} bytes ({orig_size/1024/1024:.2f} MB)')
print(f'Compressed: {new_size} bytes ({new_size/1024/1024:.2f} MB)')
print(f'Ratio: {new_size/orig_size*100:.1f}% (target ~20%)')
print(f'Output: {DST}')

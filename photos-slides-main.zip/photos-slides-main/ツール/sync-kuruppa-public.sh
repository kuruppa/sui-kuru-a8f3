#!/usr/bin/env bash
# くるっぱ/kuruppa-river → 作業データ/sui-kuru-a8f3 へ同期（公開用）
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/くるっぱ/kuruppa-river"
DST="$ROOT/作業データ/sui-kuru-a8f3"

rsync -a --delete \
  --exclude='test/' \
  --exclude='.git/' \
  "$SRC/" "$DST/"

# 公開用 README は上書きしない
if [[ ! -f "$DST/README.md" ]]; then
  cp "$SRC/README.md" "$DST/README.md"
fi

# workflow は公開リポジトリ用を維持
mkdir -p "$DST/.github/workflows"

echo "同期完了: $DST"
echo "ZIP 更新: cd 作業データ && zip -r sui-kuru-a8f3.zip sui-kuru-a8f3"

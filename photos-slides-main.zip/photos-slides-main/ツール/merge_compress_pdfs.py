"""ZIP内のPDFをタイトル順にマージし、埋め込み画像を正しく再圧縮して約1/5に縮小する。

`page.replace_image()` を使って画像オブジェクトの辞書情報(幅/高さ/Filter等)も
同時に更新させるため、PDFが壊れない。
"""
from __future__ import annotations

import io
import re
import sys
import zipfile
from pathlib import Path

import fitz
from PIL import Image

ZIP_PATH = Path(r"C:\Users\newor\Downloads\drive-download-20260419T114623Z-3-001.zip")
WORK_DIR = Path(r"c:\Users\newor\こいこい用\photos-slides\_merge_work")
OUT_MERGED = Path(r"c:\Users\newor\こいこい用\photos-slides\プロジェクトマネジメント入門_全編_v2.pdf")

MAX_IMG_LONG_SIDE = 1400
JPEG_QUALITY = 62


def natural_key(s: str):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def extract_zip() -> list[Path]:
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    extracted: list[Path] = []
    with zipfile.ZipFile(ZIP_PATH) as z:
        for info in z.infolist():
            name = info.filename
            try:
                fixed = name.encode("cp437").decode("cp932")
            except (UnicodeDecodeError, UnicodeEncodeError):
                fixed = name
            target = WORK_DIR / fixed
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as src, open(target, "wb") as dst:
                dst.write(src.read())
            extracted.append(target)
    return extracted


def merge_pdfs(paths: list[Path]) -> Path:
    merged = fitz.open()
    for p in paths:
        print(f"  結合中: {p.name}")
        with fitz.open(p) as doc:
            merged.insert_pdf(doc)
    tmp = WORK_DIR / "_merged_raw.pdf"
    merged.save(str(tmp))
    merged.close()
    return tmp


def recompress_images(src: Path, dst: Path, max_long: int, quality: int) -> None:
    doc = fitz.open(src)
    xref_to_page: dict[int, int] = {}
    for page_index in range(len(doc)):
        for img in doc[page_index].get_images(full=True):
            xref = img[0]
            xref_to_page.setdefault(xref, page_index)

    total = len(xref_to_page)
    shrunk = 0
    saved_bytes = 0

    for n, (xref, page_index) in enumerate(xref_to_page.items(), 1):
        try:
            info = doc.extract_image(xref)
        except Exception:
            continue
        raw = info.get("image")
        if not raw:
            continue
        try:
            pil = Image.open(io.BytesIO(raw))
            pil.load()
        except Exception:
            continue

        if pil.mode not in ("RGB", "L"):
            pil = pil.convert("RGB")

        w, h = pil.size
        longest = max(w, h)
        if longest > max_long:
            r = max_long / longest
            pil = pil.resize((max(1, int(w * r)), max(1, int(h * r))), Image.LANCZOS)

        buf = io.BytesIO()
        pil.save(buf, format="JPEG", quality=quality, optimize=True, progressive=True)
        new_bytes = buf.getvalue()

        if len(new_bytes) < len(raw):
            try:
                doc[page_index].replace_image(xref, stream=new_bytes)
                shrunk += 1
                saved_bytes += len(raw) - len(new_bytes)
            except Exception as e:
                print(f"  警告: xref={xref} の置換失敗: {e}")

        if n % 20 == 0 or n == total:
            print(f"  画像処理 {n}/{total}")

    print(f"  再圧縮: {shrunk}/{total} 枚 / 削減 {saved_bytes / 1024 / 1024:.1f} MB")

    doc.save(
        str(dst),
        garbage=4,
        deflate=True,
        deflate_images=True,
        deflate_fonts=True,
        clean=True,
    )
    doc.close()


def fmt_size(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.2f} {unit}"
        n /= 1024
    return f"{n:.2f} TB"


def main() -> int:
    print("ZIPを展開中...")
    pdfs = [p for p in extract_zip() if p.suffix.lower() == ".pdf"]
    pdfs.sort(key=lambda p: natural_key(p.name))

    print("タイトル順:")
    for p in pdfs:
        print(f"  - {p.name}")

    total_src = sum(p.stat().st_size for p in pdfs)
    print(f"元サイズ合計: {fmt_size(total_src)}")

    print("\nマージ中...")
    merged_raw = merge_pdfs(pdfs)
    print(f"マージ後(未圧縮): {fmt_size(merged_raw.stat().st_size)}")

    print("\n画像を再圧縮中...")
    OUT_MERGED.parent.mkdir(parents=True, exist_ok=True)
    recompress_images(merged_raw, OUT_MERGED, max_long=MAX_IMG_LONG_SIDE, quality=JPEG_QUALITY)

    out_size = OUT_MERGED.stat().st_size
    print(f"\n完了: {OUT_MERGED}")
    print(f"出力サイズ: {fmt_size(out_size)}  (元比 {out_size / total_src:.1%})")

    print("\n検証中...")
    with fitz.open(OUT_MERGED) as d:
        print(f"  ページ数: {len(d)}")
        for i in range(len(d)):
            _ = d[i].get_pixmap(dpi=40)
        print("  全ページレンダリング成功")
    return 0


if __name__ == "__main__":
    sys.exit(main())

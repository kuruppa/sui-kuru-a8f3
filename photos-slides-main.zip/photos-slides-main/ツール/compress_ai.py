import shutil
from pathlib import Path
from io import BytesIO

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
import fitz  # PyMuPDF

SRC = Path(r"C:\Users\newor\Downloads\【提案書】情報発信におけるコンプライアンス_(6).pdf")
DST = SRC.parent / "【提案書】情報発信におけるコンプライアンス_compressed.pdf"

HIGH_DPI = 300
TARGET_DPI = 180
JPEG_QUALITY = 72


def remove_notebooklm(img: Image.Image) -> Image.Image:
    """Remove NotebookLM logo by detecting text pixels inside a tight region.
    Background color is sampled from BELOW the text (guaranteed clean bg),
    not from the top of the region (which may overlap with a banner).
    """
    w, h = img.size
    scale_x = w / 1376.0
    scale_y = h / 768.0

    # NotebookLM (icon + text) tight region at 1x base (1376x768):
    #   text x=[1270, 1364], y=[748, 757]
    #   icon slightly left of text, similar height
    # Add small safety padding
    x1 = max(0, int(1253 * scale_x))
    y1 = max(0, int(745 * scale_y))
    x2 = min(w, int(1372 * scale_x))
    y2 = min(h, int(762 * scale_y))

    # Background sampling strip: BELOW the NotebookLM text (y > 757 at 1x),
    # which is always clean background for these slides
    sample_y1 = max(0, int(759 * scale_y))
    sample_y2 = min(h, int(767 * scale_y))
    if sample_y2 <= sample_y1:
        return img

    bg_strip = np.array(img.crop((x1, sample_y1, x2, sample_y2)).convert("RGB"))
    if bg_strip.size == 0:
        return img
    bg_color = np.median(bg_strip.reshape(-1, 3), axis=0)
    bg_brightness = np.mean(bg_color)

    region = np.array(img.crop((x1, y1, x2, y2)).convert("RGB")).astype(float)
    rh, rw = region.shape[:2]
    if rh < 3 or rw < 3:
        return img

    diff = np.sqrt(np.sum((region - bg_color) ** 2, axis=2))
    threshold = 45 if bg_brightness > 128 else 55
    text_mask = diff > threshold

    if np.sum(text_mask) < 5:
        return img

    # Dilate mask to cover anti-aliasing edges
    dilated = text_mask.copy()
    for dy in range(-2, 3):
        for dx in range(-2, 3):
            if abs(dy) + abs(dx) <= 2:
                shifted = np.roll(np.roll(text_mask, dy, axis=0), dx, axis=1)
                dilated = dilated | shifted

    result_arr = np.array(img.convert("RGB")).copy()
    bg_int = bg_color.astype(np.uint8)
    sub = result_arr[y1:y2, x1:x2]
    for c in range(3):
        sub[:, :, c] = np.where(dilated, bg_int[c], sub[:, :, c])
    result_arr[y1:y2, x1:x2] = sub

    return Image.fromarray(result_arr)


def main():
    doc = fitz.open(str(SRC))
    out_doc = fitz.open()
    mat = fitz.Matrix(HIGH_DPI / 72, HIGH_DPI / 72)

    for i in range(len(doc)):
        page = doc[i]
        pix = page.get_pixmap(matrix=mat)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

        # Downsample from HIGH_DPI to TARGET_DPI to avoid low-DPI rendering artifacts
        # (PDF drop shadows / transparency effects misalign at low DPI)
        tw = int(img.width * TARGET_DPI / HIGH_DPI)
        th = int(img.height * TARGET_DPI / HIGH_DPI)
        img = img.resize((tw, th), Image.LANCZOS)

        img = remove_notebooklm(img)

        buf = BytesIO()
        img.save(buf, format="JPEG", quality=JPEG_QUALITY, optimize=True)
        img_data = buf.getvalue()

        new_page = out_doc.new_page(width=page.rect.width, height=page.rect.height)
        new_page.insert_image(fitz.Rect(0, 0, page.rect.width, page.rect.height), stream=img_data)
        print(f"  Page {i+1}: {len(img_data)//1024}KB")

    out_doc.save(str(DST), deflate=True, garbage=4)
    out_doc.close()
    doc.close()

    orig = SRC.stat().st_size
    comp = DST.stat().st_size
    print(f"\nResult: {orig/1048576:.2f}MB -> {comp/1048576:.2f}MB ({comp/orig*100:.1f}%, 1/{orig/comp:.1f})")
    print(f"Output: {DST}")


if __name__ == "__main__":
    main()

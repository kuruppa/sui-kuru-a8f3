"""
Turn 'single full-slide image' decks into layered PowerPoint slides.

Each slide must be essentially one picture (raster). Text pixels are masked using
the slide corner colour, then OCR text is placed in real PowerPoint text boxes on top.

Requires: pip install python-pptx pillow easyocr numpy
First EasyOCR run downloads models (needs network once).
"""
from __future__ import annotations

import argparse
import io
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.util import Pt


def _corner_bg_rgb(im: Image.Image) -> tuple[int, int, int]:
    w, h = im.size
    samples = [
        im.getpixel((0, 0)),
        im.getpixel((w - 1, 0)),
        im.getpixel((0, h - 1)),
        im.getpixel((w - 1, h - 1)),
    ]
    r = round(sum(p[0] for p in samples) / 4)
    g = round(sum(p[1] for p in samples) / 4)
    b = round(sum(p[2] for p in samples) / 4)
    return r, g, b


def _axis_bbox_from_quad(box: list[list[float]], pad: float) -> tuple[float, float, float, float]:
    xs = [p[0] for p in box]
    ys = [p[1] for p in box]
    return min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad


def _pixel_rect_to_slide_emu(
    pic_left: int,
    pic_top: int,
    pic_w_emu: int,
    pic_h_emu: int,
    img_w: int,
    img_h: int,
    left_px: float,
    top_px: float,
    right_px: float,
    bottom_px: float,
) -> tuple[int, int, int, int]:
    def px_to_emu(px: float, py: float) -> tuple[int, int]:
        x_emu = int(pic_left + (px / img_w) * pic_w_emu)
        y_emu = int(pic_top + (py / img_h) * pic_h_emu)
        return x_emu, y_emu

    x0, y0 = px_to_emu(left_px, top_px)
    x1, y1 = px_to_emu(right_px, bottom_px)
    return x0, y0, max(1, x1 - x0), max(1, y1 - y0)


def _first_picture_shape(slide):
    for shape in slide.shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            return shape
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            for sub in shape.shapes:
                if sub.shape_type == MSO_SHAPE_TYPE.PICTURE:
                    return sub
    return None


def build_layered_pptx(
    src_pptx: Path,
    dst_pptx: Path,
    *,
    min_confidence: float,
    pad_px: float,
    min_box_h_px: float,
    japanese_font: str,
) -> None:
    try:
        import easyocr  # heavy import; optional until command runs
    except ImportError as e:  # pragma: no cover
        raise SystemExit(
            "easyocr が見つかりません。次を実行してください: py -3 -m pip install easyocr"
        ) from e

    src = Presentation(str(src_pptx))
    out = Presentation()
    out.slide_width = src.slide_width
    out.slide_height = src.slide_height
    blank_layout = out.slide_layouts[6]  # Blank

    reader = easyocr.Reader(["ja", "en"], gpu=False, verbose=False)

    n_slides = len(src.slides)
    for si, src_slide in enumerate(src.slides, start=1):
        pic = _first_picture_shape(src_slide)
        if pic is None:
            print(f"[{si}/{n_slides}] 画像なし → 空スライドをスキップします", file=sys.stderr)
            out.slides.add_slide(blank_layout)
            continue

        im = Image.open(io.BytesIO(pic.image.blob)).convert("RGB")
        img_w, img_h = im.size
        bg = _corner_bg_rgb(im)
        arr = np.array(im)

        regions = reader.readtext(arr, detail=1, paragraph=False)
        regions = [r for r in regions if float(r[2]) >= min_confidence]

        masked = im.copy()
        draw = ImageDraw.Draw(masked)
        for box, _text, _conf in regions:
            l, t, r, b = _axis_bbox_from_quad(box, pad_px)
            if b - t < min_box_h_px:
                continue
            l = max(0, l)
            t = max(0, t)
            r = min(img_w - 1, r)
            b = min(img_h - 1, b)
            draw.rectangle([l, t, r, b], fill=bg)

        pic_left = int(pic.left)
        pic_top = int(pic.top)
        pic_w = int(pic.width)
        pic_h = int(pic.height)

        buf = io.BytesIO()
        masked.save(buf, format="PNG")
        buf.seek(0)

        slide = out.slides.add_slide(blank_layout)
        slide.shapes.add_picture(buf, pic_left, pic_top, width=pic_w, height=pic_h)

        pic_h_pt = pic_h / 914400 * 72

        for box, text, conf in regions:
            l, t, r, b = _axis_bbox_from_quad(box, pad_px)
            if b - t < min_box_h_px:
                continue
            h_px = b - t
            font_pt = max(
                8.0,
                min(96.0, (h_px / img_h) * pic_h_pt * 0.82),
            )
            left_px, top_px, right_px, bottom_px = l, t, r, b
            x_emu, y_emu, w_emu, h_emu = _pixel_rect_to_slide_emu(
                pic_left,
                pic_top,
                pic_w,
                pic_h,
                img_w,
                img_h,
                left_px,
                top_px,
                right_px,
                bottom_px,
            )
            tb = slide.shapes.add_textbox(x_emu, y_emu, w_emu, h_emu)
            tf = tb.text_frame
            tf.text = text.strip() or " "
            p = tf.paragraphs[0]
            run = p.runs[0] if p.runs else p.add_run()
            run.font.name = japanese_font
            run.font.size = Pt(round(font_pt, 1))

        print(f"[{si}/{n_slides}] 完了 (認識ブロック {len(regions)} 件)", file=sys.stderr)

    out.save(str(dst_pptx))


def main() -> None:
    ap = argparse.ArgumentParser(
        description="ラスター1枚スライドを、マスク画像＋編集可能テキストに分解したpptxを出力します。"
    )
    ap.add_argument("pptx_path", type=Path)
    ap.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="出力pptx (省略時は *_layered.pptx)",
    )
    ap.add_argument("--min-confidence", type=float, default=0.35)
    ap.add_argument("--pad-px", type=float, default=6.0, help="マスクをテキスト周りに広げる量(ピクセル)")
    ap.add_argument("--min-box-h-px", type=float, default=10.0)
    ap.add_argument(
        "--font",
        default="Yu Gothic",
        help="テキストボックスのフォント名 (環境に合わせて変更)",
    )
    args = ap.parse_args()

    src = args.pptx_path.resolve()
    dst = (
        args.output.resolve()
        if args.output
        else src.with_name(f"{src.stem}_layered{src.suffix}")
    )

    build_layered_pptx(
        src,
        dst,
        min_confidence=args.min_confidence,
        pad_px=args.pad_px,
        min_box_h_px=args.min_box_h_px,
        japanese_font=args.font,
    )
    print(dst)


if __name__ == "__main__":
    main()

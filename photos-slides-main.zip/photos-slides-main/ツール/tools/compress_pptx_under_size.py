"""
Shrink in-package images (resize + JPEG) so a .pptx fits under a byte budget.

Rewrites ppt/media/* raster files and updates XML references when extension changes.
"""
from __future__ import annotations

import argparse
import io
import re
import zipfile
from pathlib import Path

from PIL import Image


def _rgb_image(im: Image.Image) -> Image.Image:
    if im.mode in ("RGBA", "P"):
        bg = Image.new("RGB", im.size, (255, 255, 255))
        if im.mode == "P":
            im = im.convert("RGBA")
        bg.paste(im, mask=im.split()[-1] if im.mode == "RGBA" else None)
        return bg
    if im.mode != "RGB":
        return im.convert("RGB")
    return im


def _resize_max_long_edge(im: Image.Image, max_long: int) -> Image.Image:
    w, h = im.size
    long_edge = max(w, h)
    if long_edge <= max_long:
        return im
    scale = max_long / long_edge
    nw = max(1, int(round(w * scale)))
    nh = max(1, int(round(h * scale)))
    return im.resize((nw, nh), Image.Resampling.LANCZOS)


def compress_pptx_images(
    src: Path,
    dst: Path,
    *,
    max_long_edge: int,
    jpeg_quality: int,
) -> int:
    src = src.resolve()
    dst = dst.resolve()

    media_pattern = re.compile(r"^ppt/media/image(\d+)\.(png|jpe?g|gif|bmp|tiff?)$", re.I)

    with zipfile.ZipFile(src, "r") as zin:
        names = zin.namelist()
        out_files: dict[str, bytes] = {}
        media_map: list[tuple[str, str]] = []  # (old_name, new_name)

        for raw in names:
            name = raw.replace("\\", "/")
            m = media_pattern.match(name)
            if not m:
                out_files[name] = zin.read(raw)
                continue

            idx = m.group(1)
            data = zin.read(raw)
            try:
                im = Image.open(io.BytesIO(data))
            except Exception:
                out_files[name] = data
                continue

            im = _rgb_image(im)
            im = _resize_max_long_edge(im, max_long_edge)
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=jpeg_quality, optimize=True, subsampling=2)
            jpg_name = f"ppt/media/image{idx}.jpeg"
            media_map.append((name, jpg_name))
            out_files[jpg_name] = buf.getvalue()

        # Replace references in all XML parts (UTF-8); higher image indices first
        def _img_num(pair: tuple[str, str]) -> int:
            mo = re.search(r"image(\d+)", pair[0])
            return int(mo.group(1)) if mo else 0

        xml_paths = [p for p in out_files if p.endswith(".xml") or p.endswith(".rels")]
        for old_name, new_name in sorted(media_map, key=_img_num, reverse=True):
            if old_name == new_name:
                continue
            base_old = Path(old_name).name
            base_new = Path(new_name).name
            for xp in xml_paths:
                text = out_files[xp].decode("utf-8")
                if base_old not in text:
                    continue
                text = text.replace(base_old, base_new)
                out_files[xp] = text.encode("utf-8")

        dst.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(dst, "w", compression=zipfile.ZIP_DEFLATED) as zout:
            for name, payload in sorted(out_files.items()):
                zout.writestr(name, payload)

    return dst.stat().st_size


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx", type=Path, nargs="+")
    ap.add_argument("--max-mb", type=float, default=1.0)
    ap.add_argument("-o", "--output-dir", type=Path, default=None)
    args = ap.parse_args()

    budget = int(args.max_mb * 1024 * 1024)

    for pptx in args.pptx:
        src = pptx.resolve()
        out_dir = args.output_dir.resolve() if args.output_dir else src.parent
        dst = out_dir / f"{src.stem}_under{int(args.max_mb)}mb{src.suffix}"

        done = False
        for max_edge in (1024, 900, 800, 720, 640, 560, 480, 420):
            for quality in (72, 62, 52, 42, 34, 28):
                size = compress_pptx_images(
                    src,
                    dst,
                    max_long_edge=max_edge,
                    jpeg_quality=quality,
                )
                if size <= budget:
                    print(f"{dst}\t{size}\tbytes\tedge={max_edge}\tq={quality}")
                    done = True
                    break
            if done:
                break

        if not done:
            size = dst.stat().st_size if dst.exists() else 0
            raise SystemExit(
                f"Could not reach <= {args.max_mb} MB for {src} (last size {size} bytes). "
                "Try lowering content or increase budget."
            )


if __name__ == "__main__":
    main()

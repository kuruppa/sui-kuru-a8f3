"""Build a fully decomposed version of the 3 Kurume slides.

- Base layer: original slide image with text + extracted icons removed (inpaint).
  Photos, panels, frames, green boxes, badges stay pixel-perfect.
- Text: editable text boxes (curated correct text, brand colours).
- Icons: each icon becomes its own transparent PNG picture shape (movable).

Also writes composited PNG previews so layout can be verified without PowerPoint.
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

SRC = Path(r"c:\Users\newor\Downloads\New_Kurume_Relocation_Subsidy_(7).pptx")
OUT_DIR = Path(r"c:\Users\newor\こいこい用\photos-slides\output")
VIEW = Path(r"c:\Users\newor\Downloads\_kurume_view")
ICON_DIR = OUT_DIR / "kurume_icons"

EMU_PER_PT = 12700

# Brand colours (RGB)
GREEN = (16, 80, 44)
ORANGE = (232, 112, 2)
GRAY = (70, 70, 70)
BLACK = (17, 17, 17)
WHITE = (255, 255, 255)

# Font files (Windows)
FONT_BOLD = r"C:\Windows\Fonts\YuGothB.ttc"
FONT_REG = r"C:\Windows\Fonts\YuGothR.ttc"
PPTX_FONT = "Yu Gothic"

# BGR fills for solid background restoration (avoids inpaint smudges)
FILL_WHITE = (255, 255, 255)
FILL_GREEN_BOX = (44, 80, 16)
FILL_GREEN_BG = (44, 80, 16)

# --- Curated content ---------------------------------------------------------
# rect = (x0, y0, x1, y1) in image pixels (image is 1376x768)
# text blocks: dict(rect, text, color, bold, lines, align)
# icons: dict(rect, name)

SLIDES = {
    1: {
        "texts": [
            dict(rect=(74, 76, 470, 138), text="令和8年10月スタート", color=WHITE, bold=True, lines=1, align="l"),
            dict(rect=(68, 172, 665, 472), text="くるめ移住\n応援補助金", color=WHITE, bold=True, lines=2, align="l"),
            dict(rect=(66, 505, 735, 670), text="久留米での新しい暮らしを\n全力で応援します！", color=WHITE, bold=True, lines=2, align="l"),
        ],
        "icons": [],
    },
    2: {
        "texts": [
            dict(rect=(700, 318, 1250, 415), text="最大補助額", color=GREEN, bold=True, lines=1, align="c"),
            dict(rect=(690, 440, 1252, 496), text="30万円から大幅引き上げ", color=ORANGE, bold=True, lines=1, align="c"),
            dict(rect=(700, 505, 1245, 656), text="100万円", color=ORANGE, bold=True, lines=1, align="c"),
            dict(rect=(70, 446, 600, 548), text="対象者：市内に住宅を購入して\n転入する世帯", color=GREEN, bold=True, lines=2, align="l"),
            dict(rect=(72, 584, 545, 640), text="開始時期：令和8年10月1日", color=GREEN, bold=True, lines=1, align="l"),
        ],
        "icons": [
            dict(rect=(66, 152, 322, 415), name="house"),
            dict(rect=(326, 152, 585, 415), name="calendar"),
            dict(rect=(862, 100, 1072, 292), name="star"),
        ],
    },
    3: {
        "texts": [
            dict(rect=(40, 44, 726, 132), text="補助額の内訳と加算", color=BLACK, bold=True, lines=1, align="l", fill=FILL_WHITE),
            dict(rect=(70, 388, 240, 520), text="基本額\n5万円", color=WHITE, bold=True, lines=2, align="c", fill=FILL_GREEN_BOX),
            # panel 1
            dict(rect=(583, 205, 882, 272), text="子ども加算", color=GREEN, bold=True, lines=1, align="l", fill=FILL_WHITE),
            dict(rect=(583, 282, 980, 324), text="中学生以下の子ども1人につき", color=GRAY, bold=False, lines=1, align="l", fill=FILL_WHITE),
            dict(rect=(966, 208, 1312, 322), text="+20万円", color=ORANGE, bold=True, lines=1, align="c", fill=FILL_WHITE),
            # panel 2
            dict(rect=(583, 402, 980, 468), text="福岡都市圏加算", color=GREEN, bold=True, lines=1, align="l", fill=FILL_WHITE),
            dict(rect=(583, 470, 912, 514), text="福岡都市圏からの転入で", color=GRAY, bold=False, lines=1, align="l", fill=FILL_WHITE),
            dict(rect=(966, 404, 1312, 518), text="+25万円", color=ORANGE, bold=True, lines=1, align="c", fill=FILL_WHITE),
            # panel 3
            dict(rect=(583, 590, 928, 658), text="Uターン加算", color=GREEN, bold=True, lines=1, align="l", fill=FILL_WHITE),
            dict(rect=(583, 658, 946, 704), text="久留米市出身者が戻る場合", color=GRAY, bold=False, lines=1, align="l", fill=FILL_WHITE),
            dict(rect=(966, 592, 1312, 706), text="+10万円", color=ORANGE, bold=True, lines=1, align="c", fill=FILL_WHITE),
        ],
        "icons": [
            dict(rect=(290, 400, 396, 506), name="plus", fill=FILL_WHITE),
            dict(rect=(498, 218, 568, 308), fill_rect=(480, 200, 585, 320), name="child", fill=FILL_WHITE),
            dict(rect=(498, 408, 568, 498), fill_rect=(480, 390, 585, 510), name="building", fill=FILL_WHITE),
            dict(rect=(498, 598, 568, 688), fill_rect=(480, 580, 585, 700), name="uturn", fill=FILL_WHITE),
        ],
    },
}


def load_images():
    z = zipfile.ZipFile(str(SRC))
    imgs = {}
    for idx in (1, 2, 3):
        raw = z.read(f"ppt/media/image{idx}.png")
        imgs[idx] = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
    return imgs


def _fill_rect(base, rect, color, pad=2):
    x0, y0, x1, y1 = rect
    cv2.rectangle(base, (x0 - pad, y0 - pad), (x1 + pad, y1 + pad), color, -1)


def clean_white_smudges(base, panels):
    """Remove dark residue on near-white panel interiors (keep ribbon corners)."""
    out = base.copy()
    for x0, y0, x1, y1 in panels:
        roi = out[y0:y1, x0:x1].copy()
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        h, w = roi.shape[:2]
        protect = np.zeros((h, w), dtype=bool)
        protect[0 : min(130, h), 0 : min(150, w)] = True
        dirty = (gray < 246) & ~protect
        roi[dirty] = (255, 255, 255)
        out[y0:y1, x0:x1] = roi
    return out


def make_base(img, texts, icons, *, slide_idx: int):
    """Remove text/icon pixels using solid fills matched to local background."""
    base = img.copy()
    for t in texts:
        fill = t.get("fill")
        if fill is None:
            fill = FILL_WHITE if slide_idx == 3 else _sample_fill(img, t["rect"])
        _fill_rect(base, t["rect"], fill)
    for ic in icons:
        fill = ic.get("fill", FILL_WHITE)
        fill_r = ic.get("fill_rect", ic["rect"])
        _fill_rect(base, fill_r, fill, pad=2)
    if slide_idx == 3:
        base = clean_white_smudges(
            base,
            [
                (410, 165, 1330, 345),
                (410, 355, 1330, 545),
                (410, 555, 1330, 735),
            ],
        )
    return base


def _sample_fill(img, rect):
    x0, y0, x1, y1 = rect
    h, w = img.shape[:2]
    # sample a ring just outside the rect
    pad = 8
    samples = []
    for sy0, sy1, sx0, sx1 in [
        (max(0, y0 - pad - 20), max(0, y0 - pad), max(0, x0 - pad), min(w, x1 + pad)),
        (min(h, y1 + pad), min(h, y1 + pad + 20), max(0, x0 - pad), min(w, x1 + pad)),
        (max(0, y0 - pad), min(h, y1 + pad), max(0, x0 - pad - 20), max(0, x0 - pad)),
        (max(0, y0 - pad), min(h, y1 + pad), min(w, x1 + pad), min(w, x1 + pad + 20)),
    ]:
        patch = img[sy0:sy1, sx0:sx1]
        if patch.size:
            samples.append(patch.reshape(-1, 3))
    if not samples:
        return FILL_WHITE
    all_px = np.vstack(samples).astype(np.float32)
    return tuple(int(c) for c in np.median(all_px, axis=0))


def extract_icon_png(img, rect):
    x0, y0, x1, y1 = rect
    crop = img[y0:y1, x0:x1]
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY).astype(np.float32)
    alpha = np.clip((248.0 - gray) / 12.0, 0.0, 1.0)
    alpha = (alpha * 255).astype(np.uint8)
    # drop isolated dark fringe pixels
    alpha = cv2.morphologyEx(alpha, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    b, g, r = cv2.split(crop)
    rgba = cv2.merge([r, g, b, alpha])
    return Image.fromarray(rgba, "RGBA")


def px_to_emu(px, py, pic):
    left, top, w, h, iw, ih = pic
    x = left + int(round(px / iw * w))
    y = top + int(round(py / ih * h))
    return x, y


def build():
    ICON_DIR.mkdir(parents=True, exist_ok=True)
    imgs = load_images()
    prs = Presentation(str(SRC))
    pic_geom = {}
    # capture original picture geometry then clear slides' picture
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    for si, slide in enumerate(prs.slides, start=1):
        pics = [s for s in slide.shapes if s.shape_type == MSO_SHAPE_TYPE.PICTURE]
        pic = max(pics, key=lambda s: int(s.width) * int(s.height))
        iw, ih = imgs[si].shape[1], imgs[si].shape[0]
        pic_geom[si] = (int(pic.left), int(pic.top), int(pic.width), int(pic.height), iw, ih)
        pic._element.getparent().remove(pic._element)

    preview_imgs = {}
    for si, slide in enumerate(prs.slides, start=1):
        conf = SLIDES[si]
        img = imgs[si]
        base = make_base(img, conf["texts"], conf["icons"], slide_idx=si)
        geom = pic_geom[si]
        left, top, w, h, iw, ih = geom

        # base picture
        ok, enc = cv2.imencode(".png", base)
        slide.shapes.add_picture(io.BytesIO(enc.tobytes()), Emu(left), Emu(top), width=Emu(w), height=Emu(h))

        # preview canvas (RGB)
        prev = cv2.cvtColor(base, cv2.COLOR_BGR2RGB)
        prev = Image.fromarray(prev).convert("RGBA")

        # icons
        for ic in conf["icons"]:
            png = extract_icon_png(img, ic["rect"])
            fp = ICON_DIR / f"slide{si}_{ic['name']}.png"
            png.save(fp)
            x0, y0, x1, y1 = ic["rect"]
            lx, ly = px_to_emu(x0, y0, geom)
            rx, ry = px_to_emu(x1, y1, geom)
            with open(fp, "rb") as fh:
                slide.shapes.add_picture(fh, Emu(lx), Emu(ly), width=Emu(rx - lx), height=Emu(ry - ly))
            prev.alpha_composite(png, (x0, y0))

        # text boxes
        draw = ImageDraw.Draw(prev)
        for t in conf["texts"]:
            x0, y0, x1, y1 = t["rect"]
            bw, bh = x1 - x0, y1 - y0
            lines = t["lines"]
            # font size in points
            box_h_pt = bh * (h / EMU_PER_PT) / ih
            fs_pt = max(9.0, min(80.0, box_h_pt / lines * 0.78))

            lx, ly = px_to_emu(x0, y0, geom)
            rx, ry = px_to_emu(x1, y1, geom)
            tb = slide.shapes.add_textbox(Emu(lx), Emu(ly), Emu(rx - lx), Emu(ry - ly))
            tf = tb.text_frame
            tf.word_wrap = True
            tf.margin_left = 0
            tf.margin_right = 0
            tf.margin_top = 0
            tf.margin_bottom = 0
            tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            parts = t["text"].split("\n")
            for i, line in enumerate(parts):
                p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
                p.alignment = {"l": PP_ALIGN.LEFT, "c": PP_ALIGN.CENTER, "r": PP_ALIGN.RIGHT}[t["align"]]
                run = p.add_run()
                run.text = line
                run.font.size = Pt(round(fs_pt, 1))
                run.font.bold = t["bold"]
                run.font.name = PPTX_FONT
                run.font.color.rgb = RGBColor(*t["color"])

            # preview text (approx)
            fs_px = int(fs_pt / (h / EMU_PER_PT) * ih)
            try:
                font = ImageFont.truetype(FONT_BOLD if t["bold"] else FONT_REG, max(10, fs_px))
            except Exception:
                font = ImageFont.load_default()
            cur_y = y0
            for line in parts:
                tb_ = draw.textbbox((0, 0), line, font=font)
                lw = tb_[2] - tb_[0]
                if t["align"] == "c":
                    tx = x0 + (bw - lw) // 2
                elif t["align"] == "r":
                    tx = x1 - lw
                else:
                    tx = x0
                draw.text((tx, cur_y), line, font=font, fill=t["color"] + (255,))
                cur_y += int(fs_px * 1.15)

        preview_imgs[si] = prev.convert("RGB")
        prev.convert("RGB").save(VIEW / f"preview_slide{si}.png")
        print(f"slide {si}: {len(conf['texts'])} texts, {len(conf['icons'])} icons")

    out_pptx = OUT_DIR / "New_Kurume_Relocation_Subsidy_(7)_decomposed_v2.pptx"
    prs.save(str(out_pptx))
    print("saved", out_pptx)


if __name__ == "__main__":
    build()

# -*- coding: utf-8 -*-
"""Try alternate sorts on APbatch10 (94 ending with 橋本真由美)."""
import csv, io, os
from pathlib import Path

OUT = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
LOG = Path(r"c:\Users\newor\こいこい用\photos-slides\tools\_identify_imported.txt")

rows = list(csv.reader(io.StringIO((OUT / "APbatch10.csv").read_bytes().decode("cp932"))))
data = rows[1:]
lines = [f"APbatch10 n={len(data)} file_last={data[-1]}"]

def show(label, key):
    sc = sorted(data, key=key)
    lines.append(f"\n{label}")
    lines.append(f"  #1={sc[0]}")
    lines.append(f"  #2={sc[1]}")
    lines.append(f"  #3={sc[2]}")
    lines.append(f"  #last={sc[-1]}")
    for name, pred in [
        ("江本", lambda r: r[0] == "江本"),
        ("さえこ", lambda r: "さえこ" in "".join(r)),
        ("橋本真由美", lambda r: r[0] == "橋本" and "真由美" in r[1]),
    ]:
        i = next((i for i, r in enumerate(sc) if pred(r)), None)
        lines.append(f"  {name}#{None if i is None else i+1}")

show("sort by 姓+名", lambda r: (r[0], r[1]))
show("sort by 名+姓", lambda r: (r[1], r[0]))
show("sort by email", lambda r: next(c for c in r if "@" in c).lower())
show("sort by 姓 only", lambda r: r[0])
# reverse file order
rev = list(reversed(data))
lines.append("\nreverse file order")
lines.append(f"  #1={rev[0]}")
lines.append(f"  #2={rev[1]}")
lines.append(f"  #last={rev[-1]}")

LOG.write_text("\n".join(lines), encoding="utf-8")
print("ok")

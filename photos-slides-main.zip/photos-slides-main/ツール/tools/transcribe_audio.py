"""Transcribe audio to text using faster-whisper."""
import sys
from pathlib import Path

from faster_whisper import WhisperModel


def transcribe(audio_path: str, output_path: str, model_path: str = "medium") -> None:
    audio = Path(audio_path)
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    print(f"Loading model: {model_path}", flush=True)
    model = WhisperModel(model_path, device="cpu", compute_type="int8")

    print(f"Transcribing: {audio}", flush=True)
    segments, info = model.transcribe(
        str(audio),
        language="ja",
        vad_filter=True,
        beam_size=5,
    )
    print(f"Language: {info.language} (prob={info.language_probability:.2f})", flush=True)

    lines: list[str] = []
    for segment in segments:
        start = format_time(segment.start)
        end = format_time(segment.end)
        text = segment.text.strip()
        if text:
            lines.append(f"[{start} - {end}] {text}")

    body = "\n".join(lines) + ("\n" if lines else "")
    out.write_text(body, encoding="utf-8")
    print(f"Done. Wrote {len(lines)} segments to {out}", flush=True)


def format_time(seconds: float) -> str:
    total = int(seconds)
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python transcribe_audio.py <audio_path> <output_path> [model_path]")
        sys.exit(1)
    model_path = sys.argv[3] if len(sys.argv) > 3 else "medium"
    transcribe(sys.argv[1], sys.argv[2], model_path)
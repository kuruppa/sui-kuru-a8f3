# -*- coding: utf-8 -*-
import csv, io, os, zipfile
from pathlib import Path

OUT = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
LOG = Path(r"c:\Users\newor\こいこい用\photos-slides\tools\_batch02_check.txt")
lines = []

with zipfile.ZipFile(OUT / "202512.zip") as z:
    n = next(x for x in z.namelist() if x.endswith(".csv"))
    allrows = list(csv.reader(io.StringIO(z.read(n).decode("cp932"))))
data = [r for r in allrows[1:] if any("@" in c for c in r)]

for i, r in enumerate(data):
    joined = "".join(r)
    if "柳沢" in joined or "柳澤" in joined or "由理" in joined:
        lines.append(f"ZIP#{i+1} {r}")

rows = list(csv.reader(io.StringIO((OUT / "APbatch02.csv").read_bytes().decode("cp932"))))
d = rows[1:]
lines.append(f"\nAPbatch02 n={len(d)}")
lines.append(f"file#1={d[0]}")
lines.append(f"file#2={d[1]}")
lines.append(f"file#last={d[-1]}")

# show name-sort first 5 of batch02
sc = sorted(d, key=lambda r: (r[0], r[1]))
for i, r in enumerate(sc[:5], 1):
    lines.append(f"name#{i}={r}")

LOG.write_text("\n".join(lines), encoding="utf-8")
print("ok")

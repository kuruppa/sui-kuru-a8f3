# SNS予約投稿（X + Threads）

Googleスプレッドシート + Google Apps Script で、**X（Twitter）** と **Threads** へ予約投稿します。

## できること

- 日時・本文・プラットフォーム（X / Threads / 両方）をシートで管理
- **API成功時だけ**「完了」シートへ移動（失敗時は行を残してエラー表示）
- Cursor チャット用の `queue.jsonl` から一括取込
- 5分おきトリガーで自動投稿

## できないこと（正直な話）

**Cursor のチャットだけ**では、指定時刻に PC が起きていなくても投稿することはできません。  
代わりに次の流れにします。

1. **あなた**: このチャットに「6/25 10:00 両方: 本文…」と伝える  
2. **Cursor**: `queue.jsonl` に追記（または貼り付け用 JSONL を返す）  
3. **Google**: メニュー「キュー取込」→ 5分トリガーが投稿

---

## セットアップ（初回30〜60分）

### 1. スプレッドシートにコードを載せる

1. 新規 Google スプレッドシートを作成（または既存シートを流用）
2. **拡張機能 → Apps Script**
3. このフォルダ内の `.gs` ファイルをすべてコピー
4. **ライブラリ** を追加: `OAuth1`（ID: `1B7FSrk5Zi6L1rSxxTDgDEUsPzlukDsi4KGuTMorsTQHhGBzBkMun4iDF`）
5. エディタで `bootstrapOnce_` を1回実行 → 「予約」「完了」シートができる

### 2. X API（Pay-per-use）

[developer.x.com](https://developer.x.com) で:

1. Project に App を紐づけ
2. Billing でクレジット購入（目安 $5）
3. App permissions: **Read and Write**
4. Keys and tokens を再生成

Apps Script → **プロジェクトの設定 → スクリプト プロパティ**:

| キー | 値 |
|------|-----|
| `X_API_KEY` | API Key |
| `X_API_SECRET` | API Key Secret |
| `X_ACCESS_TOKEN` | Access Token |
| `X_ACCESS_SECRET` | Access Token Secret |

メニュー **SNS予約 → テスト投稿（X）** で確認。

### 3. Threads API

[developers.facebook.com](https://developers.facebook.com) で:

1. アプリ作成 → **Threads API** を追加
2. 権限: `threads_basic`, `threads_content_publish`
3. 長期アクセストークンと Threads ユーザー ID を取得

スクリプト プロパティ:

| キー | 値 |
|------|-----|
| `THREADS_USER_ID` | 数値のユーザー ID |
| `THREADS_ACCESS_TOKEN` | 長期トークン |

※ Threads は現状 **テキストのみ**（画像は X 側のみ対応）。

### 4. 自動実行

スプレッドシートを開き **SNS予約 → 5分おきトリガーを設定**。

---

## シートの使い方

| 列 | 入力例 |
|----|--------|
| 投稿文 | 本文 |
| 日付 | 2026/6/25 |
| 時刻 | 10:00 |
| プラットフォーム | `X` / `Threads` / `両方` |
| 投稿する | チェック ON |
| ステータス | 自動（入力完了 / 投稿中 / エラー） |

予約時刻の **±5分以内** にトリガーが走ったとき投稿します。

---

## Cursor チャットから予約する

`queue.jsonl` に1行1JSON:

```json
{"date":"2026-06-25","time":"10:00","platforms":"両方","text":"投稿本文"}
```

チャット例:

> 6/25 10:00 XとThreads両方で「くるっぱ更新しました」を予約して

→ Cursor が JSONL を追記 → シートで **SNS予約 → キュー取込**。

---

## 旧ツールからの移行

旧「エクスケ」ツールは **失敗しても行を消す** 実装でした。  
このツールは **成功時のみ完了シートへ移動** します。

function validateAllRows_() {
  const sheet = getQueueSheet_();
  const lastRow = findLastDataRow_(sheet, COL.DATE);
  for (let row = HEAD_ROW + 1; row <= lastRow; row++) {
    validateRow_(row);
  }
  SpreadsheetApp.getActiveSpreadsheet().toast('入力チェック完了', 'SNS予約', 3);
}

function validateRow_(row) {
  const sheet = getQueueSheet_();
  const values = sheet.getRange(row, 1, 1, COL.ERROR).getValues()[0];
  const text = String(values[COL.TEXT - 1] || '').trim();
  const dateVal = values[COL.DATE - 1];
  const timeVal = values[COL.TIME - 1];
  const platforms = normalizePlatforms_(values[COL.PLATFORMS - 1]);

  if (!text && !dateVal && !timeVal) {
    sheet.getRange(row, COL.STATUS).setValue('');
    sheet.getRange(row, COL.ERROR).setValue('');
    return [];
  }

  const errors = [];

  if (!text) errors.push('投稿文');
  if (platforms.indexOf(PLATFORM.X) >= 0 && text.length > 280) errors.push('X文字数（280超）');
  if (platforms.indexOf(PLATFORM.THREADS) >= 0 && text.length > 500) errors.push('Threads文字数（500超）');
  if (!(dateVal instanceof Date)) errors.push('日付');
  if (!(timeVal instanceof Date)) errors.push('時刻');
  if (!platforms.length) errors.push('プラットフォーム');

  if (dateVal instanceof Date && timeVal instanceof Date) {
    const scheduled = combineDateTime_(dateVal, timeVal);
    if (scheduled.getTime() < Date.now() - 60 * 1000) {
      errors.push('日付が過去');
    }
  }

  const statusCell = sheet.getRange(row, COL.STATUS);
  const errorCell = sheet.getRange(row, COL.ERROR);
  const countCell = sheet.getRange(row, COL.CHAR_COUNT);

  countCell.setValue(text.length);

  if (errors.length) {
    statusCell.setValue('未完（' + errors.join('、') + '）');
    errorCell.setValue('');
    sheet.getRange(row, COL.READY).setValue(false);
  } else {
    statusCell.setValue(STATUS.COMPLETE);
    errorCell.setValue('');
  }

  return errors;
}

function onEdit(e) {
  if (!e || !e.range) return;
  const sheet = e.range.getSheet();
  if (sheet.getName() !== TAB_QUEUE) return;
  if (e.range.getRow() <= HEAD_ROW) return;

  const col = e.range.getColumn();
  if (
    col === COL.TEXT ||
    col === COL.DATE ||
    col === COL.TIME ||
    col === COL.PLATFORMS
  ) {
    validateRow_(e.range.getRow());
  }
}

function normalizePlatforms_(raw) {
  const s = String(raw || '').trim();
  if (!s) return [];
  if (s === PLATFORM.BOTH || s === 'X+Threads' || s === 'x,threads') {
    return [PLATFORM.X, PLATFORM.THREADS];
  }
  if (s === PLATFORM.X || s.toLowerCase() === 'x') return [PLATFORM.X];
  if (s === PLATFORM.THREADS || s.toLowerCase() === 'threads') return [PLATFORM.THREADS];
  return [];
}

function combineDateTime_(dateVal, timeVal) {
  const d = new Date(dateVal.getFullYear(), dateVal.getMonth(), dateVal.getDate());
  d.setHours(timeVal.getHours(), timeVal.getMinutes(), 0, 0);
  return d;
}

function isDue_(dateVal, timeVal, windowSeconds) {
  const scheduled = combineDateTime_(dateVal, timeVal);
  const diffSec = (Date.now() - scheduled.getTime()) / 1000;
  return diffSec >= 0 && diffSec <= windowSeconds;
}

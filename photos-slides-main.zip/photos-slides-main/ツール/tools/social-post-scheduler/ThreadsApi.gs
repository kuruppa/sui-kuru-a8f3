function postToThreads_(text) {
  const userId = getSecret_(PROP.THREADS_USER_ID);
  const token = getSecret_(PROP.THREADS_ACCESS_TOKEN);
  if (!userId || !token) {
    throw new Error('Threads 認証情報が未設定です（THREADS_USER_ID / THREADS_ACCESS_TOKEN）');
  }

  const createUrl =
    THREADS_GRAPH +
    '/' +
    encodeURIComponent(userId) +
    '/threads?' +
    buildQuery_({
      media_type: 'TEXT',
      text: text,
      access_token: token,
    });

  const createRes = UrlFetchApp.fetch(createUrl, { method: 'post', muteHttpExceptions: true });
  const createCode = createRes.getResponseCode();
  const createBody = createRes.getContentText();
  if (createCode < 200 || createCode >= 300) {
    throw new Error('Threads 作成失敗 ' + createCode + ': ' + createBody);
  }

  const creationId = JSON.parse(createBody).id;
  if (!creationId) {
    throw new Error('Threads creation_id がありません: ' + createBody);
  }

  Utilities.sleep(3000);

  const publishUrl =
    THREADS_GRAPH +
    '/' +
    encodeURIComponent(userId) +
    '/threads_publish?' +
    buildQuery_({
      creation_id: creationId,
      access_token: token,
    });

  const publishRes = UrlFetchApp.fetch(publishUrl, { method: 'post', muteHttpExceptions: true });
  const publishCode = publishRes.getResponseCode();
  const publishBody = publishRes.getContentText();
  if (publishCode < 200 || publishCode >= 300) {
    throw new Error('Threads 公開失敗 ' + publishCode + ': ' + publishBody);
  }

  const postId = JSON.parse(publishBody).id;
  if (!postId) {
    throw new Error('Threads 投稿ID がありません: ' + publishBody);
  }
  return String(postId);
}

function buildQuery_(params) {
  return Object.keys(params)
    .map(function (key) {
      return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
    })
    .join('&');
}

function getQueueSheet_() {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TAB_QUEUE);
}

function getDoneSheet_() {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TAB_DONE);
}

function findLastDataRow_(sheet, col) {
  const values = sheet.getRange(HEAD_ROW + 1, col, Math.max(sheet.getLastRow(), HEAD_ROW + 1), 1).getValues();
  for (let i = values.length - 1; i >= 0; i--) {
    if (values[i][0] !== '' && values[i][0] !== null) return HEAD_ROW + 1 + i;
  }
  return HEAD_ROW;
}

function appendQueueRow_(entry) {
  const sheet = getQueueSheet_();
  const row = Math.max(sheet.getLastRow(), HEAD_ROW) + 1;
  sheet.getRange(row, COL.TEXT).setValue(entry.text || '');
  sheet.getRange(row, COL.DATE).setValue(parseDate_(entry.date));
  sheet.getRange(row, COL.TIME).setValue(parseTime_(entry.time));
  sheet.getRange(row, COL.PLATFORMS).setValue(entry.platforms || PLATFORM.BOTH);
  sheet.getRange(row, COL.READY).setValue(true);
  validateRow_(row);
  return row;
}

function parseDate_(s) {
  if (!s) return '';
  const m = String(s).match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
  if (!m) return s;
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
}

function parseTime_(s) {
  const str = String(s || '').trim();
  const m = str.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return str;
  const d = new Date();
  d.setHours(Number(m[1]), Number(m[2]), 0, 0);
  return d;
}

function importQueueJsonl_(raw) {
  const lines = String(raw || '')
    .split(/\r?\n/)
    .map(function (l) {
      return l.trim();
    })
    .filter(Boolean);
  let count = 0;
  lines.forEach(function (line) {
    try {
      appendQueueRow_(JSON.parse(line));
      count++;
    } catch (err) {
      console.error('Skip invalid JSONL line: ' + line + ' / ' + err);
    }
  });
  return count;
}

function moveRowToDone_(row, result) {
  const queue = getQueueSheet_();
  const done = getDoneSheet_();
  const values = queue.getRange(row, 1, 1, COL.ERROR).getValues()[0];
  const dest = Math.max(done.getLastRow(), HEAD_ROW) + 1;
  done.getRange(dest, 1, 1, COL.ERROR).setValues([values]);
  done.getRange(dest, COL.STATUS).setValue(result.status);
  done.getRange(dest, COL.X_POST_ID).setValue(result.xPostId || '');
  done.getRange(dest, COL.THREADS_POST_ID).setValue(result.threadsPostId || '');
  done.getRange(dest, COL.ERROR).setValue(result.error || '');
  queue.deleteRow(row);
}

function markRowFailed_(row, message) {
  const sheet = getQueueSheet_();
  sheet.getRange(row, COL.STATUS).setValue(STATUS.FAILED);
  sheet.getRange(row, COL.ERROR).setValue(message);
  sheet.getRange(row, COL.READY).setValue(false);
}

function markRowPosting_(row) {
  getQueueSheet_().getRange(row, COL.STATUS).setValue(STATUS.POSTING);
}

function setupSheetHeaders_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let queue = ss.getSheetByName(TAB_QUEUE);
  if (!queue) queue = ss.insertSheet(TAB_QUEUE);
  let done = ss.getSheetByName(TAB_DONE);
  if (!done) done = ss.insertSheet(TAB_DONE);

  const headers = [
    '投稿文',
    '文字数',
    '日付',
    '時刻',
    'プラットフォーム',
    '投稿する',
    'ステータス',
    '画像URL1',
    '画像URL2',
    '画像URL3',
    '画像URL4',
    'X投稿ID',
    'Threads投稿ID',
    'エラー内容',
  ];
  queue.getRange(1, 1, 1, headers.length).setValues([headers]);
  done.getRange(1, 1, 1, headers.length).setValues([headers]);
  queue.setFrozenRows(1);
  done.setFrozenRows(1);
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('SNS予約')
    .addItem('マニュアルを開く', 'openManual_')
    .addSeparator()
    .addItem('入力チェック（全行）', 'validateAllRows_')
    .addItem('キュー取込（JSONL貼り付け）', 'importQueueFromPrompt_')
    .addSeparator()
    .addItem('今すぐ期限到来分を投稿', 'processDuePosts_')
    .addItem('テスト投稿（X・Threads）', 'runTestPostsBoth_')
    .addSeparator()
    .addItem('5分おきトリガーを設定', 'installMinuteTrigger_')
    .addItem('トリガーを削除', 'removeTriggers_')
    .addToUi();
}

function openManual_() {
  const url = 'https://github.com/'; // README を参照（ローカル tools/social-post-scheduler/README.md）
  const html = HtmlService.createHtmlOutput(
    '<p>セットアップ手順は <code>tools/social-post-scheduler/README.md</code> を参照してください。</p>' +
      '<p><a href="' + url + '" target="_blank">（任意）外部マニュアル</a></p>'
  );
  SpreadsheetApp.getUi().showModalDialog(html, 'SNS予約マニュアル');
}

function installMinuteTrigger_() {
  removeTriggers_();
  ScriptApp.newTrigger('processDuePosts_')
    .timeBased()
    .everyMinutes(5)
    .create();
  SpreadsheetApp.getActiveSpreadsheet().toast('5分おきの投稿チェックを設定しました', 'SNS予約', 5);
}

function removeTriggers_() {
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (trigger.getHandlerFunction() === 'processDuePosts_') {
      ScriptApp.deleteTrigger(trigger);
    }
  });
}

function importQueueFromPrompt_() {
  const ui = SpreadsheetApp.getUi();
  const res = ui.prompt(
    'キュー取込',
    'Cursor で作成した queue.jsonl の内容をそのまま貼り付けてください（複数行可）',
    ui.ButtonSet.OK_CANCEL
  );
  if (res.getSelectedButton() !== ui.Button.OK) return;

  const count = importQueueJsonl_(res.getResponseText());
  ui.alert('取込完了', count + ' 件を予約シートに追加しました。', ui.ButtonSet.OK);
}

/**
 * 設定値・シート名・列定義
 * Script Properties に保存する秘密情報は setupSecrets() またはメニューから設定
 */

const TAB_QUEUE = '予約';
const TAB_DONE = '完了';
const TAB_CONFIG = '設定';

const HEAD_ROW = 1;

const COL = {
  TEXT: 1,
  CHAR_COUNT: 2,
  DATE: 3,
  TIME: 4,
  PLATFORMS: 5,
  READY: 6,
  STATUS: 7,
  IMAGE1: 8,
  IMAGE2: 9,
  IMAGE3: 10,
  IMAGE4: 11,
  X_POST_ID: 12,
  THREADS_POST_ID: 13,
  ERROR: 14,
};

const STATUS = {
  COMPLETE: '入力完了',
  POSTING: '投稿中',
  POSTED: '投稿済み',
  PARTIAL: '一部成功',
  FAILED: '投稿失敗',
};

const PLATFORM = {
  X: 'X',
  THREADS: 'Threads',
  BOTH: '両方',
};

const X_TWEET_URL = 'https://api.twitter.com/2/tweets';
const X_UPLOAD_URL = 'https://upload.twitter.com/1.1/media/upload.json';

const THREADS_GRAPH = 'https://graph.threads.net/v1.0';

const PROP = {
  X_API_KEY: 'X_API_KEY',
  X_API_SECRET: 'X_API_SECRET',
  X_ACCESS_TOKEN: 'X_ACCESS_TOKEN',
  X_ACCESS_SECRET: 'X_ACCESS_SECRET',
  THREADS_USER_ID: 'THREADS_USER_ID',
  THREADS_ACCESS_TOKEN: 'THREADS_ACCESS_TOKEN',
};

function getSecret_(key) {
  return PropertiesService.getScriptProperties().getProperty(key) || '';
}

function setSecrets_(secrets) {
  PropertiesService.getScriptProperties().setProperties(secrets, true);
}

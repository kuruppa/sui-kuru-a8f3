/**
 * 期限到来した予約を1件ずつ処理（5分トリガーから呼ぶ）
 */
function processDuePosts_() {
  const sheet = getQueueSheet_();
  const lastRow = findLastDataRow_(sheet, COL.DATE);
  const windowSeconds = 300;

  for (let row = HEAD_ROW + 1; row <= lastRow; row++) {
    const values = sheet.getRange(row, 1, 1, COL.ERROR).getValues()[0];
    const ready = values[COL.READY - 1] === true;
    if (!ready) continue;

    const errors = validateRow_(row);
    const onlyPastDate =
      errors.length === 1 && errors[0] === '日付が過去';
    if (errors.length && !onlyPastDate) continue;

    const dateVal = values[COL.DATE - 1];
    const timeVal = values[COL.TIME - 1];
    if (!(dateVal instanceof Date) || !(timeVal instanceof Date)) continue;
    if (!isDue_(dateVal, timeVal, windowSeconds)) continue;

    processSingleRow_(row, values);
    return;
  }
}

function processSingleRow_(row, values) {
  markRowPosting_(row);

  const text = String(values[COL.TEXT - 1] || '').trim();
  const platforms = normalizePlatforms_(values[COL.PLATFORMS - 1]);
  const result = {
    status: STATUS.POSTED,
    xPostId: '',
    threadsPostId: '',
    error: '',
  };

  const failures = [];

  if (platforms.indexOf(PLATFORM.X) >= 0) {
    try {
      const mediaIds = collectMediaIdsFromRow_(values);
      result.xPostId = postToX_(text, mediaIds);
    } catch (err) {
      failures.push('X: ' + err.message);
    }
  }

  if (platforms.indexOf(PLATFORM.THREADS) >= 0) {
    try {
      result.threadsPostId = postToThreads_(text);
    } catch (err) {
      failures.push('Threads: ' + err.message);
    }
  }

  if (failures.length === platforms.length) {
    markRowFailed_(row, failures.join('\n'));
    return;
  }

  if (failures.length) {
    result.status = STATUS.PARTIAL;
    result.error = failures.join('\n');
  }

  moveRowToDone_(row, result);
}

/**
 * 初回セットアップ: シート見出し作成 + Script Properties 例
 * Apps Script エディタから1回実行
 */
function bootstrapOnce_() {
  setupSheetHeaders_();
  Logger.log('シート見出しを作成しました。Script Properties に API キーを設定してください。');
}

function runTestPostsBoth_() {
  const stamp = Utilities.formatDate(new Date(), 'Asia/Tokyo', 'yyyy-MM-dd HH:mm');
  const lines = [];

  try {
    const xId = postToX_('SNS予約ツール Xテスト ' + stamp, []);
    lines.push('X: 成功（ID ' + xId + '）');
  } catch (err) {
    lines.push('X: 失敗\n' + err.message);
  }

  try {
    const tId = postToThreads_('SNS予約ツール Threadsテスト ' + stamp);
    lines.push('Threads: 成功（ID ' + tId + '）');
  } catch (err) {
    lines.push('Threads: 失敗\n' + err.message);
  }

  SpreadsheetApp.getUi().alert(lines.join('\n\n'));
}

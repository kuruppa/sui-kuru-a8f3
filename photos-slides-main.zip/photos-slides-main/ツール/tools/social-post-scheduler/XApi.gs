function getTwitterService_() {
  const service = OAuth1.createService('Twitter')
    .setAccessTokenUrl('https://api.twitter.com/oauth/access_token')
    .setRequestTokenUrl('https://api.twitter.com/oauth/request_token')
    .setAuthorizationUrl('https://api.twitter.com/oauth/authorize')
    .setConsumerKey(getSecret_(PROP.X_API_KEY))
    .setConsumerSecret(getSecret_(PROP.X_API_SECRET))
    .setAccessToken(getSecret_(PROP.X_ACCESS_TOKEN), getSecret_(PROP.X_ACCESS_SECRET))
    .setPropertyStore(PropertiesService.getScriptProperties());
  return service;
}

function xRequest_(url, options) {
  const service = getTwitterService_();
  if (!service.hasAccess()) {
    throw new Error('X API 認証情報が未設定です（Script Properties の4キーを確認）');
  }
  const res = service.fetch(url, options || {});
  const code = res.getResponseCode();
  const body = res.getContentText();
  if (code < 200 || code >= 300) {
    throw new Error('X API ' + code + ': ' + body);
  }
  return JSON.parse(body);
}

function postToX_(text, mediaIds) {
  const payload = { text: text };
  if (mediaIds && mediaIds.length) {
    payload.media = { media_ids: mediaIds };
  }
  const json = xRequest_(X_TWEET_URL, {
    method: 'post',
    payload: JSON.stringify(payload),
    contentType: 'application/json',
    muteHttpExceptions: true,
  });
  if (!json.data || !json.data.id) {
    throw new Error('X API 応答に投稿IDがありません: ' + JSON.stringify(json));
  }
  return String(json.data.id);
}

function uploadImageToX_(driveUrl) {
  const match = String(driveUrl || '').match(/\/file\/d\/([^/]+)/);
  if (!match) return null;

  const file = DriveApp.getFileById(match[1]);
  const service = getTwitterService_();
  const payload = {
    media_data: Utilities.base64Encode(file.getBlob().getBytes()),
  };
  const res = service.fetch(X_UPLOAD_URL, {
    method: 'post',
    payload: payload,
    muteHttpExceptions: true,
  });
  if (res.getResponseCode() !== 200) {
    throw new Error('X 画像アップロード失敗: ' + res.getContentText());
  }
  return JSON.parse(res.getContentText()).media_id_string;
}

function collectMediaIdsFromRow_(values) {
  const ids = [];
  for (let c = COL.IMAGE1; c <= COL.IMAGE4; c++) {
    const url = values[c - 1];
    if (typeof url === 'string' && url.trim()) {
      const mediaId = uploadImageToX_(url.trim());
      if (mediaId) ids.push(mediaId);
    }
  }
  return ids;
}

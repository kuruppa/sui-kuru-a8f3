# -*- coding: utf-8 -*-
"""Rebuild 10 batch CSVs from 202512.zip (CP932, proper header)."""
from __future__ import annotations

import csv
import io
import os
import zipfile
from pathlib import Path

OUT_DIR = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
ZIP_PATH = OUT_DIR / "202512.zip"
LOG_PATH = Path(__file__).with_name("_csv_rebuild_log.txt")
BATCH_COUNT = 10


def main() -> None:
    log: list[str] = []
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(ZIP_PATH) as z:
        csv_name = next(n for n in z.namelist() if n.lower().endswith(".csv"))
        text = z.read(csv_name).decode("cp932")
    rows = list(csv.reader(io.StringIO(text)))
    header, data = rows[0], rows[1:]

    # Keep only rows with email
    data = [r for r in data if any("@" in c for c in r)]

    # Prefer deliverable if column exists
    if len(header) >= 4 and "配信" in header[3]:
        deliverable = [r for r in data if len(r) > 3 and "可" in r[3] and "不可" not in r[3]]
        if deliverable:
            log.append(f"filtered deliverable: {len(deliverable)} / {len(data)}")
            data = deliverable

    sizes = []
    base, rem = divmod(len(data), BATCH_COUNT)
    sizes = [base + (1 if i < rem else 0) for i in range(BATCH_COUNT)]

    log.append(f"source: {ZIP_PATH}!{csv_name}")
    log.append(f"header: {header}")
    log.append(f"data rows: {len(data)}")
    log.append(f"batch sizes: {sizes} sum={sum(sizes)}")

    for p in list(OUT_DIR.glob("AP_batch_*.csv")) + list(OUT_DIR.glob("APbatch*.csv")):
        p.unlink()

    offset = 0
    for i, size in enumerate(sizes, start=1):
        chunk = data[offset : offset + size]
        offset += size
        # 7th-mail: filename must be half-width alphanumeric only
        out = OUT_DIR / f"APbatch{i:02d}.csv"
        with out.open("w", encoding="cp932", newline="") as f:
            w = csv.writer(f, lineterminator="\r\n")
            w.writerows([header] + chunk)

        # Round-trip verify
        check_text = out.read_bytes().decode("cp932")
        check = list(csv.reader(io.StringIO(check_text)))
        assert check[0] == header
        assert len(check) - 1 == size
        sample = check[1]
        log.append(
            f"wrote {out.name} | sample={sample[0]} {sample[1]} <{sample[2]}>"
        )

    LOG_PATH.write_text("\n".join(log), encoding="utf-8")
    print("OK", LOG_PATH)


if __name__ == "__main__":
    main()

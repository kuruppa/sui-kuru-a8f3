"""Extract embedded pictures from a .pptx into slide_NN/image_MM.ext + manifest.json."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE


def iter_shapes_recursive(container):
    for shape in container.shapes:
        yield shape
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes_recursive(shape)


def picture_shapes_from_slide(slide):
    for shape in iter_shapes_recursive(slide):
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            yield shape


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pptx_path", type=Path)
    parser.add_argument(
        "-o",
        "--out",
        type=Path,
        default=None,
        help="Output folder (default: <pptx_stem>_assets next to pptx)",
    )
    args = parser.parse_args()
    pptx_path: Path = args.pptx_path.resolve()
    out_root = (
        args.out.resolve()
        if args.out
        else pptx_path.parent / f"{pptx_path.stem}_assets"
    )
    out_root.mkdir(parents=True, exist_ok=True)

    prs = Presentation(str(pptx_path))
    manifest = {
        "source_pptx": str(pptx_path),
        "extracted_at_utc": datetime.now(timezone.utc).isoformat(),
        "slide_count": len(prs.slides),
        "slides": [],
    }

    for si, slide in enumerate(prs.slides, start=1):
        slide_dir = out_root / f"slide_{si:02d}"
        slide_dir.mkdir(parents=True, exist_ok=True)
        slide_entry = {
            "slide_index": si,
            "folder": str(slide_dir.relative_to(out_root)),
            "images": [],
        }
        pics = list(picture_shapes_from_slide(slide))
        for ii, pic in enumerate(pics, start=1):
            img = pic.image
            ext = (img.ext or "png").lower()
            if ext not in ("png", "jpeg", "jpg", "gif", "bmp", "tiff", "emf", "wmf"):
                ext = "png"
            fname = f"image_{ii:02d}.{ext}"
            fpath = slide_dir / fname
            fpath.write_bytes(img.blob)
            try:
                left_pt = pic.left / 914400 * 72
                top_pt = pic.top / 914400 * 72
                width_pt = pic.width / 914400 * 72
                height_pt = pic.height / 914400 * 72
            except Exception:
                left_pt = top_pt = width_pt = height_pt = None
            slide_entry["images"].append(
                {
                    "file": fname,
                    "content_type": img.content_type,
                    "on_slide_left_pt": round(left_pt, 2) if left_pt is not None else None,
                    "on_slide_top_pt": round(top_pt, 2) if top_pt is not None else None,
                    "on_slide_width_pt": round(width_pt, 2) if width_pt is not None else None,
                    "on_slide_height_pt": round(height_pt, 2) if height_pt is not None else None,
                }
            )
        manifest["slides"].append(slide_entry)

    (out_root / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(out_root)


if __name__ == "__main__":
    main()

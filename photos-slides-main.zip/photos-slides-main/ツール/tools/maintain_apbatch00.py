# -*- coding: utf-8 -*-
"""Maintain APbatch00.csv = people missed by normal batch imports.

Rule (user request 2026-07-16):
- When someone is in source CSV but NOT in the live 7th-mail import/export
  for their intended batch, append them to APbatch00.csv (not to 03-10).
- Filename: half-width alphanumeric only (7th-mail requirement).
"""
from __future__ import annotations

import csv
import io
import os
from pathlib import Path

OUT = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
BATCH00 = OUT / "APbatch00.csv"
LOG = Path(__file__).with_name("_apbatch00_log.txt")

# Known miss set to ensure on 00 (いろは / ゆぺ + original た ま)
ENSURE_EMAILS = [
    "pomta.cw.contact@gmail.com",  # た ま
    "yupe220126@gmail.com",  # ゆぺ
    "mokurennoyouni@gmail.com",  # いろは いろは
]


def read(path: Path) -> list[list[str]]:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp932", "utf-8"):
        try:
            return list(csv.reader(io.StringIO(raw.decode(enc))))
        except UnicodeDecodeError:
            continue
    return list(csv.reader(io.StringIO(raw.decode("cp932", errors="replace"))))


def email_of(row: list[str]) -> str | None:
    for c in row:
        if "@" in c:
            return c.strip().lower()
    return None


def find_row_in_batches(email: str) -> list[str] | None:
    for p in sorted(OUT.glob("APbatch*.csv")):
        if p.name == "APbatch00.csv":
            continue
        rows = read(p)
        if not rows:
            continue
        start = 1 if rows[0] and not any("@" in c for c in rows[0]) else 0
        for r in rows[start:]:
            if email_of(r) == email:
                return r
    return None


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    header = ["姓", "名", "メールアドレス", "配信可能/不可能"]
    existing: dict[str, list[str]] = {}

    # Merge old APbatch00extra / APextra if present
    for name in ("APbatch00.csv", "APbatch00extra.csv", "APextra.csv"):
        p = OUT / name
        if not p.exists():
            continue
        rows = read(p)
        start = 1 if rows and not any("@" in c for c in rows[0]) else 0
        if rows and start == 1:
            header = rows[0]
        for r in rows[start:]:
            e = email_of(r)
            if e:
                existing[e] = r

    for email in ENSURE_EMAILS:
        if email in existing:
            continue
        row = find_row_in_batches(email)
        if row is None:
            raise SystemExit(f"Cannot find source row for {email}")
        existing[email] = row

    # Stable order: ENSURE list first, then any extras
    ordered: list[list[str]] = []
    seen: set[str] = set()
    for email in ENSURE_EMAILS:
        ordered.append(existing[email])
        seen.add(email)
    for email, row in existing.items():
        if email not in seen:
            ordered.append(row)

    with BATCH00.open("w", encoding="cp932", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerows([header] + ordered)

    # Remove superseded files
    for name in ("APbatch00extra.csv", "APextra.csv"):
        p = OUT / name
        if p.exists():
            p.unlink()

    lines = [f"wrote {BATCH00} count={len(ordered)}"]
    for r in ordered:
        lines.append(str(r))
    LOG.write_text("\n".join(lines), encoding="utf-8")
    print("ok", len(ordered))


def append_emails(emails: list[str]) -> None:
    """Call when similar misses appear: append missing emails into APbatch00.csv."""
    if not BATCH00.exists():
        main()
        return
    rows = read(BATCH00)
    header = rows[0]
    existing = {email_of(r): r for r in rows[1:] if email_of(r)}
    added = []
    for email in emails:
        e = email.strip().lower()
        if e in existing:
            continue
        row = find_row_in_batches(e)
        if row is None:
            raise SystemExit(f"Cannot find source row for {e}")
        existing[e] = row
        added.append(e)
    ordered = list(existing.values())
    with BATCH00.open("w", encoding="cp932", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerows([header] + ordered)
    print("appended", added, "total", len(ordered))


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
import csv, io, os
from pathlib import Path

OUT = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
LOG = Path(r"c:\Users\newor\こいこい用\photos-slides\tools\_watanabe_pos.txt")

rows = list(csv.reader(io.StringIO((OUT / "APbatch10.csv").read_bytes().decode("cp932"))))
data = rows[1:]
lines = [f"n={len(data)}"]

# file order
for i, r in enumerate(data):
    if "uniuni6758" in "".join(r) or (r[0] == "渡部" and "友里恵" in r[1]):
        lines.append(f"file order #{i+1}: {r}")

# name sort
sc = sorted(data, key=lambda r: (r[0], r[1]))
for i, r in enumerate(sc):
    if "uniuni6758" in "".join(r) or (r[0] == "渡部" and "友里恵" in r[1]):
        lines.append(f"name sort #{i+1}: {r}")

# find さえこ, 江本, 橋本 in name sort
for label, pred in [
    ("さえこ", lambda r: "さえこ" in "".join(r)),
    ("江本忠之", lambda r: r[0] == "江本" and "忠之" in r[1]),
    ("橋本真由美", lambda r: r[0] == "橋本" and "真由美" in r[1]),
    ("渡部友里恵", lambda r: r[0] == "渡部" and "友里恵" in r[1]),
]:
    i = next(i for i, r in enumerate(sc) if pred(r))
    lines.append(f"name-sort {label} #{i+1}")

# positions near 35 in name sort
lines.append("--- name-sort around #30-40 ---")
for i, r in enumerate(sc[29:40], start=30):
    lines.append(f"  #{i} {r[0]} {r[1]}")

LOG.write_text("\n".join(lines), encoding="utf-8")
print("ok")

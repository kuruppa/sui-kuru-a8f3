"""Split long audio into chunks, transcribe (optionally parallel), write QA Excel.

Saves each chunk to disk so a crash can be resumed.
"""
from __future__ import annotations

import json
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import av
import numpy as np
from faster_whisper import WhisperModel

sys.path.insert(0, str(Path(__file__).resolve().parent))
from transcribe_qa_to_excel import build_qa_rows, write_excel  # noqa: E402


def _format_time(seconds: float) -> str:
    total = int(seconds)
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def audio_duration_sec(path: Path) -> float:
    c = av.open(str(path))
    if c.duration is None:
        raise RuntimeError(f"Cannot read duration: {path}")
    return float(c.duration) / av.time_base


def load_audio_mono_16k(path: Path, start: float, end: float) -> np.ndarray:
    container = av.open(str(path))
    stream = container.streams.audio[0]
    resampler = av.audio.resampler.AudioResampler(format="flt", layout="mono", rate=16000)
    try:
        container.seek(int(max(0.0, start - 0.5) * 1_000_000))
    except Exception:
        pass

    samples: list[np.ndarray] = []
    for frame in container.decode(stream):
        pts = float(frame.pts * stream.time_base) if frame.pts is not None else None
        if pts is None:
            continue
        frame_end = pts + float(frame.samples) / float(frame.sample_rate)
        if frame_end < start:
            continue
        if pts >= end:
            break
        for out in resampler.resample(frame):
            arr = out.to_ndarray()
            if arr.ndim == 2:
                arr = arr[0]
            samples.append(np.asarray(arr, dtype=np.float32).reshape(-1))
    if not samples:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(samples)


def transcribe_chunk(args: tuple) -> dict:
    audio_path, model_path, chunk_id, start, end, chunk_json = args
    chunk_path = Path(chunk_json)
    if chunk_path.exists():
        data = json.loads(chunk_path.read_text(encoding="utf-8"))
        print(f"[chunk {chunk_id}] resume skip ({len(data.get('segments', []))} segs)", flush=True)
        return data

    print(f"[chunk {chunk_id}] start {_format_time(start)}-{_format_time(end)}", flush=True)
    audio = load_audio_mono_16k(Path(audio_path), start, end)
    if audio.size == 0:
        data = {"chunk_id": chunk_id, "start": start, "end": end, "segments": []}
        chunk_path.parent.mkdir(parents=True, exist_ok=True)
        chunk_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        print(f"[chunk {chunk_id}] empty audio", flush=True)
        return data

    model = WhisperModel(model_path, device="cpu", compute_type="int8")
    segments, _info = model.transcribe(
        audio,
        language="ja",
        vad_filter=True,
        beam_size=1,
        best_of=1,
        condition_on_previous_text=False,
    )
    out = []
    for seg in segments:
        text = (seg.text or "").strip()
        if not text:
            continue
        out.append(
            {
                "start": float(seg.start) + start,
                "end": float(seg.end) + start,
                "text": text,
            }
        )
        if len(out) % 5 == 0:
            print(
                f"[chunk {chunk_id}] {len(out)} segs, last={_format_time(out[-1]['end'])}",
                flush=True,
            )

    data = {"chunk_id": chunk_id, "start": start, "end": end, "segments": out}
    chunk_path.parent.mkdir(parents=True, exist_ok=True)
    chunk_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[chunk {chunk_id}] done ({len(out)} segments) -> {chunk_path}", flush=True)
    return data


def main() -> None:
    if len(sys.argv) < 3:
        print(
            "Usage: python transcribe_qa_parallel.py <audio> <output_xlsx> [model] [workers] [chunk_sec]",
            flush=True,
        )
        sys.exit(1)

    audio_path = Path(sys.argv[1])
    output_xlsx = Path(sys.argv[2])
    model_path = sys.argv[3] if len(sys.argv) >= 4 else str(Path("models") / "faster-whisper-small")
    workers = int(sys.argv[4]) if len(sys.argv) >= 5 else 2
    chunk_sec = float(sys.argv[5]) if len(sys.argv) >= 6 else 600.0

    if not audio_path.exists():
        raise FileNotFoundError(audio_path)

    duration = audio_duration_sec(audio_path)
    print(f"Audio: {audio_path}", flush=True)
    print(f"Duration: {_format_time(duration)} ({duration:.1f}s)", flush=True)
    print(f"Model: {model_path}", flush=True)
    print(f"Workers: {workers}, chunk_sec: {chunk_sec}", flush=True)

    chunk_dir = output_xlsx.parent / (output_xlsx.stem + "_chunks")
    chunk_dir.mkdir(parents=True, exist_ok=True)

    chunks = []
    i = 0
    t = 0.0
    while t < duration:
        e = min(t + chunk_sec, duration)
        chunk_json = str(chunk_dir / f"chunk_{i:02d}.json")
        chunks.append((str(audio_path), model_path, i, t, e, chunk_json))
        t = e
        i += 1
    print(f"Chunks: {len(chunks)} dir={chunk_dir}", flush=True)

    results = []
    if workers <= 1:
        for c in chunks:
            results.append(transcribe_chunk(c))
    else:
        with ProcessPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(transcribe_chunk, c): c[2] for c in chunks}
            for fut in as_completed(futs):
                results.append(fut.result())

    results.sort(key=lambda r: r["chunk_id"])
    segments: list[dict] = []
    for r in results:
        segments.extend(r["segments"])

    transcript_txt = output_xlsx.with_suffix(".txt")
    lines = [
        f"[{_format_time(s['start'])} - {_format_time(s['end'])}] {s['text']}" for s in segments
    ]
    transcript_txt.parent.mkdir(parents=True, exist_ok=True)
    transcript_txt.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    print(f"Transcript: {transcript_txt} ({len(segments)} segments)", flush=True)

    meta = output_xlsx.with_suffix(".segments.json")
    meta.write_text(json.dumps(segments, ensure_ascii=False, indent=2), encoding="utf-8")

    rows = build_qa_rows(segments)
    write_excel(rows, output_xlsx)
    print("Done.", flush=True)


if __name__ == "__main__":
    main()

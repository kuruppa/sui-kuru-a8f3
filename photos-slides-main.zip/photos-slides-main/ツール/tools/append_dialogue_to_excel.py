"""Parse speaker-labeled dialogue text and append QA rows to Excel."""
from __future__ import annotations

import re
import sys
from pathlib import Path

from openpyxl import Workbook, load_workbook

SPEAKER_RE = re.compile(
    r"^(?:はい[、。]?\s*)?"
    r"("
    r"(?:市長|副市長|委員長)"
    r"|(?:[一-龥ぁ-んァ-ン・]{1,24}"
    r"(?:委員|議員|課長|次長|部長|室長|主幹|所長|補佐|調整官))"
    r")"
    r"[。．]?$"
)

# longer titles like 「信号安全・安心推進課長」「協働推進部長」
SPEAKER_LONG_RE = re.compile(
    r"^(?:はい[、。]?\s*)?"
    r"([一-龥ぁ-んァ-ン・A-Za-z0-9]{2,40}"
    r"(?:推進課長|推進部長|管理課長|政策課長|政策調整官|事務局長|事務局次長|"
    r"課長補佐|室長|主幹|所長|次長|部長|課長|委員|議員))"
    r"[。．]?$"
)

QUESTIONER_SUFFIX = ("委員", "議員")
ANSWERER_SUFFIX = (
    "課長",
    "次長",
    "部長",
    "室長",
    "主幹",
    "所長",
    "補佐",
    "調整官",
    "市長",
    "副市長",
    "事務局長",
)
CHAIR_ONLY = {"委員長"}

SKIP_SHORT = re.compile(
    r"^(はい[。．]?|どうぞ。?|以上です。?|以上でございます。?|"
    r"\d+点です。?|\d+点。?|はい\d+点。?|関連。?|関連ですか。?|"
    r"よろしいですか。?|どちらに行かれますか。?)$"
)


def _role(name: str) -> str:
    if name in CHAIR_ONLY:
        return "chair"
    if name.endswith(QUESTIONER_SUFFIX):
        return "question"
    if any(name.endswith(s) for s in ANSWERER_SUFFIX):
        return "answer"
    # 「〜推進課長」など
    if "課長" in name or "部長" in name or "次長" in name:
        return "answer"
    return "other"


def _match_speaker(line: str) -> str | None:
    t = line.strip()
    if not t or len(t) > 45:
        return None
    m = SPEAKER_LONG_RE.match(t) or SPEAKER_RE.match(t)
    if not m:
        return None
    name = m.group(1).strip()
    name = re.sub(r"^はい[、。]?", "", name).strip()
    if name in {"交通安全対策", "窓口改革", "他の委員"}:
        return None
    if not name:
        return None
    return name


def parse_turns(text: str) -> list[dict]:
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    turns: list[dict] = []
    cur_name: str | None = None
    cur_role: str | None = None
    buf: list[str] = []

    def flush() -> None:
        nonlocal buf, cur_name, cur_role
        body = "".join(buf).strip()
        buf = []
        if not cur_name or not body:
            return
        if SKIP_SHORT.match(body) and len(body) < 20:
            return
        turns.append({"speaker": cur_name, "role": cur_role or "other", "text": body})

    for line in lines:
        if SKIP_SHORT.match(line):
            # keep "以上でございます。" inside speech if we have a buffer
            if cur_name and buf and line.startswith("以上"):
                buf.append(line)
            continue
        sp = _match_speaker(line)
        if sp:
            flush()
            cur_name = sp
            cur_role = _role(sp)
            continue
        if cur_name is None:
            # preamble / chair without explicit name
            cur_name = "委員長"
            cur_role = "chair"
        buf.append(line)

    flush()
    return turns


def turns_to_qa(turns: list[dict]) -> list[dict]:
    rows: list[dict] = []
    q_name = "質問者（仮称）"
    a_name = "答弁者（仮称）"
    cur_q: list[str] = []
    cur_a: list[str] = []

    def flush() -> None:
        nonlocal cur_q, cur_a
        q = "".join(cur_q).strip()
        a = "".join(cur_a).strip()
        cur_q, cur_a = [], []
        if not q and not a:
            return
        # skip pure chair procedural without Q/A substance
        if not q and a and len(a) < 30:
            return
        rows.append(
            {
                "questioner": q_name if q else "質問者（不明）",
                "question": q,
                "answerer": a_name if a else "答弁者（不明）",
                "answer": a,
            }
        )

    for t in turns:
        role = t["role"]
        name = t["speaker"]
        text = t["text"]
        if role == "chair":
            # procedural; if mentions 意見調整 / 確認, attach lightly to context
            if cur_a:
                flush()
            continue
        if role == "question":
            if cur_a:
                flush()
            q_name = name
            cur_q.append(text)
        elif role == "answer":
            a_name = name
            cur_a.append(text)
        else:
            # unknown: append to current open side
            if cur_a or (not cur_q):
                if not cur_a and not cur_q:
                    q_name = name
                    cur_q.append(text)
                else:
                    cur_a.append(text)
            else:
                cur_q.append(text)
    flush()
    return rows


def append_excel(xlsx: Path, rows: list[dict]) -> int:
    if xlsx.exists():
        wb = load_workbook(xlsx)
        ws = wb.active
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "QA"
        ws["A1"] = "質問者"
        ws["B1"] = "質問内容"
        ws["C1"] = "答弁者"
        ws["D1"] = "答弁内容"
    start = ws.max_row + 1
    # if file empty except header
    if ws.max_row == 1 and ws["A1"].value is None:
        ws["A1"] = "質問者"
        ws["B1"] = "質問内容"
        ws["C1"] = "答弁者"
        ws["D1"] = "答弁内容"
        start = 2
    r = start
    for row in rows:
        ws.cell(r, 1, row["questioner"])
        ws.cell(r, 2, row["question"])
        ws.cell(r, 3, row["answerer"])
        ws.cell(r, 4, row["answer"])
        r += 1
    wb.save(xlsx)
    return r - start


def append_txt(txt: Path, source: Path) -> None:
    extra = source.read_text(encoding="utf-8").strip() + "\n"
    existing = txt.read_text(encoding="utf-8") if txt.exists() else ""
    if not existing.endswith("\n"):
        existing += "\n"
    block = (
        "\n===== 追記（手入力・追加質疑） =====\n"
        + extra
        + "===== 追記ここまで =====\n"
    )
    if "===== 追記（手入力・追加質疑） =====" in existing:
        # replace previous append block
        pre = existing.split("===== 追記（手入力・追加質疑） =====")[0].rstrip() + "\n"
        txt.write_text(pre + block, encoding="utf-8")
    else:
        txt.write_text(existing + block, encoding="utf-8")


def main() -> None:
    src = Path(sys.argv[1]) if len(sys.argv) >= 2 else Path(
        r"C:\Users\newor\こいこい用\photos-slides\output\R8.6.16AM_追記_対話.txt"
    )
    xlsx = Path(sys.argv[2]) if len(sys.argv) >= 3 else Path(
        r"C:\Users\newor\こいこい用\R8.6.16AM_総務費質疑_QA.xlsx"
    )
    txt = Path(sys.argv[3]) if len(sys.argv) >= 4 else xlsx.with_suffix(".txt")

    text = src.read_text(encoding="utf-8")
    turns = parse_turns(text)
    print(f"turns={len(turns)}", flush=True)
    for t in turns[:8]:
        print(f"  [{t['role']}] {t['speaker']}: {t['text'][:50]}", flush=True)

    rows = turns_to_qa(turns)
    print(f"qa_rows={len(rows)}", flush=True)

    # If Excel already ends mid-topic, just append new rows
    n = append_excel(xlsx, rows)
    print(f"appended={n} -> {xlsx}", flush=True)

    append_txt(txt, src)
    print(f"txt_updated -> {txt}", flush=True)

    # mirror
    mirror = Path(__file__).resolve().parents[1] / "output" / xlsx.name
    if mirror.parent.exists():
        append_excel(mirror, rows) if False else None
        # rewrite mirror as full copy
        from shutil import copy2

        copy2(xlsx, mirror)
        print(f"mirrored -> {mirror}", flush=True)


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
import csv, io, os, zipfile
from pathlib import Path

out = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
log = Path(r"c:\Users\newor\こいこい用\photos-slides\tools\_emoto_find.txt")
lines = []

# search all batches
for p in sorted(out.glob("APbatch*.csv")):
    rows = list(csv.reader(io.StringIO(p.read_bytes().decode("cp932"))))
    for i, r in enumerate(rows):
        if "江本" in "".join(r) or "忠之" in "".join(r):
            lines.append(f"FOUND {p.name} line={i} {r}")

# ZIP index of 江本
with zipfile.ZipFile(out / "202512.zip") as z:
    n = next(x for x in z.namelist() if x.endswith(".csv"))
    rows = list(csv.reader(io.StringIO(z.read(n).decode("cp932"))))
header, data = rows[0], rows[1:]
for i, r in enumerate(data):
    if "江本" in "".join(r):
        lines.append(f"ZIP data index={i} (1-based person #{i+1}) {r}")

# Show APbatch01 first 3 with names
rows = list(csv.reader(io.StringIO((out/"APbatch01.csv").read_bytes().decode("cp932"))))
lines.append("--- current APbatch01 first 5 people ---")
for r in rows[1:6]:
    lines.append(str(r))

log.write_text("\n".join(lines), encoding="utf-8")
print("ok")

"""Rebuild QA Excel from corrected transcript .txt ([mm:ss - mm:ss] text)."""
from __future__ import annotations

import re
import sys
from pathlib import Path

# reuse QA pairing
sys.path.insert(0, str(Path(__file__).resolve().parent))
from rebuild_qa_excel import build_qa_rows, write_excel  # noqa: E402

LINE_RE = re.compile(
    r"^\[(\d{1,2}:\d{2}(?::\d{2})?)\s*-\s*(\d{1,2}:\d{2}(?::\d{2})?)\]\s*(.*)$"
)


def _to_seconds(ts: str) -> float:
    parts = [int(p) for p in ts.split(":")]
    if len(parts) == 2:
        m, s = parts
        return m * 60 + s
    h, m, s = parts
    return h * 3600 + m * 60 + s


def parse_transcript_txt(path: Path) -> list[dict]:
    segs: list[dict] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        m = LINE_RE.match(line)
        if not m:
            # continuation line without timestamp: append to previous
            if segs:
                segs[-1]["text"] = (segs[-1]["text"] + line).strip()
            continue
        text = m.group(3).strip()
        if not text:
            continue
        segs.append(
            {
                "start": _to_seconds(m.group(1)),
                "end": _to_seconds(m.group(2)),
                "text": text,
            }
        )
    return segs


def main() -> None:
    txt = Path(sys.argv[1]) if len(sys.argv) >= 2 else Path(
        r"C:\Users\newor\こいこい用\R8.6.16AM_総務費質疑_QA.txt"
    )
    xlsx = Path(sys.argv[2]) if len(sys.argv) >= 3 else txt.with_suffix(".xlsx")
    segs = parse_transcript_txt(txt)
    print(f"Parsed {len(segs)} segments from {txt}", flush=True)
    rows = build_qa_rows(segs)
    write_excel(rows, xlsx)
    # also mirror into photos-slides/output if present
    mirror = Path(__file__).resolve().parents[1] / "output" / xlsx.name
    if mirror.parent.exists():
        write_excel(rows, mirror)
    for r in rows[:5]:
        print("---")
        print("Q", r["questioner"], "|", (r["question"] or "")[:70])
        print("A", r["answerer"], "|", (r["answer"] or "")[:70])


if __name__ == "__main__":
    main()

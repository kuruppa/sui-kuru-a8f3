# Reduce workspace load: stop dev servers, archive HEIC, print size report
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

Write-Host "=== photos-slides lighten ===" -ForegroundColor Cyan

$stopped = 0
foreach ($port in 8765..8770) {
    $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if (-not $conn) { continue }
    $procId = $conn.OwningProcess
    $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$procId" -ErrorAction SilentlyContinue
    if ($proc.CommandLine -match "http\.server") {
        Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
        Write-Host "  Stopped http.server on port $port (PID $procId)"
        $stopped++
    }
}
if ($stopped -eq 0) {
    Write-Host "  No local http.server on ports 8765-8770"
}

$merged = Join-Path $Root "merged.jpg"
$archive = Join-Path $Root "_source_heic"
$heic = @(
    Get-ChildItem -Path $Root -File -Filter "*.heic" -ErrorAction SilentlyContinue
    Get-ChildItem -Path $Root -File -Filter "*.HEIC" -ErrorAction SilentlyContinue
) | Sort-Object Name -Unique
if ((Test-Path $merged) -and $heic.Count -gt 0) {
    New-Item -ItemType Directory -Path $archive -Force | Out-Null
    $moved = 0
    $bytes = 0L
    foreach ($f in $heic) {
        $dest = Join-Path $archive $f.Name
        if (Test-Path $dest) { continue }
        $bytes += $f.Length
        Move-Item -LiteralPath $f.FullName -Destination $dest
        $moved++
    }
    $mb = [math]::Round($bytes / 1MB, 1)
    Write-Host "  Archived $moved HEIC files to _source_heic/ (~$mb MB)"
} elseif ($heic.Count -gt 0) {
    Write-Host "  $($heic.Count) HEIC in root. Run merge_heic.py then run this script again."
}

$files = Get-ChildItem -Recurse -File -ErrorAction SilentlyContinue
$totalMb = [math]::Round(($files | Measure-Object Length -Sum).Sum / 1MB, 1)
Write-Host ""
Write-Host "  Total: $($files.Count) files / $totalMb MB"
$files | Sort-Object Length -Descending | Select-Object -First 5 | ForEach-Object {
    $rel = $_.FullName.Replace($Root + [IO.Path]::DirectorySeparatorChar, "")
    Write-Host ("  {0,6:N1} MB  {1}" -f ($_.Length / 1MB), $rel)
}

Write-Host ""
Write-Host "Done. Reload Cursor window for .cursorignore to apply." -ForegroundColor Green

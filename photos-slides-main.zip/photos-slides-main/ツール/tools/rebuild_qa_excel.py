"""Rebuild QA Excel from existing segments.json with better pairing."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from openpyxl import Workbook


# 「委員会」「委員の」などは除外し、氏名+委員/議員を拾う
QUESTIONER_RE = re.compile(
    r"(?:はい[、,]?\s*)?"
    r"([一-龥ぁ-んァ-ン]{2,6}(?:委員|議員))"
    r"(?!会|の|に|を|が|は|と|で|へ|も|から|まで)"
)
ANSWERER_RE = re.compile(
    r"(?:はい[、,]?\s*)?"
    r"((?:市長|副市長|教育長|議長|委員長)"
    r"|(?:[一-龥ぁ-んァ-ン]{2,8}(?:部長|課長|局長|室長|次長|参事|担当課長|会計管理者)))"
)
BAD_QUESTIONER = {
    "予算委員",
    "特別委員",
    "常任委員",
    "その委員",
    "最終的に予算委員",
    "議会委員",
    "選挙管理委員",
}

QUESTION_HINTS = (
    "質問",
    "伺",
    "お聞き",
    "聞きたい",
    "求め",
    "要望",
    "でしょうか",
    "ですか",
    "どうか",
    "どうな",
    "どのよう",
    "何を",
    "なぜ",
    "教えて",
)
ANSWER_HINTS = (
    "答弁",
    "お答え",
    "申し上げ",
    "ご説明",
    "説明いた",
    "説明させ",
    "でございます",
    "計上して",
    "お願いいた",
    "承知",
    "考えており",
    "対応して",
    "実施して",
    "予定して",
    "認識して",
)
CHAIR_HINTS = (
    # 参照用。本文スキップには使わない（修正済み全文をExcelへ反映するため）
    "では次に",
    "次の質疑",
    "他にございませんか",
    "休憩",
    "再開",
    "ご起立",
    "写真撮影",
)


def _join(parts: list[str]) -> str:
    out: list[str] = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        if out and not out[-1].endswith(("。", "！", "？", "」", "』", "、")):
            out.append(p)
        else:
            out.append(p)
    # Prefer contiguous Japanese without extra spaces
    text = "".join(out)
    text = re.sub(r"[ \t]+", "", text)
    return text


def _role_and_names(text: str, last_role: str | None) -> tuple[str, str | None, str | None]:
    """Return (role, questioner_name|None, answerer_name|None)."""
    q = QUESTIONER_RE.search(text)
    a = ANSWERER_RE.search(text)

    # Chair calling a member / official at turn start
    if q and (text.startswith("はい") or "委員" in text[:20] or "議員" in text[:20]):
        # If also looks like answer content, prefer answer only when answerer title is called
        if a and any(h in text for h in ("部長", "市長", "課長", "局長", "教育長")) and not any(
            h in text for h in QUESTION_HINTS
        ):
            return "answer", q.group(1), a.group(1)
        return "question", q.group(1), a.group(1) if a else None

    if a and (text.startswith("はい") or len(text) < 40):
        # Short recognition of answerer by chair
        return "answer", q.group(1) if q else None, a.group(1)

    has_q = any(h in text for h in QUESTION_HINTS)
    has_a = any(h in text for h in ANSWER_HINTS)

    if has_a and not has_q:
        return "answer", q.group(1) if q else None, a.group(1) if a else None
    if has_q and not has_a:
        return "question", q.group(1) if q else None, a.group(1) if a else None

    if a and any(x in text for x in ("部長", "市長", "課長", "局長")) and "委員" not in text:
        return "answer", None, a.group(1)
    if q and "委員" in text and any(h in text for h in ("質問", "伺", "お聞き", "ですか", "でしょうか")):
        return "question", q.group(1), None

    # Continuity default
    if last_role is None:
        return "question", q.group(1) if q else None, a.group(1) if a else None
    return last_role, q.group(1) if q else None, a.group(1) if a else None


def build_qa_rows(segments: list[dict]) -> list[dict]:
    questioner = "質問者（仮称）"
    answerer = "答弁者（仮称）"
    rows: list[dict] = []
    cur_q: list[str] = []
    cur_a: list[str] = []
    last_role: str | None = None
    q_name_for_row = questioner
    a_name_for_row = answerer

    def flush() -> None:
        nonlocal cur_q, cur_a, q_name_for_row, a_name_for_row
        q_text = _join(cur_q)
        a_text = _join(cur_a)
        if not q_text and not a_text:
            return
        # Skip pure procedural chair noise without substance
        if not q_text and a_text and len(a_text) < 20:
            cur_q, cur_a = [], []
            return
        rows.append(
            {
                "questioner": q_name_for_row if q_text else "質問者（不明）",
                "question": q_text,
                "answerer": a_name_for_row if a_text else "答弁者（不明）",
                "answer": a_text,
            }
        )
        cur_q, cur_a = [], []

    for seg in segments:
        text = (seg.get("text") or "").strip()
        if not text:
            continue

        role, qn, an = _role_and_names(text, last_role)
        if qn and qn not in BAD_QUESTIONER and not qn.endswith("委員会"):
            questioner = qn
        if an:
            answerer = an

        if role == "question":
            # New question after an answer => new row
            if cur_a:
                flush()
                q_name_for_row = questioner
                a_name_for_row = answerer
            elif not cur_q:
                q_name_for_row = questioner
                a_name_for_row = answerer
            else:
                # keep names unless a clearer questioner appeared
                if qn:
                    q_name_for_row = questioner
            cur_q.append(text)
            last_role = "question"
        else:
            if not cur_q and not cur_a:
                q_name_for_row = questioner
                a_name_for_row = answerer
            if an:
                a_name_for_row = answerer
            cur_a.append(text)
            last_role = "answer"

    flush()

    # Merge tiny orphan rows into neighbors where useful
    merged: list[dict] = []
    for r in rows:
        if (
            merged
            and not r["question"]
            and r["answer"]
            and merged[-1]["answer"]
            and merged[-1]["answerer"] == r["answerer"]
        ):
            merged[-1]["answer"] += r["answer"]
            continue
        if (
            merged
            and r["question"]
            and not r["answer"]
            and not merged[-1]["answer"]
            and merged[-1]["questioner"] == r["questioner"]
        ):
            merged[-1]["question"] += r["question"]
            continue
        merged.append(r)
    return merged


def write_excel(rows: list[dict], output_xlsx: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "QA"
    ws["A1"] = "質問者"
    ws["B1"] = "質問内容"
    ws["C1"] = "答弁者"
    ws["D1"] = "答弁内容"
    for i, row in enumerate(rows, start=2):
        ws.cell(i, 1, row["questioner"])
        ws.cell(i, 2, row["question"])
        ws.cell(i, 3, row["answerer"])
        ws.cell(i, 4, row["answer"])
    output_xlsx.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(output_xlsx))
    print(f"Wrote: {output_xlsx} ({len(rows)} rows)", flush=True)


def main() -> None:
    seg_path = Path(sys.argv[1]) if len(sys.argv) >= 2 else next(Path("output").glob("R8.6.16AM*.segments.json"))
    if len(sys.argv) >= 3:
        out_path = Path(sys.argv[2])
    else:
        # R8...._QA.segments.json -> R8...._QA.xlsx
        name = seg_path.name
        if name.endswith(".segments.json"):
            out_path = seg_path.with_name(name[: -len(".segments.json")] + ".xlsx")
        else:
            out_path = seg_path.with_suffix(".xlsx")
    segs = json.loads(seg_path.read_text(encoding="utf-8"))
    rows = build_qa_rows(segs)
    write_excel(rows, out_path)
    for r in rows[:5]:
        print("---")
        print("A", r["questioner"], "|", r["question"][:60])
        print("C", r["answerer"], "|", r["answer"][:60])


if __name__ == "__main__":
    main()

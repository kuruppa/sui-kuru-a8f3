# -*- coding: utf-8 -*-
import csv, io, os
from pathlib import Path

EXPORT = Path(r"c:\Users\newor\Downloads\userdl_2026-07-15_18_18_25.csv")
BATCH_DIR = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
LOG = Path(r"c:\Users\newor\こいこい用\photos-slides\tools\_sent_list_check.txt")


def read_csv(path: Path):
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp932", "utf-8"):
        try:
            return list(csv.reader(io.StringIO(raw.decode(enc))))
        except UnicodeDecodeError:
            continue
    return list(csv.reader(io.StringIO(raw.decode("cp932", errors="replace"))))


def email_map(rows, has_header=True):
    data = rows[1:] if has_header else rows
    m = {}
    for r in data:
        for c in r:
            if "@" in c:
                m[c.strip().lower()] = r
                break
    return m


exp = email_map(read_csv(EXPORT))
b02 = email_map(read_csv(BATCH_DIR / "APbatch02.csv"))
b10 = email_map(read_csv(BATCH_DIR / "APbatch10.csv"))
b09 = email_map(read_csv(BATCH_DIR / "APbatch09.csv"))

sent = set(exp)
u = set(b02) | set(b10)
missing = sorted(u - sent)
extra = sorted(sent - u)

lines = []
lines.append(f"送付済みエクスポート: {len(sent)} 件")
lines.append(f"想定セット APbatch10(94)+APbatch02(95) = {len(u)} 件")
lines.append(f"重なり: {len(u & sent)} 件")
lines.append("")
lines.append("【漏れ】想定バッチにあるがエクスポートに無い（未取込 or 配信停止/削除）")
for e in missing:
    src = "02" if e in b02 else "10"
    r = b02.get(e) or b10.get(e)
    lines.append(f"  [{src}] {r[0]} {r[1]} <{e}>")

lines.append("")
lines.append("【想定外】エクスポートにあるが batch10+02 に無い")
for e in extra:
    r = exp[e]
    # name columns in export: メール, 姓, 名?
    in09 = e in b09
    lines.append(f"  {r}  (in APbatch09? {in09})")

lines.append("")
lines.append("結論まとめ:")
lines.append(f"- ほぼ batch10 + batch02（{len(u & sent)}/{len(u)}）")
lines.append(f"- 漏れ候補 {len(missing)} 件")
lines.append(f"- 境界の余分 {len(extra)} 件（うち batch09 由来の可能性あり）")

LOG.write_text("\n".join(lines), encoding="utf-8")
print("ok")

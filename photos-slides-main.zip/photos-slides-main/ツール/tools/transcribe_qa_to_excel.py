from __future__ import annotations

import re
import sys
from pathlib import Path

from faster_whisper import WhisperModel
from openpyxl import Workbook


QUESTION_KEYWORDS = [
    # 典型的な質問・質疑の言い回し
    "質問",
    "伺",
    "聞き",
    "求め",
    "要望",
    "どう",
    "どの",
    "何を",
    "でしょう",
    "でしょうか",
    "でしょうか。",
    "質問します",
    "質疑",
]

ANSWER_KEYWORDS = [
    # 典型的な答弁・回答の言い回し
    "答弁",
    "お答え",
    "申し上げ",
    "承知",
    "まず",
    "認識",
    "対応",
    "検討",
    "進め",
    "実施",
    "お示し",
    "結論",
]


def _extract_speaker_name(text: str, role: str) -> str | None:
    """
    文字起こし結果から「氏名+役職」っぽい部分を雑に抽出します。
    うまく取れない場合は None を返し、呼び出し側で仮称を使います。
    """

    t = re.sub(r"\s+", " ", text).strip()

    if role == "question":
        # 例: 「佐藤議員」「山田市議」「鈴木委員」
        m = re.search(r"([一-龠ぁ-んァ-ンA-Za-z0-9_]+(?:議員|市議|町議|村議|委員))", t)
        return m.group(1) if m else None

    # role == "answer"
    # 例: 「市長」「教育長」「部長」「課長」「局長」「担当課長」
    m = re.search(
        r"([一-龠ぁ-んァ-ンA-Za-z0-9_]+(?:市長|教育長|部長|局長|課長|担当課長|局|部|課))",
        t,
    )
    return m.group(1) if m else None


def _classify_role(text: str) -> str | None:
    t = text.replace(" ", "")
    if any(k in t for k in ANSWER_KEYWORDS):
        return "answer"
    if any(k in t for k in QUESTION_KEYWORDS):
        return "question"
    return None


def _iter_transcript_segments(audio_path: Path, model_path: str, transcript_txt: Path | None = None) -> list[dict]:
    """
    faster-whisperのsegmentsを、role組み立て用に構造化して返します。
    """

    print(f"[1/4] Loading model: {model_path}", flush=True)
    model = WhisperModel(model_path, device="cpu", compute_type="int8")
    print("[2/4] Model loaded. Starting transcription...", flush=True)

    segments, info = model.transcribe(
        str(audio_path),
        language="ja",
        vad_filter=True,
        beam_size=1,
        best_of=1,
        condition_on_previous_text=False,
        without_timestamps=False,
    )
    print(f"[3/4] Language: {info.language} (prob={info.language_probability:.2f})", flush=True)
    print("[3/4] Decoding segments (this can take a while)...", flush=True)

    out: list[dict] = []
    lines_for_txt: list[str] = []
    for i, seg in enumerate(segments, start=1):
        text = (seg.text or "").strip()
        if not text:
            continue
        item = {
            "start": float(seg.start),
            "end": float(seg.end),
            "text": text,
        }
        out.append(item)
        line = f"[{_format_time(item['start'])} - {_format_time(item['end'])}] {text}"
        lines_for_txt.append(line)
        if len(out) % 5 == 0:
            print(f"  ... {len(out)} segments, last={_format_time(item['end'])}", flush=True)
        # 途中経過を随時保存
        if transcript_txt is not None and len(out) % 10 == 0:
            transcript_txt.parent.mkdir(parents=True, exist_ok=True)
            transcript_txt.write_text(
                "\n".join(lines_for_txt) + "\n",
                encoding="utf-8",
            )

    if transcript_txt is not None:
        transcript_txt.parent.mkdir(parents=True, exist_ok=True)
        transcript_txt.write_text("\n".join(lines_for_txt) + ("\n" if lines_for_txt else ""), encoding="utf-8")
        print(f"Transcript saved: {transcript_txt}", flush=True)

    print(f"[4/4] Decoded {len(out)} segments", flush=True)
    return out


def _format_time(seconds: float) -> str:
    total = int(seconds)
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def _join_lines(lines: list[str]) -> str:
    # Excelセルで読みやすいようにスペース区切り
    return "".join([l if l.endswith(("。", "！", "？", "」", "』")) else (l + " ") for l in lines]).strip()


def build_qa_rows(segments: list[dict]) -> list[dict]:
    """
    ダイアリゼーション(話者分離)は未実施なので、
    文字起こしセグメントの内容/順序から「質問→答弁」のペアを作ります。
    """

    questioner_name = "質問者（仮称）"
    answerer_name = "答弁者（仮称）"

    rows: list[dict] = []
    cur_q: list[str] = []
    cur_a: list[str] = []

    last_role: str | None = None

    def flush() -> None:
        nonlocal cur_q, cur_a, rows
        if not cur_q and not cur_a:
            return
        q_text = _join_lines(cur_q) if cur_q else ""
        a_text = _join_lines(cur_a) if cur_a else ""
        rows.append(
            {
                "questioner": questioner_name if q_text else "質問者（不明）",
                "question": q_text,
                "answerer": answerer_name if a_text else "答弁者（不明）",
                "answer": a_text,
            }
        )
        cur_q = []
        cur_a = []

    for seg in segments:
        text = seg["text"]
        seg_role = _classify_role(text)

        if seg_role is None:
            # ルールが取れない場合は「交互」ベースで推定（最初は質問側）
            seg_role = "question" if last_role != "question" else "answer"

        if seg_role == "question":
            # 既に答弁を溜めていたら質問が切り替わったとみなして確定
            if cur_a:
                flush()

            extracted = _extract_speaker_name(text, "question")
            if extracted:
                questioner_name = extracted

            cur_q.append(text)
            last_role = "question"
        else:  # seg_role == "answer"
            extracted = _extract_speaker_name(text, "answer")
            if extracted:
                answerer_name = extracted

            cur_a.append(text)
            last_role = "answer"

    flush()
    return rows


def write_excel(rows: list[dict], output_xlsx: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "QA"

    # ヘッダ
    ws["A1"] = "質問者"
    ws["B1"] = "質問内容"
    ws["C1"] = "答弁者"
    ws["D1"] = "答弁内容"

    r = 2
    for row in rows:
        ws.cell(row=r, column=1, value=row["questioner"])
        ws.cell(row=r, column=2, value=row["question"])
        ws.cell(row=r, column=3, value=row["answerer"])
        ws.cell(row=r, column=4, value=row["answer"])
        r += 1

    output_xlsx.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(output_xlsx))
    print(f"Wrote: {output_xlsx} ({len(rows)} rows)", flush=True)


def main() -> None:
    if len(sys.argv) < 3:
        print("Usage: python transcribe_qa_to_excel.py <audio_path> <output_xlsx> [model_path]", flush=True)
        sys.exit(1)

    audio_path = Path(sys.argv[1])
    output_xlsx = Path(sys.argv[2])

    if len(sys.argv) >= 4:
        model_path = sys.argv[3]
    else:
        # リポジトリ同梱のローカルモデルがあればそれを優先
        local_model = Path("models") / "faster-whisper-medium"
        model_path = str(local_model) if local_model.exists() else "medium"

    if not audio_path.exists():
        raise FileNotFoundError(f"Audio not found: {audio_path}")

    print(f"Audio: {audio_path}", flush=True)
    print(f"Output: {output_xlsx}", flush=True)
    transcript_txt = output_xlsx.with_suffix(".txt")
    segments = _iter_transcript_segments(
        audio_path,
        model_path=model_path,
        transcript_txt=transcript_txt,
    )
    print(f"Segments: {len(segments)}", flush=True)

    # セグメントの開始/終了を見た目で追えるように（ログのみ）
    # role推定に悪影響は与えないので、必要ならここを見て調整してください。
    for s in segments[:5]:
        print(f" - [{_format_time(s['start'])}~{_format_time(s['end'])}] {s['text'][:80]}", flush=True)
    if len(segments) > 5:
        print(f" ... ({len(segments) - 5} more)", flush=True)

    rows = build_qa_rows(segments)
    write_excel(rows, output_xlsx)


if __name__ == "__main__":
    main()


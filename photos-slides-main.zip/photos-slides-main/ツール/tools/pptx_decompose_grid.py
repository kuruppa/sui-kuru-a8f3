"""
Decompose single-image slides into a rectangular grid of picture shapes.

Unlike contour-based splitting, grid cells tile the full slide (no gaps), so the
recomposed slide looks identical to the original while each region stays movable.

Requires: pip install python-pptx opencv-python-headless numpy
"""
from __future__ import annotations

import argparse
import io
import sys
from pathlib import Path

import cv2
import numpy as np
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE


def _find_largest_picture(slide):
    pics = [s for s in slide.shapes if s.shape_type == MSO_SHAPE_TYPE.PICTURE]
    if not pics:
        return None
    return max(pics, key=lambda s: int(s.width) * int(s.height))


def _major_splits(
    projection: np.ndarray,
    length: int,
    *,
    max_internal: int,
    min_gap: int,
    margin: int,
) -> list[int]:
    """Return sorted split positions including 0 and length."""
    sm = np.convolve(projection.astype(np.float64), np.ones(31) / 31, mode="same")
    mins: list[tuple[int, float]] = []
    for i in range(margin, length - margin):
        if sm[i] <= sm[i - 1] and sm[i] <= sm[i + 1]:
            mins.append((i, float(sm[i])))
    mins.sort(key=lambda t: t[1])
    chosen = [0, length]
    for i, _v in mins:
        if len(chosen) >= max_internal + 2:
            break
        if all(abs(i - c) >= min_gap for c in chosen):
            chosen.append(i)
    return sorted(chosen)


def grid_cells_for_image(
    img_bgr: np.ndarray,
    *,
    max_row_splits: int,
    max_col_splits: int,
    row_min_gap: int,
    col_min_gap: int,
) -> list[tuple[int, int, int, int]]:
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape[:2]
    content = (255 - gray).astype(np.float32)
    y_splits = _major_splits(
        content.sum(axis=1),
        h,
        max_internal=max_row_splits,
        min_gap=row_min_gap,
        margin=30,
    )
    x_splits = _major_splits(
        content.sum(axis=0),
        w,
        max_internal=max_col_splits,
        min_gap=col_min_gap,
        margin=30,
    )
    cells: list[tuple[int, int, int, int]] = []
    for yi in range(len(y_splits) - 1):
        y0, y1 = y_splits[yi], y_splits[yi + 1]
        for xi in range(len(x_splits) - 1):
            x0, x1 = x_splits[xi], x_splits[xi + 1]
            cells.append((x0, y0, x1 - x0, y1 - y0))
    return cells


def _pixel_rect_to_placement(
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    *,
    pic_left: int,
    pic_top: int,
    pic_w: int,
    pic_h: int,
    img_w: int,
    img_h: int,
) -> tuple[int, int, int, int]:
    left = pic_left + int(round(x0 * pic_w / img_w))
    top = pic_top + int(round(y0 * pic_h / img_h))
    width = max(1, int(round((x1 - x0) * pic_w / img_w)))
    height = max(1, int(round((y1 - y0) * pic_h / img_h)))
    return left, top, width, height


def decompose_pptx_grid(
    src: Path,
    dst: Path,
    *,
    max_row_splits: int,
    max_col_splits: int,
    row_min_gap: int,
    col_min_gap: int,
) -> None:
    prs = Presentation(str(src))
    for si, slide in enumerate(prs.slides, start=1):
        pic = _find_largest_picture(slide)
        if pic is None:
            print(f"[slide {si}] 画像なし — スキップ", file=sys.stderr)
            continue

        blob = pic.image.blob
        img_bgr = cv2.imdecode(np.frombuffer(blob, dtype=np.uint8), cv2.IMREAD_COLOR)
        if img_bgr is None:
            print(f"[slide {si}] 画像デコード失敗 — スキップ", file=sys.stderr)
            continue

        ih, iw = img_bgr.shape[:2]
        cells = grid_cells_for_image(
            img_bgr,
            max_row_splits=max_row_splits,
            max_col_splits=max_col_splits,
            row_min_gap=row_min_gap,
            col_min_gap=col_min_gap,
        )

        pic_left = int(pic.left)
        pic_top = int(pic.top)
        pic_w = int(pic.width)
        pic_h = int(pic.height)
        pic._element.getparent().remove(pic._element)

        for x, y, cw, ch in cells:
            crop = img_bgr[y : y + ch, x : x + cw]
            ok, enc = cv2.imencode(".png", crop)
            if not ok:
                continue
            stream = io.BytesIO(enc.tobytes())
            left, top, width, height = _pixel_rect_to_placement(
                x,
                y,
                x + cw,
                y + ch,
                pic_left=pic_left,
                pic_top=pic_top,
                pic_w=pic_w,
                pic_h=pic_h,
                img_w=iw,
                img_h=ih,
            )
            slide.shapes.add_picture(stream, left, top, width=width, height=height)

        print(f"[slide {si}] {len(cells)} 領域に分割（全面タイル）", file=sys.stderr)

    prs.save(str(dst))


def main() -> None:
    ap = argparse.ArgumentParser(
        description="一枚画像スライドを矩形グリッドに分解（隙間なく全面をカバー）"
    )
    ap.add_argument("pptx_path", type=Path)
    ap.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="出力pptx（省略時は *_grid.pptx）",
    )
    ap.add_argument("--max-row-splits", type=int, default=2, help="水平方向の最大分割数")
    ap.add_argument("--max-col-splits", type=int, default=1, help="垂直方向の最大分割数")
    ap.add_argument("--row-min-gap", type=int, default=100)
    ap.add_argument("--col-min-gap", type=int, default=200)
    args = ap.parse_args()

    src = args.pptx_path.resolve()
    dst = args.output.resolve() if args.output else src.with_name(f"{src.stem}_grid{src.suffix}")

    decompose_pptx_grid(
        src,
        dst,
        max_row_splits=args.max_row_splits,
        max_col_splits=args.max_col_splits,
        row_min_gap=args.row_min_gap,
        col_min_gap=args.col_min_gap,
    )
    print(dst)


if __name__ == "__main__":
    main()

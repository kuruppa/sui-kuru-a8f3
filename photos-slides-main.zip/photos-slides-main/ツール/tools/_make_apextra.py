# -*- coding: utf-8 -*-
import csv
import io
import os
from pathlib import Path

OUT = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
LOG = Path(__file__).with_name("_cover_check.txt")
TARGETS = ["mokurennoyouni@gmail.com", "yupe220126@gmail.com"]


def read(path: Path):
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp932", "utf-8"):
        try:
            return list(csv.reader(io.StringIO(raw.decode(enc))))
        except UnicodeDecodeError:
            continue
    return list(csv.reader(io.StringIO(raw.decode("cp932", errors="replace"))))


def main() -> None:
    lines: list[str] = []
    for email in TARGETS:
        found = []
        for p in sorted(OUT.glob("APbatch*.csv")):
            for i, r in enumerate(read(p)):
                if any(email.lower() == c.strip().lower() for c in r):
                    found.append(f"{p.name}#{i}")
        lines.append(f"{email}: {found or ['NONE']}")

    rows02 = read(OUT / "APbatch02.csv")
    header = rows02[0]
    extra = []
    for r in rows02[1:]:
        for c in r:
            if c.strip().lower() in TARGETS:
                extra.append(r)
                break

    out = OUT / "APextra.csv"
    with out.open("w", encoding="cp932", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerows([header] + extra)

    vr = read(out)
    lines.append(f"wrote {out.name} count={len(vr) - 1}")
    for r in vr:
        lines.append(str(r))
    lines.append("")
    lines.append("Answer: NO - these 2 appear ONLY in APbatch02, not in 03-10.")
    lines.append("Import APextra.csv in a small scenario (or into an existing greeting scenario) once.")

    LOG.write_text("\n".join(lines), encoding="utf-8")
    print("ok")


if __name__ == "__main__":
    main()

"""
Extract non-background graphic regions (icons, charts, tables as raster) from each
slide image inside a .pptx.

Uses local contrast (absolute difference from a heavy Gaussian-blurred plate) so
slow background gradients are suppressed. Large blobs are re-segmented recursively
with a stricter threshold inside the ROI.

Output: slide_XX/crop_YY.png + manifest.json with pixel bboxes (relative to slide image).

Limitations: merged graphics may stay merged; fine lines may fragment — tuning may be needed.
"""
from __future__ import annotations

import argparse
import io
import json
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

import cv2
import numpy as np


@dataclass
class CropRecord:
    slide_index: int
    crop_index: int
    file: str
    x: int
    y: int
    width: int
    height: int
    area_px: float
    percentile_used: float


def _list_slide_media(z: zipfile.ZipFile) -> list[tuple[int, str]]:
    out: list[tuple[int, str]] = []
    for name in z.namelist():
        n = name.replace("\\", "/")
        if not n.startswith("ppt/media/image"):
            continue
        stem = Path(n).stem
        if not stem.startswith("image"):
            continue
        ext = Path(n).suffix.lower()
        if ext not in (".png", ".jpeg", ".jpg", ".gif", ".bmp", ".tif", ".tiff"):
            continue
        try:
            idx = int(stem.replace("image", ""))
        except ValueError:
            continue
        out.append((idx, n))
    out.sort(key=lambda t: t[0])
    return out


def _segment_once(
    gray: np.ndarray,
    *,
    percentile: float,
    blur_ksize: int,
    close_ksize: int,
    min_area: float,
    max_area: float,
) -> list[tuple[int, int, int, int, float]]:
    """Return list of (x, y, w, h, area) in coordinates of `gray`."""
    k = blur_ksize | 1  # odd
    bg = cv2.GaussianBlur(gray, (k, k), 0)
    diff = cv2.absdiff(gray, bg).astype(np.float32)
    thr = float(np.percentile(diff, percentile))
    mask = ((diff > thr).astype(np.uint8)) * 255
    ck = max(3, close_ksize | 1)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ck, ck))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w = gray.shape[:2]
    img_area = float(h * w)
    out: list[tuple[int, int, int, int, float]] = []
    for c in contours:
        a = float(cv2.contourArea(c))
        if a < min_area or a > max_area:
            continue
        x, y, cw, ch = cv2.boundingRect(c)
        out.append((x, y, cw, ch, a))
    return out


def _segment_recursive(
    gray: np.ndarray,
    ox: int,
    oy: int,
    *,
    percentile: float,
    blur_ksize: int,
    close_ksize: int,
    min_area: float,
    max_area_ratio: float,
    split_area_ratio: float,
    max_depth: int,
    depth: int,
) -> list[tuple[int, int, int, int, float, float]]:
    """
    Return tuples (x,y,w,h,area,perc) in **global** coordinates (offset ox,oy applied).
    """
    h, w = gray.shape[:2]
    img_area = float(h * w)
    max_area = max_area_ratio * img_area

    blobs = _segment_once(
        gray,
        percentile=percentile,
        blur_ksize=blur_ksize,
        close_ksize=close_ksize,
        min_area=min_area,
        max_area=max_area,
    )
    results: list[tuple[int, int, int, int, float, float]] = []

    for x, y, cw, ch, a in blobs:
        gx, gy = ox + x, oy + y
        if a >= split_area_ratio * img_area and depth < max_depth:
            sub_gray = gray[y : y + ch, x : x + cw]
            if sub_gray.size == 0:
                continue
            sub_p = min(percentile + 3.0, 98.5)
            inner = _segment_recursive(
                sub_gray,
                gx,
                gy,
                percentile=sub_p,
                blur_ksize=max(15, (blur_ksize // 3) | 1),
                close_ksize=max(3, close_ksize - 2),
                min_area=max(200.0, min_area * 0.75),
                max_area_ratio=max_area_ratio,
                split_area_ratio=split_area_ratio,
                max_depth=max_depth,
                depth=depth + 1,
            )
            if len(inner) >= 2:
                results.extend(inner)
                continue
        results.append((gx, gy, cw, ch, a, percentile))

    # De-duplicate heavily overlapping boxes (keep larger)
    results.sort(key=lambda t: t[4], reverse=True)
    kept: list[tuple[int, int, int, int, float, float]] = []
    for box in results:
        x, y, cw, ch, a, p = box
        xa, ya = x + cw, y + ch
        bad = False
        for k in kept:
            kx, ky, kw, kh, _, _ = k
            inter_x0 = max(x, kx)
            inter_y0 = max(y, ky)
            inter_x1 = min(xa, kx + kw)
            inter_y1 = min(ya, ky + kh)
            inter = max(0, inter_x1 - inter_x0) * max(0, inter_y1 - inter_y0)
            if inter > 0.6 * min(a, k[4]):
                bad = True
                break
        if not bad:
            kept.append(box)
    return kept


def segment_slide_bgr_to_boxes(
    img_bgr: np.ndarray,
    *,
    percentile: float = 90.0,
    min_area_ratio: float = 0.0008,
    max_area_ratio: float = 0.7,
    split_area_ratio: float = 0.22,
    blur_ksize: int = 51,
    close_ksize: int = 7,
    max_depth: int = 3,
) -> list[tuple[int, int, int, int, float, float]]:
    """
    Segment a slide-sized BGR image into graphic regions.
    Returns sorted boxes: (x, y, w, h, area_px, percentile_used).
    """
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape[:2]
    img_area = float(h * w)
    min_area = min_area_ratio * img_area
    boxes = _segment_recursive(
        gray,
        0,
        0,
        percentile=percentile,
        blur_ksize=blur_ksize,
        close_ksize=close_ksize,
        min_area=min_area,
        max_area_ratio=max_area_ratio,
        split_area_ratio=split_area_ratio,
        max_depth=max_depth,
        depth=0,
    )
    boxes.sort(key=lambda t: (t[1] // max(1, h // 200), t[0]))
    return boxes


def extract_from_pptx(
    pptx_path: Path,
    out_dir: Path,
    *,
    percentile: float,
    pad_px: int,
    min_area_ratio: float,
    max_area_ratio: float,
    split_area_ratio: float,
    blur_ksize: int,
    close_ksize: int,
    max_depth: int,
) -> None:
    pptx_path = pptx_path.resolve()
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    manifest: dict = {
        "source_pptx": str(pptx_path),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "params": {
            "percentile": percentile,
            "pad_px": pad_px,
            "min_area_ratio": min_area_ratio,
            "max_area_ratio": max_area_ratio,
            "split_area_ratio": split_area_ratio,
            "blur_ksize": blur_ksize,
            "close_ksize": close_ksize,
            "max_depth": max_depth,
        },
        "slides": [],
    }

    with zipfile.ZipFile(pptx_path, "r") as zf:
        media = _list_slide_media(zf)
        if not media:
            raise SystemExit("ppt/media に画像が見つかりません。")

        for slide_idx, media_path in media:
            raw = zf.read(media_path)
            img = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_COLOR)
            if img is None:
                continue
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape[:2]
            img_area = float(h * w)
            min_area = min_area_ratio * img_area

            boxes = _segment_recursive(
                gray,
                0,
                0,
                percentile=percentile,
                blur_ksize=blur_ksize,
                close_ksize=close_ksize,
                min_area=min_area,
                max_area_ratio=max_area_ratio,
                split_area_ratio=split_area_ratio,
                max_depth=max_depth,
                depth=0,
            )
            boxes.sort(key=lambda t: (t[1] // max(1, h // 200), t[0]))

            slide_dir = out_dir / f"slide_{slide_idx:02d}"
            slide_dir.mkdir(parents=True, exist_ok=True)

            slide_entry = {"slide_index": slide_idx, "crops": []}

            for ci, (x, y, cw, ch, area, perc_used) in enumerate(boxes, start=1):
                x0 = max(0, x - pad_px)
                y0 = max(0, y - pad_px)
                x1 = min(w, x + cw + pad_px)
                y1 = min(h, y + ch + pad_px)
                crop = img[y0:y1, x0:x1]
                fname = f"crop_{ci:02d}.png"
                ok, enc = cv2.imencode(".png", crop)
                if not ok:
                    continue
                (slide_dir / fname).write_bytes(enc.tobytes())
                rec = CropRecord(
                    slide_index=slide_idx,
                    crop_index=ci,
                    file=fname,
                    x=int(x0),
                    y=int(y0),
                    width=int(x1 - x0),
                    height=int(y1 - y0),
                    area_px=float(area),
                    percentile_used=float(perc_used),
                )
                slide_entry["crops"].append(asdict(rec))

            manifest["slides"].append(slide_entry)

    (out_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx_path", type=Path)
    ap.add_argument(
        "-o",
        "--out",
        type=Path,
        default=None,
        help="出力フォルダ（省略時は <stem>_visual_crops）",
    )
    ap.add_argument("--percentile", type=float, default=90.0)
    ap.add_argument("--pad", type=int, default=6)
    ap.add_argument("--min-area-ratio", type=float, default=0.0008)
    ap.add_argument("--max-area-ratio", type=float, default=0.7)
    ap.add_argument("--split-area-ratio", type=float, default=0.22)
    ap.add_argument("--blur", type=int, default=51)
    ap.add_argument("--close", type=int, default=7)
    ap.add_argument("--max-depth", type=int, default=3)
    args = ap.parse_args()

    src = args.pptx_path.resolve()
    out = args.out.resolve() if args.out else src.with_name(f"{src.stem}_visual_crops")

    extract_from_pptx(
        src,
        out,
        percentile=args.percentile,
        pad_px=args.pad,
        min_area_ratio=args.min_area_ratio,
        max_area_ratio=args.max_area_ratio,
        split_area_ratio=args.split_area_ratio,
        blur_ksize=args.blur,
        close_ksize=args.close,
        max_depth=args.max_depth,
    )
    print(out)


if __name__ == "__main__":
    main()

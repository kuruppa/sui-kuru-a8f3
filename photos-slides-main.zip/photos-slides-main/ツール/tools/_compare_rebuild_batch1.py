# -*- coding: utf-8 -*-
"""Compare old vs new APbatch01 membership."""
from __future__ import annotations

import csv
import io
import os
import zipfile
from pathlib import Path

OUT = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
ZIP = OUT / "202512.zip"
LOG = Path(__file__).with_name("_batch1_compare.txt")


def load_zip_rows():
    with zipfile.ZipFile(ZIP) as z:
        n = next(x for x in z.namelist() if x.endswith(".csv"))
        text = z.read(n).decode("cp932")
    rows = list(csv.reader(io.StringIO(text)))
    header, data = rows[0], rows[1:]
    data = [r for r in data if any("@" in c for c in r)]
    return header, data


def emails(rows):
    # email is typically col index 2
    out = []
    for r in rows:
        for c in r:
            if "@" in c:
                out.append(c.strip().lower())
                break
    return out


def main():
    header, data = load_zip_rows()
    # CURRENT batch1: first 95 of full 944
    new_b1 = data[0:95]
    # OLD batch1 (bug): standalone CSV had no header; first data row
    # was treated as header and dropped from data. So data started at
    # ZIP index 1. Batch sizes were 95,95,95,94,... on 943 people.
    old_b1 = data[1:96]

    new_e = emails(new_b1)
    old_e = emails(old_b1)
    only_new = sorted(set(new_e) - set(old_e))
    only_old = sorted(set(old_e) - set(new_e))
    both = sorted(set(new_e) & set(old_e))

    lines = []
    lines.append(f"ZIP data count: {len(data)}")
    lines.append(f"NEW APbatch01 count: {len(new_e)} first={new_b1[0][0]} {new_b1[0][1]} <{new_e[0]}>")
    lines.append(f"OLD APbatch01 count: {len(old_e)} first={old_b1[0][0]} {old_b1[0][1]} <{old_e[0]}>")
    lines.append(f"overlap: {len(both)}")
    lines.append(f"only in NEW (not in what you likely imported): {len(only_new)} -> {only_new}")
    lines.append(f"only in OLD (imported but not in current file): {len(only_old)} -> {only_old}")
    lines.append("")
    lines.append("Conclusion: If you imported the first APbatch01 (or AP_batch_01_*),")
    lines.append("that was OLD. Current APbatch01.csv is NEW and differs by 1 person")
    lines.append("at the start/end of the window.")
    LOG.write_text("\n".join(lines), encoding="utf-8")

    # Rebuild APbatch01 as OLD version (match import), and APbatch02-10
    # as continuation of OLD sequence so remaining don't overlap.
    # OLD sequence on data[1:] with sizes for 943:
    remaining = data[1:]  # 943 people, what old scripts treated as full list
    sizes = []
    base, rem = divmod(len(remaining), 10)
    sizes = [base + (1 if i < rem else 0) for i in range(10)]
    # sizes should be 95*3 + 94*7 = 285+658=943

    offset = 0
    for i, size in enumerate(sizes, start=1):
        chunk = remaining[offset : offset + size]
        offset += size
        path = OUT / f"APbatch{i:02d}.csv"
        with path.open("w", encoding="cp932", newline="") as f:
            w = csv.writer(f, lineterminator="\r\n")
            w.writerows([header] + chunk)
        e0 = emails(chunk)[0]
        lines.append(f"rewrote {path.name} n={size} first=<{e0}>")

    # Also leave a file with the ONE person dropped from old scheme
    dropped = data[0:1]
    drop_path = OUT / "APbatch00extra.csv"
    with drop_path.open("w", encoding="cp932", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerows([header] + dropped)
    lines.append(
        f"extra (only in NEW scheme / not in old batch1-10): {drop_path.name} "
        f"{dropped[0][0]} {dropped[0][1]} <{emails(dropped)[0]}>"
    )
    lines.append("APbatch01 restored to match likely-imported OLD content.")
    LOG.write_text("\n".join(lines), encoding="utf-8")
    print("wrote", LOG)


if __name__ == "__main__":
    main()

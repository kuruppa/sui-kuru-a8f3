"""Crop Kuruppa gameplay screen recordings to the game canvas only."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import cv2
import numpy as np

GAME_ASPECT = 960 / 540


def _safe_print(msg: str) -> None:
    text = msg.replace("\u200b", "")
    try:
        print(text, flush=True)
    except UnicodeEncodeError:
        sys.stdout.buffer.write((text + "\n").encode("utf-8", errors="replace"))
        sys.stdout.flush()


def list_kuruppa_videos(cap_dir: Path) -> list[Path]:
    vids = []
    for p in cap_dir.glob("*.mp4"):
        if "くるっぱ" in p.name.replace("\u200b", ""):
            vids.append(p)
    return sorted(vids, key=lambda p: p.stat().st_mtime, reverse=True)


def safe_stem(path: Path, index: int) -> str:
    raw = path.stem.replace("\u200b", "")
    m = re.search(r"(\d{4}-\d{2}-\d{2}[ _]?\d{2}[-_]\d{2}[-_]\d{2})", raw)
    stamp = m.group(1).replace(" ", "_") if m else f"rec{index:02d}"
    return f"kuruppa_game_{stamp}"


def grab_frame_at_sec(path: Path, sec: float) -> tuple[np.ndarray | None, float, int, int]:
    cap = cv2.VideoCapture(str(path))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, sec) * 1000.0)
    ok, frame = cap.read()
    if not ok:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ok, frame = cap.read()
    cap.release()
    return (frame if ok else None), fps, w, h


def detect_game_bbox(frame_bgr: np.ndarray) -> tuple[int, int, int, int]:
    """Find the #game canvas (16:9 rect below browser chrome)."""
    h, w = frame_bgr.shape[:2]
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    edges = cv2.Canny(blur, 30, 100)
    # Ignore browser chrome / taskbar-ish bands
    chrome = max(100, int(h * 0.11))
    edges[:chrome, :] = 0
    edges[int(h * 0.97) :, :] = 0
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    rects: list[tuple[float, int, int, int, int]] = []
    min_area = w * h * 0.10
    max_area = w * h * 0.85
    for cnt in contours:
        x, y, cw, ch = cv2.boundingRect(cnt)
        area = cw * ch
        if area < min_area or area > max_area:
            continue
        if y < chrome:
            continue
        aspect = cw / max(ch, 1)
        if abs(aspect - GAME_ASPECT) > 0.25:
            continue
        score = area * (1.0 - abs(aspect - GAME_ASPECT))
        rects.append((score, x, y, cw, ch))

    if not rects:
        # Fallback centered under chrome
        top = int(h * 0.28)
        bottom = int(h * 0.90)
        usable_h = max(1, bottom - top)
        if w / usable_h > GAME_ASPECT:
            ch = usable_h
            cw = int(ch * GAME_ASPECT)
        else:
            cw = int(w * 0.9)
            ch = int(cw / GAME_ASPECT)
        x = (w - cw) // 2
        y = top + (usable_h - ch) // 2
        return x, y, cw, ch

    rects.sort(reverse=True)
    _, x, y, cw, ch = rects[0]
    # Inset past the CSS border (~4px at 960; scaled)
    inset = max(4, int(round(cw / 960 * 5)))
    x += inset
    y += inset
    cw = max(1, cw - 2 * inset)
    ch = max(1, ch - 2 * inset)
    # Snap remaining box to exact 16:9 by trimming
    if cw / ch > GAME_ASPECT:
        new_w = int(ch * GAME_ASPECT)
        x += (cw - new_w) // 2
        cw = new_w
    else:
        new_h = int(cw / GAME_ASPECT)
        y += (ch - new_h) // 2
        ch = new_h
    return x, y, cw, ch


def export_cropped(
    video: Path,
    out_path: Path,
    bbox: tuple[int, int, int, int],
    out_w: int = 960,
    out_h: int = 540,
) -> dict:
    x, y, cw, ch = bbox
    cap = cv2.VideoCapture(str(video))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
    # Prefer avc1 when available; fall back to mp4v
    writer = None
    for codec in ("avc1", "H264", "X264", "mp4v"):
        fourcc = cv2.VideoWriter_fourcc(*codec)
        writer = cv2.VideoWriter(str(out_path), fourcc, fps, (out_w, out_h))
        if writer.isOpened():
            _safe_print(f"  codec={codec}")
            break
        writer.release()
        writer = None
    if writer is None:
        cap.release()
        raise RuntimeError(f"Failed to open writer: {out_path}")

    written = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        crop = frame[y : y + ch, x : x + cw]
        if crop.size == 0:
            continue
        resized = cv2.resize(crop, (out_w, out_h), interpolation=cv2.INTER_AREA)
        writer.write(resized)
        written += 1
        if written % 400 == 0:
            _safe_print(f"    ... {written} frames")

    writer.release()
    cap.release()
    return {
        "frames": written,
        "fps": fps,
        "bbox": bbox,
        "size_bytes": out_path.stat().st_size if out_path.exists() else 0,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--captures", type=Path, default=Path.home() / "Videos" / "Captures")
    ap.add_argument(
        "--out",
        type=Path,
        default=Path.home() / "Videos" / "Captures" / "kuruppa_cropped",
    )
    ap.add_argument("--preview-only", action="store_true")
    ap.add_argument("--sample-sec", type=float, default=2.5)
    ap.add_argument("--skip-existing", action="store_true", help="Skip if output mp4 already exists")
    ap.add_argument("--only-newer-than", type=str, default="", help="YYYY-MM-DD; only process newer files")
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    videos = list_kuruppa_videos(args.captures)
    if args.only_newer_than:
        from datetime import datetime

        cutoff = datetime.strptime(args.only_newer_than, "%Y-%m-%d").timestamp()
        videos = [v for v in videos if v.stat().st_mtime >= cutoff]
    if not videos:
        _safe_print(f"No kuruppa recordings found in {args.captures}")
        return 1

    _safe_print(f"Found {len(videos)} recording(s)")
    for i, vp in enumerate(videos):
        stem = safe_stem(vp, i)
        out_mp4 = args.out / f"{stem}.mp4"
        _safe_print(f"\n[{i + 1}/{len(videos)}] {stem}")
        if args.skip_existing and out_mp4.exists() and not args.preview_only:
            _safe_print("  SKIP: already exists")
            continue
        frame, fps, vw, vh = grab_frame_at_sec(vp, args.sample_sec)
        if frame is None:
            _safe_print("  SKIP: could not read frame")
            continue
        _safe_print(f"  source {vw}x{vh} @ {fps:.2f}fps")
        bbox = detect_game_bbox(frame)
        x, y, cw, ch = bbox
        _safe_print(f"  bbox x={x} y={y} w={cw} h={ch}")

        vis = frame.copy()
        cv2.rectangle(vis, (x, y), (x + cw, y + ch), (0, 255, 0), 3)
        cv2.imwrite(str(args.out / f"{stem}_preview.png"), vis)
        cv2.imwrite(str(args.out / f"{stem}_crop.png"), frame[y : y + ch, x : x + cw])

        if args.preview_only:
            continue

        info = export_cropped(vp, out_mp4, bbox)
        _safe_print(
            f"  wrote {info['frames']} frames ({info['size_bytes'] / 1e6:.1f} MB) -> {out_mp4.name}"
        )
        # Re-encode to H.264 for playback compatibility when possible
        try:
            import imageio_ffmpeg
            import subprocess

            ff = imageio_ffmpeg.get_ffmpeg_exe()
            tmp = out_mp4.with_name(out_mp4.stem + "_h264.mp4")
            cmd = [
                ff,
                "-y",
                "-i",
                str(out_mp4),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-crf",
                "20",
                "-preset",
                "fast",
                "-an",
                str(tmp),
            ]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode == 0 and tmp.exists():
                out_mp4.unlink()
                tmp.rename(out_mp4)
                _safe_print(f"  h264 {out_mp4.stat().st_size / 1e6:.1f} MB")
            elif tmp.exists():
                tmp.unlink()
        except Exception as exc:
            _safe_print(f"  h264 skip: {exc}")

    _safe_print(f"\nDone: {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

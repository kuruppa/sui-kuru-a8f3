"""One-off: run EasyOCR on the 3 Kurume slides and cache results to JSON.

Caches tight per-line boxes so later layout work does not need to re-run OCR.
"""
from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image
import easyocr

PPTX = Path(r"c:\Users\newor\Downloads\New_Kurume_Relocation_Subsidy_(7).pptx")
CACHE = Path(r"c:\Users\newor\Downloads\_kurume_view\ocr_cache.json")


def main() -> None:
    reader = easyocr.Reader(["ja", "en"], gpu=False, verbose=False)
    z = zipfile.ZipFile(str(PPTX))
    out = {"slides": []}
    for idx in (1, 2, 3):
        raw = z.read(f"ppt/media/image{idx}.png")
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        arr = np.array(im)
        regions = reader.readtext(arr, detail=1, paragraph=False)
        recs = []
        for box, text, conf in regions:
            xs = [float(p[0]) for p in box]
            ys = [float(p[1]) for p in box]
            recs.append(
                {
                    "x0": min(xs),
                    "y0": min(ys),
                    "x1": max(xs),
                    "y1": max(ys),
                    "text": text,
                    "conf": float(conf),
                }
            )
        out["slides"].append({"index": idx, "w": im.width, "h": im.height, "regions": recs})
        print(f"slide{idx}: {len(recs)} regions")
    CACHE.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("cached ->", CACHE)


if __name__ == "__main__":
    main()

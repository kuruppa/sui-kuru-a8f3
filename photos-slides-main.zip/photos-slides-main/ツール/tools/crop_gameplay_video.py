"""Crop Edge screen capture to game canvas only."""
from __future__ import annotations

import sys
from pathlib import Path

import av
import numpy as np

# crop box detected from frame analysis (game canvas + border)
X, Y, W, H = 459, 180, 1002, 622


def find_source() -> Path:
    captures = Path(r"C:\Users\newor\Videos\Captures")
    vids = sorted(captures.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
    for v in vids:
        n = v.name.replace("\u200b", "")
        if "2026-08-06" in n or "05-32-11" in n:
            return v
    raise FileNotFoundError("source mp4 not found")


def main() -> None:
    vid = Path(sys.argv[1]) if len(sys.argv) >= 2 else find_source()
    out_path = (
        Path(sys.argv[2])
        if len(sys.argv) >= 3
        else Path(r"C:\Users\newor\Videos\Captures") / "kuruppa_gameplay_only_2026-08-06.mp4"
    )
    print(f"in_size={vid.stat().st_size}", flush=True)
    print(f"out={out_path}", flush=True)
    print(f"crop=x={X},y={Y},w={W},h={H}", flush=True)

    inp = av.open(str(vid))
    v_in = inp.streams.video[0]
    fps = float(v_in.average_rate) if v_in.average_rate else 30.0
    rate = round(fps) if abs(fps - round(fps)) < 0.15 else 30

    out = av.open(str(out_path), mode="w")
    v_out = out.add_stream("libx264", rate=rate)
    v_out.width = W
    v_out.height = H
    v_out.pix_fmt = "yuv420p"
    v_out.options = {"crf": "20", "preset": "fast"}

    n = 0
    for frame in inp.decode(video=0):
        arr = frame.to_ndarray(format="rgb24")
        crop = np.ascontiguousarray(arr[Y : Y + H, X : X + W])
        f = av.VideoFrame.from_ndarray(crop, format="rgb24")
        f.pts = n
        for pkt in v_out.encode(f):
            out.mux(pkt)
        n += 1
        if n % 150 == 0:
            print(f"frames {n}", flush=True)

    for pkt in v_out.encode(None):
        out.mux(pkt)

    out.close()
    inp.close()
    print(f"done frames={n} size={out_path.stat().st_size}", flush=True)


if __name__ == "__main__":
    main()

"""Probe: detect colored (non-white) blobs on slides 2 & 3, visualize boxes."""
from __future__ import annotations

import zipfile
from pathlib import Path

import cv2
import numpy as np

PPTX = Path(r"c:\Users\newor\Downloads\New_Kurume_Relocation_Subsidy_(7).pptx")
OUT = Path(r"c:\Users\newor\Downloads\_kurume_view")


def blobs(img, min_area=1500, close=15):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # non-white mask
    mask = (gray < 235).astype(np.uint8) * 255
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close, close))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k)
    n, lbl, stats, cent = cv2.connectedComponentsWithStats(mask, 8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = stats[i]
        if a < min_area:
            continue
        out.append((int(x), int(y), int(w), int(h), int(a)))
    return out


def main():
    z = zipfile.ZipFile(str(PPTX))
    for idx in (2, 3):
        img = cv2.imdecode(np.frombuffer(z.read(f"ppt/media/image{idx}.png"), np.uint8), cv2.IMREAD_COLOR)
        vis = img.copy()
        bs = blobs(img)
        print(f"=== slide{idx}: {len(bs)} blobs ===")
        for j, (x, y, w, h, a) in enumerate(bs):
            cv2.rectangle(vis, (x, y), (x + w, y + h), (0, 0, 255), 3)
            cv2.putText(vis, str(j), (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)
            print(f"  [{j}] x={x} y={y} w={w} h={h} area={a}")
        ok, enc = cv2.imencode(".png", vis)
        (OUT / f"probe_slide{idx}.png").write_bytes(enc.tobytes())
    print("saved probes")


if __name__ == "__main__":
    main()

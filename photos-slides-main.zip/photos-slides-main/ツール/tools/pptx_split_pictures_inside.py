"""
Replace each slide's largest raster picture with multiple Picture shapes (cropped regions).

Graphic regions are detected with the same heuristic as pptx_extract_visual_crops.py.
Text boxes / other shapes are left as-is and stay above the new pictures (z-order).
"""
from __future__ import annotations

import argparse
import io
import sys
from pathlib import Path

import cv2
import numpy as np
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

_TOOLS = Path(__file__).resolve().parent
if str(_TOOLS) not in sys.path:
    sys.path.insert(0, str(_TOOLS))

from pptx_extract_visual_crops import segment_slide_bgr_to_boxes


def _find_largest_picture(slide):
    pics = [s for s in slide.shapes if s.shape_type == MSO_SHAPE_TYPE.PICTURE]
    if not pics:
        return None
    return max(pics, key=lambda s: int(s.width) * int(s.height))


def _picture_slide_index(slide, pic) -> int | None:
    for i, s in enumerate(slide.shapes):
        if s._element is pic._element:
            return i
    return None


def _pixel_rect_to_placement(
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    *,
    pic_left: int,
    pic_top: int,
    pic_w: int,
    pic_h: int,
    img_w: int,
    img_h: int,
) -> tuple[int, int, int, int]:
    left = pic_left + int(round(x0 * pic_w / img_w))
    top = pic_top + int(round(y0 * pic_h / img_h))
    width = max(1, int(round((x1 - x0) * pic_w / img_w)))
    height = max(1, int(round((y1 - y0) * pic_h / img_h)))
    return left, top, width, height


def split_pictures_inside_pptx(
    src: Path,
    dst: Path,
    *,
    percentile: float,
    pad_px: int,
    min_area_ratio: float,
    max_area_ratio: float,
    split_area_ratio: float,
    blur_ksize: int,
    close_ksize: int,
    max_depth: int,
    skip_if_single_near_full: bool,
) -> None:
    prs = Presentation(str(src))
    for si, slide in enumerate(prs.slides, start=1):
        pic = _find_largest_picture(slide)
        if pic is None:
            print(f"[slide {si}] 画像なし — スキップ", file=sys.stderr)
            continue

        idx_pic = _picture_slide_index(slide, pic)
        if idx_pic is None:
            continue
        anchor_after = None
        if idx_pic + 1 < len(slide.shapes):
            anchor_after = slide.shapes[idx_pic + 1]._element

        blob = pic.image.blob
        img_bgr = cv2.imdecode(np.frombuffer(blob, dtype=np.uint8), cv2.IMREAD_COLOR)
        if img_bgr is None:
            print(f"[slide {si}] 画像デコード失敗 — スキップ", file=sys.stderr)
            continue

        ih, iw = img_bgr.shape[:2]
        boxes = segment_slide_bgr_to_boxes(
            img_bgr,
            percentile=percentile,
            min_area_ratio=min_area_ratio,
            max_area_ratio=max_area_ratio,
            split_area_ratio=split_area_ratio,
            blur_ksize=blur_ksize,
            close_ksize=close_ksize,
            max_depth=max_depth,
        )

        if not boxes:
            print(f"[slide {si}] 領域0件 — 元画像のまま", file=sys.stderr)
            continue

        if skip_if_single_near_full and len(boxes) == 1:
            _, _, cw, ch, area, _ = boxes[0]
            if area >= 0.92 * float(iw * ih):
                print(f"[slide {si}] ほぼ全面1枚 — 分割スキップ", file=sys.stderr)
                continue

        pic_left = int(pic.left)
        pic_top = int(pic.top)
        pic_w = int(pic.width)
        pic_h = int(pic.height)

        pic._element.getparent().remove(pic._element)

        new_elems: list = []
        for x, y, cw, ch, _a, _p in boxes:
            x0 = max(0, x - pad_px)
            y0 = max(0, y - pad_px)
            x1 = min(iw, x + cw + pad_px)
            y1 = min(ih, y + ch + pad_px)
            crop = img_bgr[y0:y1, x0:x1]
            ok, enc = cv2.imencode(".png", crop)
            if not ok:
                continue
            stream = io.BytesIO(enc.tobytes())
            left, top, width, height = _pixel_rect_to_placement(
                x0,
                y0,
                x1,
                y1,
                pic_left=pic_left,
                pic_top=pic_top,
                pic_w=pic_w,
                pic_h=pic_h,
                img_w=iw,
                img_h=ih,
            )
            shp = slide.shapes.add_picture(stream, left, top, width=width, height=height)
            new_elems.append(shp._element)

        if not new_elems:
            print(f"[slide {si}] 警告: 画像の削除のみで追加失敗 — 手動で元に戻してください", file=sys.stderr)
            continue

        parent = new_elems[0].getparent()
        for el in new_elems:
            parent.remove(el)

        if anchor_after is not None and anchor_after.getparent() is not None:
            insert_at = parent.index(anchor_after)
            for i, el in enumerate(new_elems):
                parent.insert(insert_at + i, el)
        else:
            insert_at = 0
            for i, el in enumerate(new_elems):
                parent.insert(insert_at + i, el)

        print(f"[slide {si}] 画像 {len(new_elems)} 枚に分割", file=sys.stderr)

    prs.save(str(dst))


def main() -> None:
    ap = argparse.ArgumentParser(
        description="pptx 内の一枚画像を複数の画像シェイプに分解して配置し直します。"
    )
    ap.add_argument("pptx_path", type=Path)
    ap.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="出力pptx（省略時は *_split_shapes.pptx）",
    )
    ap.add_argument("--percentile", type=float, default=90.0)
    ap.add_argument("--pad", type=int, default=6)
    ap.add_argument("--min-area-ratio", type=float, default=0.0008)
    ap.add_argument("--max-area-ratio", type=float, default=0.7)
    ap.add_argument("--split-area-ratio", type=float, default=0.22)
    ap.add_argument("--blur", type=int, default=51)
    ap.add_argument("--close", type=int, default=7)
    ap.add_argument("--max-depth", type=int, default=3)
    ap.add_argument(
        "--no-skip-single",
        action="store_true",
        help="全面に近い1領域でも必ず差し替える",
    )
    args = ap.parse_args()

    src = args.pptx_path.resolve()
    dst = args.output.resolve() if args.output else src.with_name(f"{src.stem}_split_shapes{src.suffix}")

    split_pictures_inside_pptx(
        src,
        dst,
        percentile=args.percentile,
        pad_px=args.pad,
        min_area_ratio=args.min_area_ratio,
        max_area_ratio=args.max_area_ratio,
        split_area_ratio=args.split_area_ratio,
        blur_ksize=args.blur,
        close_ksize=args.close,
        max_depth=args.max_depth,
        skip_if_single_near_full=not args.no_skip_single,
    )
    print(dst)


if __name__ == "__main__":
    main()

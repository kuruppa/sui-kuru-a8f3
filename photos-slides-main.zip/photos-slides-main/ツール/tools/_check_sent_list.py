# -*- coding: utf-8 -*-
"""Compare 7th-mail export vs planned APbatch files."""
from __future__ import annotations

import csv
import io
import os
from pathlib import Path

EXPORT = Path(r"c:\Users\newor\Downloads\userdl_2026-07-15_18_18_25.csv")
BATCH_DIR = Path(os.environ["USERPROFILE"]) / "Desktop" / "起業" / "メルマガ" / "メルマガリスト"
LOG = Path(r"c:\Users\newor\こいこい用\photos-slides\tools\_sent_list_check.txt")


def read_csv(path: Path) -> list[list[str]]:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp932", "utf-8"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        text = raw.decode("cp932", errors="replace")
    return list(csv.reader(io.StringIO(text)))


def emails_from_rows(rows: list[list[str]], has_header: bool = True) -> set[str]:
    data = rows[1:] if has_header and rows else rows
    out: set[str] = set()
    for r in data:
        for c in r:
            if "@" in c:
                out.add(c.strip().lower())
                break
    return out


def main() -> None:
    lines: list[str] = []
    exp_rows = read_csv(EXPORT)
    lines.append(f"export: {EXPORT.name}")
    lines.append(f"export header: {exp_rows[0] if exp_rows else None}")
    lines.append(f"export rows incl header: {len(exp_rows)}")
    sent = emails_from_rows(exp_rows)
    lines.append(f"export unique emails: {len(sent)}")

    # Load all APbatch files
    batches: dict[str, set[str]] = {}
    for p in sorted(BATCH_DIR.glob("APbatch*.csv")):
        rows = read_csv(p)
        # our batches always have header
        em = emails_from_rows(rows, has_header=True)
        # if first row looks like data (has @), include it
        if rows and any("@" in c for c in rows[0]):
            em |= emails_from_rows(rows, has_header=False)
        batches[p.name] = em
        lines.append(f"  {p.name}: {len(em)} emails")

    # Likely imported: batch10 (first import) + batch02 (second) — also check 01,03...
    # Compare each batch for containment
    lines.append("\n=== each batch vs export ===")
    for name, em in batches.items():
        if name.startswith("APbatch00"):
            continue
        in_sent = em & sent
        missing = em - sent
        extra_note = ""
        lines.append(
            f"{name}: in_export={len(in_sent)}/{len(em)} "
            f"missing_from_export={len(missing)}"
        )
        if missing and len(missing) <= 5:
            lines.append(f"  missing emails: {sorted(missing)}")
        elif missing:
            lines.append(f"  missing sample: {sorted(missing)[:5]}")

    # Best guess: which combination fully covers export?
    lines.append("\n=== coverage analysis ===")
    # Find batches that are mostly inside export (>=90%)
    likely = []
    for name, em in batches.items():
        if name.startswith("APbatch00"):
            continue
        if not em:
            continue
        ratio = len(em & sent) / len(em)
        if ratio >= 0.9:
            likely.append((name, ratio, len(em & sent), len(em - sent)))
            lines.append(f"LIKELY imported {name}: match_ratio={ratio:.1%} in={len(em&sent)} missing={len(em-sent)}")

    union_likely = set()
    for name, *_ in likely:
        union_likely |= batches[name]

    lines.append(f"\nunion of likely batches: {len(union_likely)}")
    only_export = sent - union_likely
    only_batches = union_likely - sent
    lines.append(f"in export but NOT in likely batches: {len(only_export)}")
    lines.append(f"in likely batches but NOT in export: {len(only_batches)}")

    if only_export:
        # map to names from export
        exp_data = exp_rows[1:]
        email_to_row = {}
        for r in exp_data:
            for c in r:
                if "@" in c:
                    email_to_row[c.strip().lower()] = r
                    break
        lines.append("extra in export (sample up to 15):")
        for e in sorted(only_export)[:15]:
            lines.append(f"  {e} | {email_to_row.get(e)}")

    if only_batches:
        lines.append("missing from export (should have been sent / imported):")
        for name, em in batches.items():
            miss = (em & union_likely) - sent
            if miss:
                # get names from batch file
                rows = read_csv(BATCH_DIR / name)
                emap = {}
                for r in rows[1:]:
                    for c in r:
                        if "@" in c:
                            emap[c.strip().lower()] = r
                            break
                for e in sorted(miss):
                    lines.append(f"  [{name}] {e} | {emap.get(e)}")

    # Also: exact match batch10+02
    for combo_names in [
        ["APbatch10.csv", "APbatch02.csv"],
        ["APbatch10.csv", "APbatch01.csv"],
        ["APbatch10.csv", "APbatch02.csv", "APbatch01.csv"],
        ["APbatch10.csv", "APbatch02.csv", "APbatch03.csv"],
    ]:
        if not all((BATCH_DIR / n).exists() for n in combo_names):
            continue
        u = set()
        for n in combo_names:
            u |= batches[n]
        lines.append(
            f"\ncombo { '+'.join(combo_names) }: union={len(u)} "
            f"export_overlap={len(u & sent)} "
            f"missing_from_export={len(u - sent)} "
            f"extra_in_export={len(sent - u)}"
        )
        if u - sent:
            lines.append(f"  missing: {sorted(u - sent)[:20]}")
        if sent - u:
            lines.append(f"  extra sample: {sorted(sent - u)[:10]}")

    LOG.write_text("\n".join(lines), encoding="utf-8")
    print("wrote", LOG)


if __name__ == "__main__":
    main()

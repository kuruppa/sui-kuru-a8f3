import os
import shutil
import zipfile
import tempfile
from pathlib import Path
from io import BytesIO

import numpy as np
from PIL import Image, ImageDraw
import pikepdf
import fitz  # PyMuPDF

SOURCE_DIR = Path(r"C:\Users\newor\Desktop\起業\研修講師関連\研修用ソース\情報発信とコンプライアンス")
OUTPUT_DIR = SOURCE_DIR / "compressed"

PPTX_MAX_DIM = 800
PPTX_JPEG_QUALITY = 25

PDF_IMG_MAX_DIM = 600
PDF_IMG_QUALITY = 20

PDF_RENDER_DPI = 72
PDF_RENDER_QUALITY = 20

# NotebookLM position at 1x (1376x768 base resolution)
# Measured: icon+text spans x=[1270,1364], y=[748,757]
NLM_X1_1X = 1262
NLM_Y1_1X = 743
NLM_X2_1X = 1370
NLM_Y2_1X = 762


def remove_notebooklm(img: Image.Image) -> Image.Image:
    """Remove NotebookLM text using precise pixel detection within a tight region."""
    w, h = img.size
    scale_x = w / 1376.0
    scale_y = h / 768.0

    x1 = int(NLM_X1_1X * scale_x)
    y1 = int(NLM_Y1_1X * scale_y)
    x2 = int(NLM_X2_1X * scale_x)
    y2 = int(NLM_Y2_1X * scale_y)
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)

    region = np.array(img.crop((x1, y1, x2, y2)).convert("RGB")).astype(float)
    rh, rw = region.shape[:2]
    if rh < 3 or rw < 3:
        return img

    # Sample background from left edge of the tight region (before the icon)
    sample_w = max(3, rw // 8)
    bg_color = np.median(region[:, :sample_w].reshape(-1, 3), axis=0)
    bg_brightness = np.mean(bg_color)

    diff = np.sqrt(np.sum((region - bg_color) ** 2, axis=2))
    threshold = 40 if bg_brightness > 128 else 50
    text_mask = diff > threshold

    if np.sum(text_mask) < 3:
        return img

    # Dilate mask by 2px to cover anti-aliasing
    dilated = text_mask.copy()
    for dy in range(-2, 3):
        for dx in range(-2, 3):
            if abs(dy) + abs(dx) <= 2:
                shifted = np.roll(np.roll(text_mask, dy, axis=0), dx, axis=1)
                dilated = dilated | shifted

    result_arr = np.array(img.convert("RGB")).copy()
    bg_int = bg_color.astype(np.uint8)
    sub = result_arr[y1:y2, x1:x2]
    for c in range(3):
        sub[:, :, c] = np.where(dilated[:sub.shape[0], :sub.shape[1]], bg_int[c], sub[:, :, c])
    result_arr[y1:y2, x1:x2] = sub

    if img.mode == "RGBA":
        result = img.copy()
        result.paste(Image.fromarray(result_arr), (0, 0))
        return result
    return Image.fromarray(result_arr)


def compress_pptx(src: Path, dst: Path):
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        with zipfile.ZipFile(src, 'r') as zin:
            zin.extractall(tmpdir)

        media_dir = tmpdir / "ppt" / "media"
        if media_dir.exists():
            for img_file in media_dir.iterdir():
                if img_file.suffix.lower() not in (".png", ".jpg", ".jpeg", ".tiff", ".tif", ".bmp", ".gif"):
                    continue
                data = img_file.read_bytes()
                try:
                    img = Image.open(BytesIO(data))
                except Exception:
                    continue

                img = remove_notebooklm(img)

                if img.mode == "RGBA":
                    bg = Image.new("RGB", img.size, (255, 255, 255))
                    bg.paste(img, mask=img.split()[3])
                    img = bg
                elif img.mode not in ("RGB", "L"):
                    img = img.convert("RGB")

                w, h = img.size
                if max(w, h) > PPTX_MAX_DIM:
                    ratio = PPTX_MAX_DIM / max(w, h)
                    img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)

                buf = BytesIO()
                img.save(buf, format="JPEG", quality=PPTX_JPEG_QUALITY, optimize=True)
                compressed = buf.getvalue()

                new_name = img_file.stem + ".jpg"
                new_path = img_file.parent / new_name
                if img_file.suffix.lower() != ".jpg":
                    _update_refs(tmpdir, img_file.name, new_name)
                    img_file.unlink()
                new_path.write_bytes(compressed)
                print(f"  {img_file.name}: {len(data)//1024}KB -> {len(compressed)//1024}KB")

        with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zout:
            for root, dirs, files in os.walk(tmpdir):
                for f in files:
                    fp = Path(root) / f
                    zout.write(fp, fp.relative_to(tmpdir))

    print(f"  PPTX: {src.stat().st_size/1048576:.2f}MB -> {dst.stat().st_size/1048576:.2f}MB ({dst.stat().st_size/src.stat().st_size*100:.1f}%)")


def _update_refs(tmpdir: Path, old_name: str, new_name: str):
    for pattern in ["ppt/slides/_rels/*.rels", "ppt/_rels/*.rels"]:
        for f in tmpdir.glob(pattern):
            content = f.read_text(encoding="utf-8")
            if old_name in content:
                f.write_text(content.replace(old_name, new_name), encoding="utf-8")

    ct_file = tmpdir / "[Content_Types].xml"
    if ct_file.exists():
        content = ct_file.read_text(encoding="utf-8")
        new_ext = Path(new_name).suffix.lstrip(".")
        if f'Extension="{new_ext}"' not in content:
            if new_ext in ("jpg", "jpeg"):
                ext_entry = f'<Default Extension="{new_ext}" ContentType="image/jpeg"/>'
            elif new_ext == "png":
                ext_entry = f'<Default Extension="{new_ext}" ContentType="image/png"/>'
            else:
                ext_entry = ""
            if ext_entry:
                content = content.replace("</Types>", f"{ext_entry}</Types>")
        ct_file.write_text(content, encoding="utf-8")


def _extract_pdf_image(xobj, w, h):
    filters = xobj.get("/Filter")
    if isinstance(filters, pikepdf.Array):
        filter_list = [str(f) for f in filters]
    else:
        filter_list = [str(filters)] if filters else []

    raw_data = xobj.read_raw_bytes()

    if "/DCTDecode" in filter_list:
        try:
            return Image.open(BytesIO(raw_data))
        except Exception:
            return None

    try:
        decompressed = xobj.read_bytes()
    except Exception:
        return None

    cs = str(xobj.get("/ColorSpace", ""))
    if "/DeviceRGB" in cs or "RGB" in cs:
        mode, ch = "RGB", 3
    elif "/DeviceCMYK" in cs or "CMYK" in cs:
        mode, ch = "CMYK", 4
    elif "/DeviceGray" in cs or "Gray" in cs:
        mode, ch = "L", 1
    else:
        mode, ch = "RGB", 3

    expected = w * h * ch
    if len(decompressed) < expected:
        if ch == 3:
            mode, ch, expected = "L", 1, w * h
            if len(decompressed) < expected:
                return None
        else:
            return None

    try:
        img = Image.frombytes(mode, (w, h), decompressed[:expected])
        return img.convert("RGB") if mode == "CMYK" else img
    except Exception:
        return None


def compress_pdf_pikepdf(src: Path, dst: Path):
    with pikepdf.open(src) as pdf:
        for page in pdf.pages:
            if "/Resources" not in page:
                continue
            resources = page["/Resources"]
            if "/XObject" not in resources:
                continue
            for key in list(resources["/XObject"].keys()):
                xobj = resources["/XObject"][key]
                if not isinstance(xobj, pikepdf.Stream) or xobj.get("/Subtype") != "/Image":
                    continue
                try:
                    w, h = int(xobj.get("/Width", 0)), int(xobj.get("/Height", 0))
                    if w == 0 or h == 0:
                        continue
                    raw_data = xobj.read_raw_bytes()
                    pil_img = _extract_pdf_image(xobj, w, h)
                    if pil_img is None:
                        continue
                    if max(w, h) > PDF_IMG_MAX_DIM:
                        ratio = PDF_IMG_MAX_DIM / max(w, h)
                        pil_img = pil_img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
                    if pil_img.mode not in ("RGB", "L"):
                        pil_img = pil_img.convert("RGB")
                    buf = BytesIO()
                    pil_img.save(buf, format="JPEG", quality=PDF_IMG_QUALITY, optimize=True)
                    new_data = buf.getvalue()
                    if len(new_data) < len(raw_data):
                        xobj.write(new_data, filter=pikepdf.Name("/DCTDecode"))
                        xobj["/Width"] = pil_img.width
                        xobj["/Height"] = pil_img.height
                        xobj["/ColorSpace"] = pikepdf.Name("/DeviceRGB") if pil_img.mode == "RGB" else pikepdf.Name("/DeviceGray")
                        xobj["/BitsPerComponent"] = 8
                        for k in ("/DecodeParms", "/SMask"):
                            if k in xobj:
                                del xobj[k]
                except Exception:
                    continue

        pdf.remove_unreferenced_resources()
        pdf.save(dst, linearize=True, compress_streams=True,
                 stream_decode_level=pikepdf.StreamDecodeLevel.generalized)


def compress_pdf_render(src: Path, dst: Path):
    doc = fitz.open(str(src))
    out_doc = fitz.open()
    for page_num in range(len(doc)):
        page = doc[page_num]
        mat = fitz.Matrix(PDF_RENDER_DPI / 72, PDF_RENDER_DPI / 72)
        pix = page.get_pixmap(matrix=mat)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        buf = BytesIO()
        img.save(buf, format="JPEG", quality=PDF_RENDER_QUALITY, optimize=True)
        new_page = out_doc.new_page(width=page.rect.width, height=page.rect.height)
        new_page.insert_image(fitz.Rect(0, 0, page.rect.width, page.rect.height), stream=buf.getvalue())
    out_doc.save(str(dst), deflate=True, garbage=4)
    out_doc.close()
    doc.close()


def compress_pdf_best(src: Path, dst: Path):
    orig_size = src.stat().st_size
    results = {}

    for method_name, method_fn in [("pikepdf", compress_pdf_pikepdf), ("render", compress_pdf_render)]:
        tmp = dst.parent / f"_tmp_{method_name}_{dst.name}"
        try:
            method_fn(src, tmp)
            results[method_name] = tmp.stat().st_size
        except Exception as e:
            print(f"  {method_name} failed: {e}")
            if tmp.exists():
                tmp.unlink()

    if not results:
        shutil.copy2(src, dst)
        print(f"  PDF: kept original ({orig_size/1048576:.2f}MB)")
        return

    best_method = min(results, key=results.get)
    best_size = results[best_method]

    if best_size >= orig_size:
        shutil.copy2(src, dst)
        for m in results:
            tmp = dst.parent / f"_tmp_{m}_{dst.name}"
            if tmp.exists():
                tmp.unlink()
        print(f"  PDF: kept original ({orig_size/1048576:.2f}MB)")
        return

    best_tmp = dst.parent / f"_tmp_{best_method}_{dst.name}"
    shutil.move(str(best_tmp), str(dst))
    for m in results:
        if m != best_method:
            tmp = dst.parent / f"_tmp_{m}_{dst.name}"
            if tmp.exists():
                tmp.unlink()

    print(f"  PDF({best_method}): {orig_size/1048576:.2f}MB -> {best_size/1048576:.2f}MB ({best_size/orig_size*100:.1f}%)")


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    source_subdir = SOURCE_DIR / "ソース"
    if source_subdir.exists():
        (OUTPUT_DIR / "ソース").mkdir(exist_ok=True)

    total_orig = 0
    total_new = 0

    for f in sorted(SOURCE_DIR.iterdir()):
        if f.is_dir():
            continue
        total_orig += f.stat().st_size
        dst = OUTPUT_DIR / f.name
        print(f"\nProcessing: {f.name}")
        if f.suffix.lower() == ".pptx":
            compress_pptx(f, dst)
        elif f.suffix.lower() == ".pdf":
            compress_pdf_best(f, dst)
        else:
            shutil.copy2(f, dst)
        total_new += dst.stat().st_size

    if source_subdir.exists():
        for f in sorted(source_subdir.iterdir()):
            if f.is_dir():
                continue
            total_orig += f.stat().st_size
            dst = OUTPUT_DIR / "ソース" / f.name
            print(f"\nProcessing: ソース/{f.name}")
            if f.suffix.lower() == ".pdf":
                compress_pdf_best(f, dst)
            else:
                shutil.copy2(f, dst)
            total_new += dst.stat().st_size

    print(f"\n{'='*60}")
    print(f"Total original: {total_orig/1048576:.2f} MB")
    print(f"Total compressed: {total_new/1048576:.2f} MB")
    print(f"Compression ratio: {total_new/total_orig*100:.1f}% (1/{total_orig/total_new:.1f})")
    print(f"Output: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()

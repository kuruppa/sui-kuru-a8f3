const CACHE = "kuruppa-river-v2";
const ASSETS = [
  "./index.html",
  "./css/game.css",
  "./js/game.js",
  "./manifest.json",
  "./assets/icon.svg",
  "./assets/icon.png",
  "./assets/kuruppa-sit.png",
  "./assets/kuruppa-happy.png",
  "./assets/kuruppa-smile.png",
  "./assets/kuruppa-dizzy.png",
  "./assets/kuruppa-yay.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((hit) => hit || fetch(event.request))
  );
});
